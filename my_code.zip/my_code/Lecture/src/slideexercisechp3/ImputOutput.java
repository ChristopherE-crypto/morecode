package slideexercisechp3;
import java.util.Scanner;

public class ImputOutput {
public static void main(String [] args) {
	
	Scanner kb = new Scanner(System.in);
	int hour, minute, second, secHr, secMin, secTotal,secsincemid,remainingsecday;
	final int SEC12H = 43200;
	final int SEC24H = 86400;
	System.out.println("What is the hour of the day? [Use a 24 hour clock (8am is 8, 2pm is 14)]");
	hour = kb.nextInt();
	System.out.println("What is the minute of the hour? ");
	minute = kb.nextInt();
	System.out.println("What is the second of the minute? ");
	second = kb.nextInt();
	secHr = (hour * 60 * 60);
	secMin = (minute * 60);
	secTotal = secHr + secMin + second;
	secsincemid = Math.abs(secTotal - SEC12H);
	remainingsecday = SEC24H - secTotal;
	System.out.println("Number of seconds since midnight: "+secsincemid);
	System.out.println("Number of seconds remaining in the day: "+remainingsecday);
	
	System.out.printf("The current time is %02d:%02d:%02d",hour,minute,second);

    }
}
