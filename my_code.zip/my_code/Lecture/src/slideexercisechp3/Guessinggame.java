package slideexercisechp3;
import java.util.Scanner;
import java.util.Random;

public class Guessinggame {
public static void main(String [] args) {
	
Scanner scnr = new Scanner(System.in);
Random randG = new Random();

System.out.println("What is your full name?");
String fullName = scnr.nextLine();

System.out.println("Welcome "+fullName);
System.out.println("I'm thinking about a number. Can you guess what number it is?");
int userNum = scnr.nextInt();
int randNum = randG.nextInt(101) + 1;
int diff = Math.abs(randNum - userNum);

System.out.println("What is your nickname?");
String nickName = scnr.next();

System.out.printf("The number you guess was %2d, my number is %2d. They were %2d numbers apart.", userNum, randNum, diff);

System.out.println(" Good bye, "+fullName + " a.k.a "+nickName + ", see you next time!");

scnr.close();

   }
}
