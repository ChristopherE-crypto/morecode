package slideexercisechp3;
import java.util.Scanner;

public class Exercise4xd {
public static void main(String [] args) {
	
double cm;
int feet, inches, remainingInches;
final double CM_PER_INCH = 2.54;
final int INCHES_PER_FOOT = 12;

	
	

Scanner scnr = new Scanner(System.in);

	
	
System.out.println("Hi! Welcome to the cm to ft. in. converter :-D");	
System.out.println("Hi can you tell me how many centimeters so I can convert to feet and inches for you:  ");

cm = scnr.nextDouble();

inches = (int)(cm / CM_PER_INCH);

feet = inches / INCHES_PER_FOOT;

remainingInches = inches % INCHES_PER_FOOT;

System.out.printf("The conversion from %.2f centimeters equals to %02d feet and %02d inches.", cm, feet, remainingInches);







	scnr.close();
}
}
