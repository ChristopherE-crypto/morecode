package slideexercisechp2;

public class X1x {
public static void main(String [] args) {
	
	String greeting	= "Hello Everyone!";
	System.out.println(greeting);
	final char SPACE_CHARACTER = ' ';
	int locationOf_Space = greeting.indexOf(SPACE_CHARACTER);
	System.out.println("Index of the space character is "+ locationOf_Space	);
	
	System.out.println("The index of 'e' character is "+ greeting.indexOf('e'));
	System.out.println("The index of \"every\" character is "+ greeting.indexOf("every"));
	System.out.println("The index of \"Every\" character is "+ greeting.indexOf("Every"));
	System.out.println("The index of 'e' character is "+ greeting.indexOf('e'));
	System.out.println("Has very? "+ greeting.contains("very"));
	System.out.println("Has every? "+ greeting.contains("every"));
	System.out.println("Has Every? "+ greeting.contains("Every"));
	
	
	
	
}
}
