package slideexercisechp2;
import java.lang.Math;
import java.util.Random;

public class MethodsfromMathandRandom {
public static void main(String [] args) {
	
Random randG = new Random();

int randNum = randG.nextInt(501)+1;

System.out.println("The random number generated is: "+ randNum);

int result1 = randNum * 2;
System.out.println(result1);

int result2 = (int) Math.pow(randNum, 2);
System.out.println(result2);

int result3 = (int) Math.sqrt(randNum);
System.out.println(result3);
	
   }
}
