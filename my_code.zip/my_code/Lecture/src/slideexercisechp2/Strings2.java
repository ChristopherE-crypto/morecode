package slideexercisechp2;
import java.util.Scanner;

public class Strings2 {
public static void main(String [] args) {
	
	Scanner kb = new Scanner(System.in);
	System.out.println("In 1 sentence, tell me what is on your mind.");
	String sentence = kb.nextLine();//retrieve input from the user�s keyboard entry
	System.out.println("You said: " + sentence);//print their sentence back to them
	char firstChar = sentence.charAt(0);
	System.out.println("The first character of your sentence is: "+firstChar);
	int lastChar = sentence.length()-1;
	System.out.println("The last character of your sentence is: "+sentence.charAt(lastChar));
	String sentenceAsLower = sentence.toLowerCase();
	System.out.println(sentenceAsLower);
	int locationCharA = sentence.indexOf('a');
	System.out.println(locationCharA);
	int locationCharB = sentence.indexOf('b');
	System.out.println(locationCharB);
	int locationCharZ = sentence.indexOf('z');
	System.out.println(locationCharZ);
	sentence = sentence.replace('e', 'a');
	System.out.println(sentence);
	System.out.println("Bye for now");
	kb.close();

	
}
}
