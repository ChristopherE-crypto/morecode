package slideexercisechp2;
import java.util.Scanner;
public class Helloworld {

	
	public static void main(String [] args) {
	String s = "Hello Everyone!";
	String s1 = "This is fun.";
	String greet = s +" "+ s1;
	System.out.println(greet + " We have just begun!");
	
	int x = 8; int y = 2;
	
	String clue = "I have "+ x + " legs.";
	
	System.out.print(clue);
	System.out.print(" I have "+ y + " eyes.\n What am I?");
	
	}
}

