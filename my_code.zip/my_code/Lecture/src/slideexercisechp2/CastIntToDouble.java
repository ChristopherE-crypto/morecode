package slideexercisechp2;

public class CastIntToDouble {
public static void main(String [] args) {
	
	int a = 9999999;
	System.out.println("a is "+ a);
	
	int b = 2147483647;
	System.out.println("b is "+ b);
	
	int c = b + 1;
	System.out.println("c is "+c);
	
	long d = (long)(b + 1);
	System.out.println("d is "+d);
	
	long e = (long) 1 + b;
	System.out.println("e is "+ e);
	
	long f = (long) b + 1;
	System.out.println("f is "+f);
	
	
   }
}
