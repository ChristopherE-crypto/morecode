package slideexercisechp2;
import java.util.Scanner;

public class CastIntToDouble2 {
public static void main(String [] args) {
	Scanner kb = new Scanner(System.in);
	System.out.println("Enter the number of pennies");
	final int NUM_OF_PENNIES = kb.nextInt();//run with different amounts 5, 327, 499, 1328, 94, 192
	final int PENNIES_IN_A_DOLLAR = 100;
			double dollarsAndCents = NUM_OF_PENNIES/PENNIES_IN_A_DOLLAR; //no cast
//			double dollarsAndCents = (double)(NUM_OF_PENNIES/PENNIES_IN_A_DOLLAR); 
//			double dollarsAndCents = (double)NUM_OF_PENNIES/PENNIES_IN_A_DOLLAR;
//			double dollarsAndCents = NUM_OF_PENNIES/(double)PENNIES_IN_A_DOLLAR;
//			double dollarsAndCents = (double)NUM_OF_PENNIES/(double)PENNIES_IN_A_DOLLAR;
//			double dollarsAndCents = NUM_OF_PENNIES/100.0; 
	System.out.printf("$%2.2f",dollarsAndCents);
	
	
	
   }
}
