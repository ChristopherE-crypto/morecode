package slideexercisechp2;
import java.util.Scanner;

public class Testing4 {
public static void main(String [] args) {
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("What is your full name?");
	String fullName = scnr.nextLine();
	System.out.println("Nice to meet you, " + fullName + ". Can you guess the number I'm thinking of?");
	int a = scnr.nextInt();
	System.out.printf("You guessed %5d I was thinking of 52.\n", a);
	System.out.println("Guess what color I'm thinking of.");
	String color = scnr.next();
	System.out.println("You guessed " + color + ", I was thinking of blue.");
	System.out.printf("Bye for now %20s. See you next time!", fullName);
	 
	
}
}
