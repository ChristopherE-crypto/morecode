package slideexercisechp2;
import java.util.Scanner;

public class IntegerDivisionandModulo {
public static void main(String [] args) {
	
	final int CENTS_IN_DOLLAR = 100;
	final int CENTS_IN_QUARTER = 25;
	final int CENTS_IN_DIME = 10;
	final int CENTS_IN_NICKEL = 5;
	final int CENTS_IN_PENNY = 1;
	
	Scanner kb = new Scanner(System.in);
	System.out.println("Enter the initial amount in cents");
	final int INITAL_AMOUNT_IN_CENTS = kb.nextInt();
	int cents = INITAL_AMOUNT_IN_CENTS;
	int numDollars = cents / CENTS_IN_DOLLAR;
	cents = cents % CENTS_IN_DOLLAR;
	int numQuarters = cents / CENTS_IN_QUARTER;
	cents = cents % CENTS_IN_QUARTER;
	int numDimes = cents / CENTS_IN_DIME;
	cents = cents % CENTS_IN_DIME;
	int numNickels = cents / CENTS_IN_NICKEL;
	cents = cents % CENTS_IN_NICKEL;
	int numPennies = cents / CENTS_IN_PENNY;
	cents = cents % CENTS_IN_NICKEL;
	
	System.out.printf("%2d cents can be broken down as:\n%2d dollars\n%2d quarters\n%2d dimes\n%2d nickels\n%2d pennies", INITAL_AMOUNT_IN_CENTS,numDollars,numQuarters,numDimes,numNickels,numPennies);
	
	
	
	
     }
}
