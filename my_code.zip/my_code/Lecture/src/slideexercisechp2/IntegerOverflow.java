package slideexercisechp2;

public class IntegerOverflow {
public static void main(String [] args) {
	
	int a = 9999999;
	System.out.println("a is "+ a);
	
	int b = 2147483647;
	System.out.println("b is "+ b);
	
	int c = b + 1;
	System.out.println("c is "+c);
	
    }
}
