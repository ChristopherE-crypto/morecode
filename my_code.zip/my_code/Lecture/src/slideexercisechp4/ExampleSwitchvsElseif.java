package slideexercisechp4;
import java.util.Scanner;


public class ExampleSwitchvsElseif {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("Hi there, enter a letter representing a size.");
	
	
	char shirtSize = scnr.next().charAt(0);
	
	if(shirtSize == 'M'   || shirtSize == 'm') {
		System.out.println("Size Medium.");
	}
	else if(shirtSize == 'L' || shirtSize == 'l') {
		System.out.println("Size Large.");
	}
	else if(shirtSize == 'X' || shirtSize == 'x') {
		System.out.println("Size XLarge.");
	}
	
	
	switch(shirtSize) {
	case 'M':
	case 'm':
		System.out.println("Size Medium");
		break;
	case 'L':
	case 'l':
		System.out.println("Size Large");
		break;
	case 'X':
	case 'x':
		System.out.println("Size XLarge");
		break;
	default:
		System.out.println("One Size Fits All");
		break;
		
		
	}
	
  }
}
