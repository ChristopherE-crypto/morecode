package slideexercisechp4;
import java.util.Random;
import java.util.Scanner;


public class XDguessinggame {

	public static void main(String[] args) {
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("Can you guess the number I'm thinking of?");
	int userGuess = scnr.nextInt();
	
	Random rand = new Random();
	int myRandNum = rand.nextInt(99) + 1;
	
	int diff = Math.abs(myRandNum - userGuess);
	
	if(userGuess < 1 || userGuess > 99) {
	System.out.println("Invalid number.");
	
	if(userGuess == myRandNum) {
		System.out.println("YAY NO DIFF... you guessed correctly.");
		
	}
	else if(userGuess > myRandNum) {
		System.out.println("You guessed above my number " + myRandNum + " by " + diff);
	}
	else {
		System.out.println("You guessed below my number " + myRandNum + " by " + diff);
		
	}
	scnr.close();
	}
	}
}
