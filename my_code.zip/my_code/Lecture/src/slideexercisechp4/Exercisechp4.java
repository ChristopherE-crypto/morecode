package slideexercisechp4;
import java.util.Scanner;
public class Exercisechp4 {
public static void main(String [] args) {
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("Hi there, enter a number.");
	
	int x = scnr.nextInt();
	if(x > 0) {
		
		if(x < 10) {
			System.out.print("the number you entered "+ x + " is a single ");
		
		}
		else if(x < 100) {
			System.out.print("the number you entered "+ x + " is a two ");
		}
		else if(x < 1000) {
			System.out.print("the number you entered "+ x + " is a three ");
		}
		System.out.println("digit positive number.");
	}
	else if(x < 0){
		System.out.println(x + " is Negative");
	}
	
	scnr.close();
   }
}
