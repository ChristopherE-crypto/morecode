import java.util.Arrays;

public class Array {
	
	public static int sum(int [] arr) {//Correct!
		
		int sum = 0;
		
		for(int i = 0; i < arr.length; i++) {
			sum += arr[i];
		}
		return sum;
	}
	
	public static int sum(int [] arr, int firstIndex, int lastIndex) {//Correct!
		
		int sum = 0;
		
		if(firstIndex <= lastIndex && firstIndex > 0 && lastIndex > 0 && lastIndex < arr.length) {
		
			for(int i = firstIndex; i <= lastIndex; i++) {
				sum += arr[i];
			}
			return sum;
		
		}
		
		else {
			return -666;
		}
	}
	
	public static double average(int [] arr) {
		
		double avg = sum(arr) / (double) arr.length;
		
		return avg;
	
	}
	
	public static double average(int [] arr, int firstIndex, int lastIndex) {//Probably correct!
		
		double avg = 0;
		
		if(firstIndex <= lastIndex && firstIndex > 0 && lastIndex > 0 && lastIndex < arr.length) {
		
			int numElements = Math.abs(arr.length - firstIndex - lastIndex - 2);
		
			avg = sum(arr, firstIndex, lastIndex) / (double) numElements;
			
			return avg;
		
			}
		else {
			return -666;
		}
		
	}
	
	public static int maxValue(int [] arr) {//Correct!
		
		int max = Integer.MIN_VALUE;
		
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] > max) {
				max = arr[i];
			}
		}
		
		return max;
	}
	
	public static int maxValue(int [] arr, int firstIndex, int lastIndex) {//Correct!
		
		int max = Integer.MIN_VALUE;
		
		if(firstIndex <= lastIndex && firstIndex > 0 && lastIndex > 0 && lastIndex < arr.length) {
		
			for(int i = firstIndex; i <= lastIndex; i++) {
				if(arr[i] > max) {
					max = arr[i];
				}
			}
		return max;
		}
		else {
			return -666;
		}
	}
	
	public static int indexOfFirstMaxValue(int [] arr) {
		
		int max = Integer.MIN_VALUE;
		
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] > max) {
				max = arr[i];
			}
		}
		
		for(int j = 0; j < arr.length; j++) {
			if(arr[j] == max) {
				return j;
			}
		}
		return 0;
		
	}
	
	public static int indexOfFirstMaxValue(int [] arr, int firstIndex, int lastIndex) {
		
		int max = Integer.MIN_VALUE;
		
		int i;
		
		if(firstIndex <= arr.length && firstIndex <= lastIndex && firstIndex >= 0 && lastIndex > 0 && lastIndex < arr.length) {
		
			for(i = firstIndex; i <= lastIndex; i++) {
				if(arr[i] > max) {
					max = arr[i];
				}
			}
			
			for(int j = firstIndex; j <= lastIndex; j++) {
				if(arr[j] == max) {
					return j;
				}
			}
			
			
		return i;
		}
		else {
			return -1;
		}
	}
	
	public static int numberOfBelowAverageElements(int [] arr) {
		
		int counter = 0;
		
		double avg = average(arr);
		
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] < avg) {
				counter++;
			}
		}
		return counter;
	}
	
	public static int numberOfBelowAverageElements(int [] arr, int firstIndex, int lastIndex) {
		int counter = 0;
		
		double avg = average(arr, firstIndex, lastIndex);
		
		if(firstIndex <= lastIndex && firstIndex > 0 && lastIndex > 0 && lastIndex < arr.length) {
			
			for(int i = firstIndex; i <= lastIndex; i++) {
				if(arr[i] < avg) {
					counter++;
				}
			}
			return counter;
		}
		else {
			return -666;
		}
	}
	
	public static void rotateElements(int [] arr) {
		
		for(int i = 0; i < 1; i++) {
			
			int j, last;
			
			last = arr[arr.length - 1];
			
			for(j = arr.length - 1; j > 0; j--) {
				arr[j] = arr[j - 1];
			}
			arr[0] = last;
		}
		
	}
	
	public static void rotateElements(int [] arr, int rotationCount) {
		
		for(int i = 0; i < rotationCount; i++) {
			
			int j, last;
			
			last = arr[arr.length - 1];
			
			for(j = arr.length - 1; j > 0; j--) {
				arr[j] = arr[j - 1];
			}
			arr[0] = last;
		}
	}
	
	public static void reverseArray(int [] arr) {
		
		for(int i = 0, j = arr.length - 1; i < j; i++, j--) {
			int temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
		}
	}
	
	public static void main(String [] args) {
		
		int [] myArr = {45, 22, 18, 89, 82, 79, 15, 69, 100, 55, 48, 72, 16, 98, 57, 75, 44, 32, 21, 14, 7, 16, 49, 58, 72};
		
		//System.out.println(sum(myArr));
		
		//System.out.println(sum(myArr, 12, 25));
		
		//System.out.println(average(myArr));
		
		//System.out.println(average(myArr, 12, 18));
		
		//System.out.println(maxValue(myArr));
		
		//System.out.println(maxValue(myArr, 12, 18));
		
		//System.out.println(indexOfFirstMaxValue(myArr));
		
		System.out.println(indexOfFirstMaxValue(myArr, 12, 25));
		
		//System.out.println(numberOfBelowAverageElements(myArr));
		
		//System.out.println(numberOfBelowAverageElements(myArr, 12, 18));
		
		//rotateElements(myArr);
		
		//rotateElements(myArr, 5);
		
		//reverseArray(myArr);
		
		//System.out.println(Arrays.toString(myArr));
		
	}

}
