package slideexercisechp5;
import java.util.Scanner;

public class Exampleloopinput {

	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);
		System.out.println("Enter a number between 1 and 10 inclusive.");
		int userGuess = scnr.nextInt();
		while(userGuess < 1 || userGuess > 10) {
			System.out.println("Enter a number between 1 and 10 inclusive.");
			userGuess = scnr.nextInt();
		}
		System.out.println("Thanks you entered " + userGuess + " we can compare your guess against my random number now.");
		
		
scnr.close();
	}

}
