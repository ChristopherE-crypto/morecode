package slideexercisechp1;

public class Helloworld2 {

public static void main(String [] args){
	System.out.println("Hello");
	System.out.println("  Hello World!\tWe are coding! This is cool!!!");
	System.out.println("Wonder Woman said: \"Hello World!\", before raising her sword");
	System.out.println("it is time to battle with the machines!");
	System.out.println("Now we are battling with the machines :-)");
	System.out.println("Did you notice that the 2 last sentences, this one, and the next sentence appear on line 1?");
	System.out.println("The reason is, we used the \"print\" method which doesn't append the new line after the String.");
	System.out.println("We have 1 line before and 2 lines after. We used \"\\n\", since we're using \"print\".");
	System.out.println("Do you see how this sentence is pushed an extra line further down?");
}

}