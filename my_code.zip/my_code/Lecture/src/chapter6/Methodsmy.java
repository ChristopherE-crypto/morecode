package chapter6;

public class Methodsmy {
	public static void printGreeting() {
		
		System.out.println("Hello everyone.");
		
	}
	public static void printGreeting(String name) {
		System.out.println("Hello " + name);
	}
	public static void printSum(int a, int b) {
		int sum = a + b;
		System.out.println("The sum of " + a + " and " + b + " is " + sum);
	}
	
	public static int getValueTripled(int z) {
		int triple = 3 * z;
		return triple;
	}
	
	public static double getHalfTheVal(int a) {
		double val = a / 2.0;
		return val;
	}

}
