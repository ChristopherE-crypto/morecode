package chapter6;

public class Driver {
	public static void main(String [] args) {
		
		Methodsmy.printGreeting("Super Man");
		Methodsmy.printSum(-3, 5);
		
		int result = Methodsmy.getValueTripled(8);
		System.out.println("The result is " + result);
		
		double theResult = Methodsmy.getHalfTheVal(7);
		System.out.println("The result is " + theResult);
	}

}
