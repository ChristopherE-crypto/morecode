
public class LinkedList <E extends KeyedElementInterface<K>, K extends Comparable<? super K>> {
	
	private Node<E,K> head;
	private Node<E,K> tail;
	
	

}
