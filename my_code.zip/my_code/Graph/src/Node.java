
public class Node <E extends KeyedElementInterface<K>, K extends Comparable<? super K>> {
	
	private E element;
	private LinkedList<E,K> adjNodes;
	
	public Node(E element) {
		
		this.element = element;
		this.adjNodes = new LinkedList<E,K>();
	}
	
	public Node(E element, LinkedList<E,K> adjNodes) {
		
		this.element = element;
		this.adjNodes = adjNodes;
	}
	
	public E getElement() {
		
		return this.element;
	}
	
	public LinkedList<E,K> getAdjacentNodes() {
		
		return this.adjNodes;
	}
	
	public void setElement(E element) {
		
		this.element = element;
	}
	
	public void setAdjacentNodes(LinkedList<E,K> adjNodes) {
		
		this.adjNodes = adjNodes;
	}

}
