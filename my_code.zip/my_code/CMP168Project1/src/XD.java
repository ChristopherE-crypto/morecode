
public class XD {

	public static void main(String[] args) {
		Faculty faculty = new Faculty();
		
		Course c1 = new Course(true, 771, "MAT", 4);
		Course c2 = new Course(true, 777, "CMP", 4);
		Course c3 = new Course(true, 711, "CMP", 4);
		Course c4 = new Course(true, 723, "MAT", 4);
		Course cN = null;
		
		Student s1 = new Student();
		Student s2 = new Student();
		
		s1.addCourseTaken(c1);
		s1.addCourseTaken(c2);
		
		Course [] courses = new Course [100];
		
		courses[0] = c1;
		courses[1] = c2;
		courses[2] = c3;
		
		s2.addCoursesTaken(courses);
		
		System.out.println("Number of courses taught before adding anything: " + faculty.getNumCoursesTaught());
		
		faculty.addCourseTaught(c4);
		
		System.out.println("Number of courses taught after adding 1 course: " + faculty.getNumCoursesTaught());
		
		faculty.addCourseTaught(c3);
		
		System.out.println("Number of courses taught after adding 1 course more: " + faculty.getNumCoursesTaught());
		
		faculty.addCoursesTaught(courses);
		
		System.out.println("Number of courses taught after adding an array of courses:" + faculty.getNumCoursesTaught());
		
		faculty.addCourseTaught(c3);
		
		System.out.println("Number of courses taught after adding 1 course more: " + faculty.getNumCoursesTaught());
		
		faculty.addCourseTaught(c3);
		
		System.out.println("Number of courses taught after adding 1 course more: " + faculty.getNumCoursesTaught());
		
		faculty.addCourseTaught(cN);
		
		System.out.println("Number of courses taught after adding 1 null course: " + faculty.getNumCoursesTaught());
		
		System.out.println(s2.compareTo(s1));
		
		System.out.println(faculty.getAllCoursesTaughtAsString());
		
		
		
		

	}

}
