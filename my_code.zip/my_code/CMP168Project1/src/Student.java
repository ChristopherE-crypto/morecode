
public class Student extends Person {
	private static int numStudents;
	private int studentID;
	private Course [] coursesTaken;
	private int numCoursesTaken;
	private boolean isGraduate;
	private String major;
	
	public Student() {
		super();
		studentID = ++numStudents;
		major = "undeclared";
		coursesTaken = new Course [100];
		numCoursesTaken = 0;
		isGraduate = false;
	}
	
	public Student(boolean isGraduate) {
		super();
		this.isGraduate = isGraduate;
		studentID = ++numStudents;
		major = "undeclared";
		coursesTaken = new Course [100];
		numCoursesTaken = 0;
	}
	
	public Student(String major, boolean isGraduate) {
		super();
		this.major = major;
		this.isGraduate = isGraduate;
		studentID = ++numStudents;
		coursesTaken = new Course [100];
		numCoursesTaken = 0;
	}
	
	public Student(String name, int birthYear, String major, boolean isGraduate) {
		super(name, birthYear);
		this.major = major;
		this.isGraduate = isGraduate;
		studentID = ++numStudents;
	}
	
	public boolean isGraduate() {
		return isGraduate;
	}
	
	public int getNumCoursesTaken() {
		return numCoursesTaken;
	}
	
	public static int getNumStudents() {
		return numStudents;
	}
	
	public int getStudentID() {
		return studentID;
	}
	
	public String getMajor() {
		return major;
	}
	
	public void setIsGraduate(boolean isGraduate) {
		this.isGraduate = isGraduate;
	}
	
	public void setMajor(String major) {
		this.major = major;
	}
	
	public void addCourseTaken(Course course) {
		if(numCoursesTaken < coursesTaken.length && course != null) {
			coursesTaken[numCoursesTaken] = course;
			numCoursesTaken++;
		}
	}
	
	public void addCoursesTaken(Course [] course) {
		for(int i = 0, j = 0; i < coursesTaken.length && j < course.length; i++) {
			if(coursesTaken[i] == null) {
				if(course[j] != null) {
					addCourseTaken(course[j++]);
				}
			}
		}
	}
	
	public Course getCourseTaken(int index) {
		if(index >= 0 && index <= numCoursesTaken) {
			return coursesTaken[index];
		}
		else {
			return null;
		}
	}
	
	public String getCourseTakenAsString(int index) {
		if(index >= 0 && index <= numCoursesTaken) {
			return coursesTaken[index].getCourseDept() + "-" + coursesTaken[index].getCourseNum();
		}
		else {
			return "";
		}
	}
	
	public String getAllCoursesTakenAsString() {
		String courses = "";
		for(int i = 0; i < numCoursesTaken; i++) {
			courses += getCourseTakenAsString(i) + ", ";
		}
		return courses;
	}
	
	private boolean compareArrays(Object [] arr, Object [] arr2) {
		boolean equals = false;
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] == arr2[i]) {
				equals = true;
			}
			else {
				equals = false;
			}
		}
		return equals;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null) {return false;}
		if(this == obj) {return true;}
		if(obj instanceof Student) {
			Student otherS = (Student) obj;
				if(super.equals(otherS)) {
					if(major.equals(otherS.major)) {
						if(isGraduate == otherS.isGraduate) {
							if(numCoursesTaken == otherS.numCoursesTaken) {
								if(compareArrays(coursesTaken, otherS.coursesTaken)) {
									return true;
								}
							}
						}
					}
				}
			}
		return false;
	}
	
	@Override
	public String toString() {
		String is = "Graduate";
		String isNot = "Undergraduate";
		if(isGraduate) {
			return super.toString() + String.format(" Student: studentID: %04d | Major %20s | %14s | Number of Courses Taken: %3d | Courses Taken: %s", studentID, major, is, numCoursesTaken, getAllCoursesTakenAsString());
		}
		else {
			return super.toString() + String.format(" Student: studentID: %04d | Major %20s | %14s | Number of Courses Taken: %3d | Courses Taken: %s", studentID, major, isNot, numCoursesTaken, getAllCoursesTakenAsString());
		}
	}
	
	private int addCredits(Course [] courses) {
		int total = 0;
		for(int i = 0; i < numCoursesTaken; i++) {
			total += courses[i].getNumCredits();
		}
		return total;
	}
	
	public int compareTo(Student s) {
		int parentVal = super.compareTo(s);
		if(s instanceof Student) {
			if(parentVal > 0) {
				if(this.addCredits(coursesTaken) > ((Student)s).addCredits(coursesTaken)) {
					return 1;
				}
			}
			else if(parentVal < 0) {
				if(this.addCredits(coursesTaken) < ((Student)s).addCredits(coursesTaken)) {
					return -1;
				}
			}
			return 0;
		}
		return parentVal;
	}
	

}
