import java.io.*;

public class Driver_SchoolDB {
	
	public static void main(String [] args) {
		Course c1 = new Course(true, 771, "MAT", 4);
		Course c2 = new Course(true, 777, "CMP", 4);
		Course c3 = new Course(true, 711, "CMP", 4);
		Course c4 = new Course(true, 723, "MAT", 4);
		Course c5 = new Course(false, 168, "CMP", 4);
		Course c6 = new Course(false, 338, "CMP", 4);
		
		Faculty f1 = new Faculty();
		Faculty f2 = new Faculty(true);
		Faculty f3 = new Faculty("MAT", false);
		Faculty f4 = new Faculty("Superman", 1938, "PHY", true);
		
		Student s1 = new Student();
		Student s2 = new Student(false);
		Student s3 = new Student("Math", false);
		Student s4 = new Student("Wonderwoman", 1941, "JST", true);
		
		GeneralStaff g1 = new GeneralStaff();
		GeneralStaff g2 = new GeneralStaff("advise students");
		GeneralStaff g3 = new GeneralStaff("Sanitation", "clean");
		GeneralStaff g4 = new GeneralStaff("Flash Gordon", 1934, "Security", "safety");
		
		//Learned from this video: https://www.youtube.com/watch?v=hgF21imQ_Is
		
		try {
			BufferedReader br = new BufferedReader(new FileReader("SchoolDB_Initial.txt"));
			String s;
			while((s = br.readLine()) != null) {
				System.out.println(s);
			}
			br.close();
		}
		catch(Exception ex){
			return;
		}
		
		System.out.println();
		
		System.out.println("**************************************************************");
		
		System.out.println("SCHOOL DATABASE INFO:");
		
		System.out.println();
		
		System.out.println("************************************************");
		
		System.out.println("COURSES:");
		
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
	    System.out.println(c4);
		System.out.println(c5);
		System.out.println(c6);
		
		System.out.println("************************************************");
		System.out.println("************************************************");
		
		System.out.println("PERSONS:");
		System.out.println("************************************************");
		System.out.println("************************************************");
		
		System.out.println("EMPLOYEES:");
		System.out.println("************************************************");
		System.out.println("************************************************");
		
		System.out.println("GENERAL STAFF:");
		
		System.out.println(g1);
		System.out.println(g2);
		System.out.println(g3);
		System.out.println(g4);
		
		System.out.println("************************************************");
		System.out.println("************************************************");
		
		System.out.println("FACULTY:");
		
		System.out.println(f1);
		System.out.println(f2);
		System.out.println(f3);
		System.out.println(f4);
		
		System.out.println("************************************************");
		System.out.println("************************************************");
		
		System.out.println("STUDENTS:");
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s4);
		
		System.out.println("************************************************");
		System.out.println("**************************************************************");
		
		System.out.println();
		
		
	}

}
