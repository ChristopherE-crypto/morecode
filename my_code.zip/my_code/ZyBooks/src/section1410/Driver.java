package section1410;

import javax.swing.JFrame;

public class Driver {

	public static void main(String[] args) {
		SeatReservationFrame myFrame = new SeatReservationFrame();

	      myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      myFrame.pack();
	      myFrame.setVisible(true);

	}

}
