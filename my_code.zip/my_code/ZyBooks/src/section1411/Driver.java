package section1411;

import javax.swing.JFrame;

public class Driver {

	public static void main(String[] args) {
		FileReadFrame myFrame = new FileReadFrame();

	      myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      myFrame.pack();
	      myFrame.setVisible(true);

	}

}
