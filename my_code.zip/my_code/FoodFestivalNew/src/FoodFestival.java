import java.util.ArrayList;
import java.util.Scanner;

public class FoodFestival {
	
	public static int displayAppetizerMenu() {
		Scanner scan = new Scanner(System.in);
		System.out.println("0 - Nothing\n1 - Ramen\n2 - Empanada\n3 - Caesar Salad");
		int option = scan.nextInt();
		return option;
	}
	
	public static String selectAppetizer(int selection) {
		String order = "";
		if(selection == 0) {
			return order;
		}
		else if(selection == 1) {
			return order = "Ramen";
		}
		else if(selection == 2) {
			return order = "Empanada";
		}
		else {
			return order = "Caesar Salad";
		}
	}
	
	public static int displayMainMenu() {
		Scanner scan = new Scanner(System.in);
		System.out.println("0 - Exit\n1 - Appetizers\n2 - Main Course\n3 - Dessert");
		int option = scan.nextInt();
		return option;
	}
	
	public static void main(String [] args) {
		String name;
		ArrayList <String> order = new ArrayList();
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Welcome to the food festival\nWould you like to place an order?");
		String response = scnr.next();
		if(response.equalsIgnoreCase("No")) {
			System.out.println("See you next time!");
			System.exit(0);
		}
		if(response.equalsIgnoreCase("Yes")) {
			System.out.println("What is the name for your order?");
			name = scnr.next();
			
			System.out.println("Here's the main menu " + name);
			
			int option = displayMainMenu();
			
			if(option == 0) {
				System.out.println("No order\nExiting application...");
				System.exit(0);
			}
			
			else if(option == 1) {
					int app = displayAppetizerMenu();
					
					while(app != 0) {
						order.add(selectAppetizer(app));
						app = displayAppetizerMenu();
					}
				}
			
			
			
			
			
		}
			
		
	}

}
