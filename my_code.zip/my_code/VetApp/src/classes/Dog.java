package classes;

public class Dog extends Animal {
	
	private String breed;
	private int age;

	public Dog(String name, double weight, double height, String breed, int age) throws Exception {
		
		super(name, weight, height);
		this.breed = breed;
		
		if(age <= 0) {
			
			throw new Exception("INVALID AGE");
		}
		
		this.age = age;
	}
	
	public String getBreed() {
		
		return this.breed;
	}
	
	public int getAge() {
		
		return this.age;
	}
	
	public void setBreed(String breed) {
		
		this.breed = breed;
	}
	
	public void setAge(int age) throws Exception {
		
		if(age <= 0) {
			
			throw new Exception("INVALID AGE");
		}
		
		this.age = age;
	}
	
	

}
