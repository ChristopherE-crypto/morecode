package classes;

public class Animal {
	
	private double weight;
	private double height;
	private String name;
	
	public Animal(String name, double weight, double height) throws Exception {
		
		this.name = name;
		
		if(weight <= 0) {
			
			throw new Exception("INVALID WEIGHT");
		}
		
		this.weight = weight;
		
		if(height <= 0) {
			
			throw new Exception("INVALID HEIGHT");
		}
		
		this.height = height;
	}
	
	public String getName() {
		
		return this.name;
	}
	
	public double getWeight() {
		
		return this.weight;
	}
	
	public double getHeight() {
		
		return this.height;
	}
	
	public void setWeight(double weight) throws Exception {
		
		if(weight <= 0) {
			
			throw new Exception("INVALID WEIGHT");
		}
		
		this.weight = weight;
	}
	
	public void setHeight(double height) throws Exception {
		
		if(height <= 0) {
			
			throw new Exception("INVALID HEIGHT");
		}
		
		this.height = height;
	}
	
	@Override
	public String toString() {
		
		return "| NAME : " + this.name + " | WEIGHT : " + this.weight + " | HEIGHT : " + this.height + " |";
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if(obj == null) {
			
			return false;
		}
		
		if(this == obj) {
			
			return true;
		}
		
		if(obj instanceof Animal) {
			
			Animal otherAnimal = (Animal)obj;
			
			if(this.name.equalsIgnoreCase(otherAnimal.name)) {
				
				if(Math.abs(this.weight - otherAnimal.weight) <= 0.2) {
					
					if(Math.abs(this.height - otherAnimal.height) <= 0.2) {
						
						return true;
					}
				}
			}
		}
		
		return false;
	}

}
