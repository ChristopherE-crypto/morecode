import java.util.Scanner;

public class HelloWorld {
	
	public static void main(String [] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		int userNum;
		int userNum2;
		int answer = 0;
		
		String sign;
		
		System.out.println("Enter a number : ");
		userNum = scnr.nextInt(); // Create a variable and store the input inside the variable
		
		System.out.println("Enter another number : ");
		userNum2 = scnr.nextInt();
		
		System.out.println("Enter an operation : ");
		sign = scnr.next(); // Compare sign with +, -, *, /
		
		if(sign.equals("+")) { // If the user wants to add the 2 numbers, then this code executes!
			answer = userNum + userNum2;
		}
		
		if(sign.equals("-")) {
			answer = userNum - userNum2;
		}
		
		if(sign.equals("*")) {
			answer = userNum * userNum2;
		}
		
		if(sign.equals("/")) {
			answer = userNum / userNum2;
		}
		
		System.out.println("The result is " + answer);
		
		scnr.close();
		
		
		
		
	}

}
