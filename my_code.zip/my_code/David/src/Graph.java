
public class Graph {
	
	public Node upLeft;
	public Node upRight;
	public Node downLeft;
	public Node downRight;
	
	public Node upMiddle; 
	public Node leftMiddle; 
	public Node middle;
	public Node rightMiddle;
	public Node downMiddle;
	
	private class Node {
		
		private int data;
		private boolean on;
		private Node up;
		private Node down;
		private Node right;
		private Node left;
		
		public Node(int data, boolean on) {
			
			this.data = data;
			this.on = on;
			
			this.up = null;
			this.down = null;
			this.right = null;
			this.left = null;
		}
		
		public int getData() {
			
			return this.data;
		}
		
		public void setUp(Node up) {
			
			this.up = up;
		}
		
		public void setDown(Node down) {
			
			this.down = down;
		}
		
		public void setRight(Node right) {
			
			this.right = right;
		}
		
		public void setLeft(Node left) {
			
			this.left = left;
		}
	}
	
	public Graph() {
		
		Node upLeft = new Node(1, false);
		Node upRight = new Node(3, false);
		Node downLeft = new Node(7, false);
		Node downRight = new Node(9, false);
		
		Node upMiddle = new Node(2, false);
		Node leftMiddle = new Node(4, false);
		Node middle = new Node(5, false);
		Node rightMiddle = new Node(6, false);
		Node downMiddle = new Node(8, false);
		
		upLeft.setRight(upMiddle);
		upLeft.setDown(leftMiddle);
		upMiddle.setLeft(upLeft);
		upMiddle.setRight(upRight);
		upMiddle.setDown(middle);
		upRight.setLeft(upMiddle);
		upRight.setDown(rightMiddle);
		leftMiddle.setUp(upLeft);
		leftMiddle.setDown(downLeft);
		leftMiddle.setRight(middle);
		middle.setUp(upMiddle);
		middle.setDown(downMiddle);
		middle.setLeft(leftMiddle);
		middle.setRight(rightMiddle);
		rightMiddle.setUp(upRight);
		rightMiddle.setLeft(middle);
		rightMiddle.setDown(downRight);
		downLeft.setUp(leftMiddle);
		downLeft.setRight(downMiddle);
		downMiddle.setUp(middle);
		downMiddle.setLeft(downLeft);
		downMiddle.setRight(downRight);
		downRight.setUp(rightMiddle);
		downRight.setLeft(downMiddle);
		
		
	}
	
	@Override
	public String toString() {
		
		Graph g = new Graph();
		
		return "" + g.upLeft.getData() + "<-->" + g.upMiddle.getData() + "<-->" + g.upRight.getData();
	}
	
	public static void main(String [] args) {
		
		Graph g = new Graph();
		
		System.out.println(g.toString());
	}

}
