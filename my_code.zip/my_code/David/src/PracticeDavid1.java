import java.util.Scanner;
public class PracticeDavid1 {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		
		int number = 5;
		
		System.out.println("Enter a number : ");
		
		int myVal = scnr.nextInt();
		
		if((myVal + number) == 12 || myVal > number) {
			System.out.println("YOOOOOOOOOOOOO");
		}
		else {
			System.out.println("XDDDDDDDDDDDD");
		}

	}

}
