import java.util.Scanner;

public class Grades {
	
	public static void main(String [] args) {
		
		int gradeA = 0;
		int gradeAMinus = 0;
		int gradeBPlus = 0;
		int gradeB = 0;
		int gradeBMinus = 0;
		int gradeCPlus = 0;
		int gradeC = 0;
		int gradeCMinus = 0;
		int gradeD = 0;
		int gradeF = 0;
		
		
		Scanner scnr = new Scanner(System.in);
		
		int counter = 0;
		
		System.out.println("Enter a grade: ");
		int grade = scnr.nextInt();
		
		if(grade >= 93 && grade <= 100) {
			gradeA++;
		}
		if(grade >= 90 && grade < 93) {
			gradeAMinus++;
		}
		if(grade >= 87 && grade < 90) {
			gradeBPlus++;
		}
		if(grade >= 83 && grade < 87) {
			gradeB++;
		}
		if(grade >= 80 && grade < 83) {
			gradeBMinus++;
		}
		if(grade >= 77 && grade < 80) {
			gradeCPlus++;
		}
		if(grade >= 73 && grade < 77) {
			gradeC++;
		}
		if(grade >= 70 && grade < 73) {
			gradeCMinus++;
		}
		if(grade >= 60 && grade < 70) {
			gradeD++;
		}
		if(grade >= 0 && grade < 60) {
			gradeF++;
		}
		
		
		while(grade > 0) {
			System.out.println("Enter a grade: ");
			grade = scnr.nextInt();
			counter++;
			
			if(grade >= 93 && grade <= 100) {
				gradeA++;
			}
			if(grade >= 90 && grade < 93) {
				gradeAMinus++;
			}
			if(grade >= 87 && grade < 90) {
				gradeBPlus++;
			}
			if(grade >= 83 && grade < 87) {
				gradeB++;
			}
			if(grade >= 80 && grade < 83) {
				gradeBMinus++;
			}
			if(grade >= 77 && grade < 80) {
				gradeCPlus++;
			}
			if(grade >= 73 && grade < 77) {
				gradeC++;
			}
			if(grade >= 70 && grade < 73) {
				gradeCMinus++;
			}
			if(grade >= 60 && grade < 70) {
				gradeD++;
			}
			if(grade >= 0 && grade < 60) {
				gradeF++;
			}
		}
		
		System.out.println("Total number of grades = " + counter);
		System.out.println("Number of A's = " + gradeA);
		System.out.println("Number of A-'s = " + gradeAMinus);
		System.out.println("Number of B+'s = " + gradeBPlus);
		System.out.println("Number of B's = " + gradeB);
		System.out.println("Number of B-'s = " + gradeBMinus);
		System.out.println("Number of C+'s = " + gradeCPlus);
		System.out.println("Number of C's = " + gradeC);
		System.out.println("Number of C-'s = " + gradeCMinus);
		System.out.println("Number of D's = " + gradeD);
		System.out.println("Number of F's = " + gradeF);
		
		
	}

}
