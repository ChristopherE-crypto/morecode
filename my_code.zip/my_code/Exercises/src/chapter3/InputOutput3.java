package chapter3;

import java.util.Scanner;

public class InputOutput3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Program that takes in Strings from the user and stores them in an array and then print them to the screen.
		 * Does not need to add the "Enter Done to exit" because it only stores up to the number of items you entered. Ask the user for the number of items. */
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Welcome to Food Inc.\nPlease enter the number of items you are buying: ");
		int number = scnr.nextInt(); //Takes the number of items from the user which later can be used to set the array's length.
		
		String [] food = new String [number];
		
		for(int i = 0; i < food.length; i++) {
			System.out.println("Enter your item: ");
			food[i] = scnr.next();
		}
		for(int i = 0; i < food.length; i++) {
			System.out.println("Here's the items you are buying: ");
			System.out.println(food[i]);
		}
		
		System.out.println("Thank you!");
			
		
		
		
		
		

	}

}
