package chapter3;
import java.util.Scanner;

public class InputOutput1 {
	public static void main(String [] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Hello. Can you guess the number I�m thinking of?");
		int a = scanner.nextInt();
		System.out.printf("You guessed %5d I was thinking of 67.\n", a);
		scanner.nextLine(); //uncomment so the user�s input can be read in instead of skipped over
		System.out.println("What is your full name?");
		String fullName = scanner.nextLine();	
		System.out.println("Nice to meet you, "+fullName+", see you next time!");
		scanner.close();

	}

}
