package chapter3;

import java.util.Scanner;

public class InputOutput2 {
	public static void main(String [] args) {
		
		Scanner kb = new Scanner(System.in);
		int hour, minute,seconds;
		final int NUM_OF_SECS_IN_12H = 43200;
		final int NUM_OF_SECS_IN_24H = 86400;
		int totalAmountOfSecs;
		System.out.println("What is the hour of the day? [Use a 24 hour clock (8am is 8, 2pm is 14)]");
		hour = kb.nextInt();
		System.out.println("What is the minute of the hour? ");
		minute = kb.nextInt();
		System.out.println("What is the seconds of the minute? ");
		seconds = kb.nextInt();
		
		totalAmountOfSecs = (hour * 3600) + (minute * 60) + seconds;
		
		int x = NUM_OF_SECS_IN_12H - totalAmountOfSecs;
		int y = NUM_OF_SECS_IN_24H - totalAmountOfSecs;
		System.out.printf("The current time is %02d:%02d:%02d\n",hour,minute,seconds);
		System.out.println("The number of seconds since midnight is: " + Math.abs(x));
		System.out.println("The number of seconds remaining in the day is: " + Math.abs(y));

	}

}
