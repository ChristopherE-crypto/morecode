package chapter1;

public class HelloWorld {
	public static void main(String [] args) {
		
		System.out.println("Hello");
		System.out.println("Hello World!\tWe are coding! This is cool!!!");
		System.out.println("Wonder Woman said: \"Hello World!\", before raising her sword");
		System.out.println("It is time to battle with the machines!");
		System.out.println("Now we are battling with the machines :-) ");
		System.out.println("Did you notice that the 2 last sentences, this one, and the next sentence appear on 1 line?");
		System.out.println("The reason is, we used the \"print\" method which doesn�t append the new line after the String.");
		System.out.print("We have 1 line before and 2 lines after. We used \"\\n\", since we�re using \"print\". \n");
		System.out.println("Do you see how this sentence is pushed an extra line further down?");
		System.out.println("I want to create an A.I.");
		System.out.println("I am doing all this stuff to practice.");
		System.out.println("I want to get better at coding.");
		System.out.println("Practicing with\t tabs.");
		System.out.println("Lmao\\ moment");

	}//Writen by Chris E.

}
/*This program prints random stuff I don't know what else to put*/