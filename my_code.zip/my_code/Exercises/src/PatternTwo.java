import java.util.Scanner;

public class PatternTwo {
	
	public static void main(String [] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Please enter a number 1...9 : ");
		int n = scnr.nextInt();
		
		for(int j = 1; j <= n; j++) {
			System.out.print(" ");
			
		    for(int i = n; i >= 1; i--) {
		    	if(i > j) {
			      System.out.print(" ");
		    	}
		    	else {
		    	  System.out.print(i);
		    	}
		    	
		    	
		     }
		System.out.println();
		}
		
	}

}
