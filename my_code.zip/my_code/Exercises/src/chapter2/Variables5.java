package chapter2;

public class Variables5 {
	public static void main(String [] args) {
		
		String greeting = "What's up my G!";
		System.out.println(greeting);
		final char SPACE_CHARACTER = ' ';
		int locationOf_e = greeting.indexOf('e');
		int locationOfSpace = greeting.indexOf(SPACE_CHARACTER);
		int numCharsInGreeting = greeting.length();
		String greetingAsUpper = greeting.toUpperCase();
		System.out.println("Index of 'e' is "+locationOf_e);
		System.out.println("Index of the space character is "+locationOfSpace);
		System.out.println("Let's yell the greeting: " + greetingAsUpper);
		greeting = greeting.replace('e', 'a');
		System.out.println(greeting);
		System.out.println("The greeting is "+numCharsInGreeting+" characters long");

	}

}
