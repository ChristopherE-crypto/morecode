package chapter2;
import java.util.Scanner;

public class Variables6 {
	public static void main(String [] args) {
		
		Scanner kb = new Scanner(System.in);
		System.out.println("In 1 sentence, tell me what is on your mind.");
		String sentence = kb.nextLine();//retrieve input from the user�s keyboard entry
		System.out.println("You said: " + sentence);
		char firstChar = sentence.charAt(0);
		System.out.println("The first character of your sentence is " + firstChar);
		char lastChar = sentence.charAt(sentence.length()-1);
		System.out.println("The last character of your sentence is " + lastChar);
		String upC = sentence.toUpperCase();
		System.out.println("Your sentence all uppercase is " + upC);
		int a = sentence.indexOf('a');
		System.out.println("Your sentence contains/does not contain the character a is at location: " + a);
		sentence = sentence.replace('a', 'e');
		System.out.println(sentence);
		System.out.println("Bye for now");
		kb.close();

	}

}
