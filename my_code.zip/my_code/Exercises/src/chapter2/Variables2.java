package chapter2;

public class Variables2 {
	public static void main(String [] args) {
		
		int a = 9999999;
		System.out.println("a is "+a); 

		int b = 2147483647;
		System.out.println("b is "+b);    

		int c = b + 1;
		System.out.println("c is "+c);    

		
		
		long d = (long) (b + 1); 
		System.out.println("d is "+d);    //incorrect sum is displayed

		
		long e = a + (long) 1 ;
		System.out.println("e is "+e);    //correct sum is displayed

		
		long f = (long) b + 1 ;
		System.out.println("f is "+f);    //correct sum is displayed

	}

}
