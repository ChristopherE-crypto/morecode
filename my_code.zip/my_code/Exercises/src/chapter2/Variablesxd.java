package chapter2;

public class Variablesxd {
	public static void main(String [] args) {
		
		int a = 9999999;
		System.out.println("a is "+a); //correct value displayed since it is within range

		int b = 2147483647;
		System.out.println("b is "+b);    //correct value displayed since it is within range

		int c = b + 1;
		System.out.println("c is "+c);    //incorrect value displayed since it is NOT within range

	}

}
