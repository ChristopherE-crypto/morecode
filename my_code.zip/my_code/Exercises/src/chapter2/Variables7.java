package chapter2;
import java.util.Random;

public class Variables7 {
	public static void main(String [] args) {
		
		Random rand = new Random();
		
		int randNum = rand.nextInt(501) + 1;
		
		System.out.println("A random number between 1 and 500 inclusive is: " + randNum);
		
		randNum = 2 * randNum;
		
		System.out.println("The double of the random number is: " + randNum);
		
		randNum = (int)Math.pow(randNum, 2);
		
		System.out.println("The random number squared is: " + randNum);
		
		randNum = (int)Math.sqrt(randNum);
		
		System.out.println("The square root of the random number is: " + randNum);
	}

}
