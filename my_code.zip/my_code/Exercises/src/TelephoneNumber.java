import java.util.Scanner;

public class TelephoneNumber {

	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Please enter a telephone number using letters: ");
		String phrase = scnr.nextLine();
		phrase = phrase.replaceAll("\\s", "");
		
		if(phrase.length() > 7) {
			phrase = phrase.substring(0, 7);
		}
		
		
		for(int i = 0; i < phrase.length(); i++) {
			
			if(i == 3) {
				phrase = phrase.substring(0, 3) + "-" + phrase.substring(3, phrase.length());
				
			}
			
			if(phrase.charAt(i) == 'a' || phrase.charAt(i) == 'A' || phrase.charAt(i) == 'b' || phrase.charAt(i) == 'B' || phrase.charAt(i) == 'c' || phrase.charAt(i) == 'C') {
				phrase = phrase.replace(phrase.charAt(i), '2');
				
			}
			
			if(phrase.charAt(i) == 'd' || phrase.charAt(i) == 'D' || phrase.charAt(i) == 'e' || phrase.charAt(i) == 'E' || phrase.charAt(i) == 'f' || phrase.charAt(i) == 'F') {
				phrase = phrase.replace(phrase.charAt(i), '3');
				
			}
			
			if(phrase.charAt(i) == 'g' || phrase.charAt(i) == 'G' || phrase.charAt(i) == 'h' || phrase.charAt(i) == 'H' || phrase.charAt(i) == 'i' || phrase.charAt(i) == 'I') {
				phrase = phrase.replace(phrase.charAt(i), '4');
				
			}
			
			if(phrase.charAt(i) == 'j' || phrase.charAt(i) == 'J' || phrase.charAt(i) == 'k' || phrase.charAt(i) == 'K' || phrase.charAt(i) == 'l' || phrase.charAt(i) == 'L') {
				phrase = phrase.replace(phrase.charAt(i), '5');
				
			}
			
			if(phrase.charAt(i) == 'm' || phrase.charAt(i) == 'M' || phrase.charAt(i) == 'n' || phrase.charAt(i) == 'N' || phrase.charAt(i) == 'o' || phrase.charAt(i) == 'O') {
				phrase = phrase.replace(phrase.charAt(i), '6');
				
			}
			
			if(phrase.charAt(i) == 'p' || phrase.charAt(i) == 'P' || phrase.charAt(i) == 'q' || phrase.charAt(i) == 'Q' || phrase.charAt(i) == 'r' || phrase.charAt(i) == 'R' || phrase.charAt(i) == 's' || phrase.charAt(i) == 'S') {
				phrase = phrase.replace(phrase.charAt(i), '7');
				
			}
			
			if(phrase.charAt(i) == 't' || phrase.charAt(i) == 'T' || phrase.charAt(i) == 'u' || phrase.charAt(i) == 'U' || phrase.charAt(i) == 'v' || phrase.charAt(i) == 'V') {
				phrase = phrase.replace(phrase.charAt(i), '8');
				
			}
			
			if(phrase.charAt(i) == 'w' || phrase.charAt(i) == 'W' || phrase.charAt(i) == 'x' || phrase.charAt(i) == 'X' || phrase.charAt(i) == 'y' || phrase.charAt(i) == 'Y' || phrase.charAt(i) == 'z' || phrase.charAt(i) == 'Z') {
				phrase = phrase.replace(phrase.charAt(i), '9');
				
			}
		}
		
		
		System.out.println(phrase);
		

	}

}
