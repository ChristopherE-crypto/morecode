package lab1;

import java.util.Scanner;

public class Homework2 {
public static void main(String [] args) {
	Scanner scnr = new Scanner(System.in);

	
	
	System.out.print("Enter firstInt: " );
    int firstInt = scnr.nextInt();
	System.out.print("Enter secondInt: ");
	int secondInt = scnr.nextInt();
	System.out.print("Enter thirdInt: ");
	int thirdInt = scnr.nextInt();
	
	
	int firstResult = ((firstInt + secondInt) / thirdInt);
	System.out.println("First Result = " + firstResult);
	int secondResult = ((secondInt * thirdInt) / (secondInt + firstInt));
	System.out.println("Second Result = " + secondResult);
	int thirdResult = ((firstInt * thirdInt) % secondInt);
	System.out.println("Third Result = " + thirdResult);
	
	//Homework 2-1 Used basic stuff.
	
	
	
	
     }
}
