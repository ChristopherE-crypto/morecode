package lab1;
import java.util.Scanner;
import java.lang.Math;
import java.lang.Math;
public class Homework23 {
public static void main(String [] args) {
	
Scanner scnr = new Scanner(System.in);
	
	System.out.println("Enter radius: ");
	double r = scnr.nextDouble();
	
double a = 3;	
double cC = 2 * Math.PI * r;
double cA = Math.PI * Math.pow(r, 2);
double sA = 4 * Math.PI * Math.pow(r, 2);
double sV = (4 / a ) * (Math.PI * Math.pow(r, 3));

System.out.println("Circle Circumference = " + cC);
System.out.println("Circle Area = " + cA);
System.out.println("Sphere Area = " + sA);
System.out.printf("Sphere Volume = %.10f",sV);

//Homework 2-3 I had to declare 3 as a double so the division of 4/3 would give me the right answer. 
	
}
}
