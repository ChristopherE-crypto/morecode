package lab1;

public class xdxd {

	public static void main(String[] args) {
		
		pp message = () -> {
			System.out.println("hello mf");
		};

	}

}

interface pp {
	void message();
}
