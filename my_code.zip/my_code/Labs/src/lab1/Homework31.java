package lab1;
import java.util.Scanner;

public class Homework31 {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner (System.in);
	
	double celsiusT;
	double fahrenheitT;
	
	System.out.println("Enter the temperature in degree celsius: ");
	celsiusT = scnr.nextDouble();
	
	fahrenheitT = (celsiusT * (double)(9)/5) + 32;
	
	System.out.printf("%.1f C = %.1f F",celsiusT,fahrenheitT);
	
	
	
	scnr.close();
	
	//Homework 3-1 I need to memorize the formatting thing.  
    }
}
