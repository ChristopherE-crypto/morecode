package lab1;
import java.util.Scanner;

public class Homework33 {
public static void main(String [] args) {
	
Scanner scnr = new Scanner(System.in);

int numQuarters;
int numDimes;
int numNickels;
int numPennies;
double totalDollars;

final int PENNIES_IN_QUARTERS = 25;
final int PENNIES_IN_DIMES = 10;
final int PENNIES_IN_NICKELS = 5;
final int PENNIES_IN_PENNIES = 1;

System.out.print("Enter the number of quarters: ");
numQuarters = scnr.nextInt();

System.out.print("Enter the number of dimes: ");
numDimes = scnr.nextInt();

System.out.print("Enter the number of nickels: ");
numNickels = scnr.nextInt();

System.out.print("Enter the number of pennies: ");
numPennies = scnr.nextInt();

System.out.printf("You entered:\n %d quarters\n %d dimes\n %d nickels\n %d pennies\n", numQuarters, numDimes, numNickels, numPennies);

int a = numQuarters * PENNIES_IN_QUARTERS;
int b = numDimes * PENNIES_IN_DIMES;
int c = numNickels * PENNIES_IN_NICKELS;
int d = numPennies * PENNIES_IN_PENNIES;

totalDollars = (a + b + c + d) / (double)100;

System.out.printf("The total in dollars is $%.2f", totalDollars);

scnr.close();
//Homework 3-3 Liked working on it.
	
  }
}
