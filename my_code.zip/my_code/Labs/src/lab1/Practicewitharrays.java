package lab1;
import java.util.Scanner;

public class Practicewitharrays {

	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		int [] scores = {82, 66, 56, 45, 77, 99, 10, 56, 21, 45, 70};
		
		int [] scores2 = new int [scores.length];
		for(int i = 0; i < scores.length; i++) {
			scores2[i] = scores[i];
		}
		
		for(int i = 0; i < scores.length; i++) {
			System.out.print(scores2 [i] + ", ");
		}
		
		//String vals = scores.toString();
		
		//boolean flag = false;
		
		//int [] a = {8, -5, 2, -1, 7, 3};
		//int [] b = {-5, -4, -1, 2, 3, 7, 8};
		
		//for(int i = 0; i < a.length; i++) {
			
			//if(a [i] == 3) {
			//	flag = true;
			//	System.out.println("The index is: " + i);
			//	break;
			//}
		//}
		
		//if(flag == false) {
		//	System.out.println("The element is not in the list!");
		//}
		//----------------------------------------------------------------------------------------------------------------------
		
		//System.out.println("Enter the number of inputs: ");
		//int n = scnr.nextInt();
		
		//int [] a = new int [n];
		
		//for(int i = 0; i < a.length; i++) {
		//System.out.println("Enter an integer value: ");
		//a [i] = scnr.nextInt();
		//}
		
		//for(int i = 0; i < a.length; i++) {
			
		//System.out.print(a [i] + ", ");
		//}
		
		
		
		//int [] a = {5, 2, 0, -1, 9, -5, 8, 7, 3, 6, -2};
		
		//-----------------------------------------------------------------------------------------------------------
		//int [] a = {5, 2, 0, -1, 9, -5};
		//int [] b = {5, 2, 0, -1, 9, 4};
		//boolean flag = true;
		//if(a.length != b.length) {
			//System.out.println("Arrays are not the same.");
			//flag = false;
		//}
		//else {
			//for(int i = 0; i < a.length; i++) {
			//	if(a [i] != b [i]) {
			//		flag = false;
			//		break;
			//	}
			//}
		//}
		//if(flag == false) {
		//	System.out.println("Not the same!");
		//}
		//else {
		//	System.out.println("Same arrays!");
		//}
		
		//----------------------------------------------------------------------------------------------------------------------
		
		//for(int i = 0; i < a.length; i++) {
			//for(int j = i; j < a.length; j++) {
				//for(int k = 0; k < a.length; k++) {
				//	if(i != j && j != k && i != k && a [i] + a[j] + a[k] == 1) {
				//		System.out.println("(" + a[i] + ", " + a[j] + ", " + a[k] + ")");
				//	}
				//}
				
			//}
		}
		//int counter = 0;
		//for(int i = 0; i < a.length; i++) {
			
			//if(a [i] > 0) {
				//counter += 1;
			//}
		//}
		
		//System.out.println("The number of positive integers is: " + counter);
		
	}


