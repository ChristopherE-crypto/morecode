package lab1;

import java.util.Scanner;
import java.math.BigDecimal;
import java.math.RoundingMode;
public class yikes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scnr = new Scanner(System.in);
		
		System.out.print("Enter number of Eastern Caribbean Dollars :");
		BigDecimal ecd = scnr.nextBigDecimal();
		System.out.print("Enter number of Dominican Pesos :");
		BigDecimal dp = scnr.nextBigDecimal();
		System.out.print("Enter number of Brazilian Reals :");
		BigDecimal br = scnr.nextBigDecimal();
		
		BigDecimal a = new BigDecimal(0.37);
		BigDecimal b = new BigDecimal(0.019);
		BigDecimal c = new BigDecimal(0.239);
		
		BigDecimal x = ecd.multiply(a);
		BigDecimal y = dp.multiply(b);
		BigDecimal z = br.multiply(c);
		
		BigDecimal a1 = x.add(y);
		BigDecimal s = z.add(a1);
		
		BigDecimal f = (s).setScale(2, RoundingMode.HALF_UP);
		
		System.out.print(f);
		
		//1.13 Homework 1-1. Used BigDecimal and RoundingMode. 
		
		
		
	}

	

}
