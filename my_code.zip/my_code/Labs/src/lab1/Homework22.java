package lab1;
import java.util.Scanner;

public class Homework22 {
public static void main(String [] args) {
Scanner scnr = new Scanner(System.in);

int numYards;
int numFeet;
int footInInches = 12;
int yardInInches = 36;
int a;
int b;
int x;
int r1;
int r2;

System.out.println("Enter number of inches: ");
int numInches = scnr.nextInt();

a = numInches / yardInInches;
r1 = numInches %  yardInInches;

b = r1 / footInInches;
r2 = r1 % footInInches;

numYards = a;
numFeet = b;
x = r2;

System.out.println(numYards + " yards, " + numFeet + " feet, and " + x);

//Homework 2-2 It was quite difficult to figure out but I made it through.




	
	
	
	
	
   }
}
