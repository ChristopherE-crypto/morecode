package lab1;
import java.util.Scanner;

public class CopenhagenTransit {
public static void main(String [] args) {
	
Scanner scnr = new Scanner(System.in);

int zoneNumber;
double fare;
String adultorChild;
fare = 0;

System.out.println("Enter zone number :");
zoneNumber = scnr.nextInt();

System.out.println("Enter adult or child :");
adultorChild = scnr.next();

if(zoneNumber > 4) {
	fare = -1.00;
}
else if(zoneNumber <= 2 && adultorChild.equals("adult")) {
	fare = 23.0;
}
else if(zoneNumber <= 2 && adultorChild.equals("child")) {
	fare = 11.5;
}
else if(zoneNumber == 3 && adultorChild.equals("adult")) {
	fare = 34.5;
}
else if(zoneNumber == 4 && adultorChild.equals("adult")) {
	fare = 46.0;
}
else if(zoneNumber == 3 || zoneNumber == 4 && adultorChild.equals("child")) {
	fare = 23.0;
}




System.out.printf("The fare for %s to zone number %d is %.1f", adultorChild, zoneNumber, fare);
	
    }
}
