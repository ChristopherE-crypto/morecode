package lab1;
import java.util.Scanner;

public class Homework32 {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	
	int numSeconds;
	int numMinutes;
	int numHours;
	int totalSeconds;
	
	System.out.println("Enter the number of seconds: ");
	totalSeconds = scnr.nextInt();
	
	numHours = (totalSeconds / 60) / 60;
	numMinutes = (totalSeconds / 60) % 60;
	numSeconds = ((totalSeconds % 60) % 60) % 60;
	System.out.printf("%1d seconds = %d hours, %1d minutes, and %1d seconds \n", totalSeconds, numHours, numMinutes, numSeconds);
	
	System.out.printf("%d seconds = %02dh:%02dm:%02ds", totalSeconds, numHours, numMinutes, numSeconds);

	
	
	scnr.close();
	//Homework 3-2 Enjoyed working on this one. Practiced more formatting. 
   }
}
