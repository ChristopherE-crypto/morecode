

package lab1;
import java.util.Scanner;

public class labone {
public static void main(String [] args) {

	Scanner scnr = new Scanner(System.in);
	
	System.out.print("Enter number of Eastern Caribbean Dollars :");
	double ecd = scnr.nextInt();
	System.out.print("Enter number of Dominican pesos :");
	double dp = scnr.nextInt();
	System.out.print("Enter number of Brazilian Reals :");
	double br = scnr.nextInt();
	
	double usd = (ecd * 0.37) + (dp * 0.019) + (br * 0.239);
	
	System.out.print("US Dollars = $" + usd);
	
	
	
	
	
	
   }
}