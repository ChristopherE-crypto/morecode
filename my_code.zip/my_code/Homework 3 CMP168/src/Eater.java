
public interface Eater {
	
	void eat(Food food);
	void eat(Food [] foods);

}
