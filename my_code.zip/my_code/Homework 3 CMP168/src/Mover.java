
public interface Mover {
	
	String move();
	String move(int count);

}
