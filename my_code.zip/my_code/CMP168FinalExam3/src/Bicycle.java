
public class Bicycle extends Vehicle implements Comparable<Bicycle>{
	private double weight;
	private final double ACCURACY_RANGE = 0.5;
	
	public Bicycle() {
		super(1, 1);
		weight = 0;
	}
	
	public Bicycle(Person driver) {
		super(new int [] {1});
		weight = 0;
		try {
			setDriver(driver);
		} catch (InvalidDriverException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Bicycle(Person driver, double weight) {
		super(new int [] {1});
		
		if(weight > 0) {
			this.weight = weight;
		}
		else {
			weight = 0;
		}
		try {
			setDriver(driver);
		} catch (InvalidDriverException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public double getWeight() {
		return weight;
	}
	
	public void setWeight(double w) {
		if(w > 0) {
			weight = w;
		}
		else {
			weight = 0;
		}
	}
	
	public void setDriver(Person p) throws InvalidDriverException {
		if(p != null) {
			if(p.getAge() < 3) {
				throw new InvalidDriverException();
			}
			else{
				personsOnBoard[0][0] = p;
			}
		}
		else {
			throw new InvalidDriverException();
		}
	}
	
	public String toString() {
		return "Bicycle [ rider= " + getDriver().getName() + " | weight= " + weight + " ]";
	}
	
	public boolean equals(Object o) {
		if(o == null) {return false;}
		if(this == o) {return true;}
		if(o instanceof Bicycle) {
			Bicycle otherB = (Bicycle)o;
			if(Math.abs(this.getWeight() - otherB.getWeight()) <= ACCURACY_RANGE) {
				return true;
			}
		}
		return false;
	}

	@Override
	public int compareTo(Bicycle o) {
		if(this.getWeight() < o.getWeight() && Math.abs(this.getWeight() - o.getWeight()) > ACCURACY_RANGE) {
			return -1;
		}
		else if(this.getWeight() > o.getWeight() && Math.abs(this.getWeight() - o.getWeight()) > ACCURACY_RANGE) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean loadPassenger(Person p) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int loadPassengers(Person[] peeps) {
		// TODO Auto-generated method stub
		return 0;
	}
}
