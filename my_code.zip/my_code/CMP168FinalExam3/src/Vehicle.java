
public abstract class Vehicle {
	protected Person [][] personsOnBoard;
	protected int numberOfRows;
	protected int maxSeatsPerRow;
	protected int [] numSeatsPerRow;
	
	public Vehicle(int numRows, int numSeatsPerRow) {
		personsOnBoard = new Person [numRows][numSeatsPerRow];
		numberOfRows = numRows;
		maxSeatsPerRow = numSeatsPerRow;
		this.numSeatsPerRow = new int [numRows];
		for(int i = 0; i < numRows; i++) {
			this.numSeatsPerRow[i] = numSeatsPerRow;
		}
	}
	
	public Vehicle(int [] numSeatsPerRow) {
		personsOnBoard = new Person [numSeatsPerRow.length][];
		this.numSeatsPerRow = numSeatsPerRow;
		numberOfRows = numSeatsPerRow.length;
		int max = 0;
		for(int i = 0; i < numSeatsPerRow.length; i++) {
			personsOnBoard[i] = new Person [numSeatsPerRow[i]];
			if(numSeatsPerRow[i] > max) {
				max = numSeatsPerRow[i];
			}
		}
		maxSeatsPerRow = max;
	}
	
	public Vehicle(Person driver, int [] numSeatsPerRow) {
		if(!driver.hasDriverLicense()) {
			new InvalidDriverException();
		}
		else {
			personsOnBoard = new Person [numSeatsPerRow.length][];
			this.numSeatsPerRow = numSeatsPerRow;
			numberOfRows = numSeatsPerRow.length;
			int max = 0;
			for(int i = 0; i < numSeatsPerRow.length; i++) {
				personsOnBoard[i] = new Person [numSeatsPerRow[i]];
				if(numSeatsPerRow[i] > max) {
					max = numSeatsPerRow[i];
				}
			}
			maxSeatsPerRow = max;
			personsOnBoard[0][0] = driver;
			
		}
	}
	
	public abstract boolean loadPassenger(Person p);
	
	public abstract int loadPassengers(Person [] peeps);
	
	public int getNumberOfSeats() {
		int count = 0;
		for(int i = 0; i < numSeatsPerRow.length; i++) {
			count += numSeatsPerRow[i];
		}
		return count;
	}
	
	public void setDriver(Person p) throws InvalidDriverException {
		if(p != null) {
			if(p.hasDriverLicense()) {
				personsOnBoard[0][0] = p;
			}
			else {
				throw new InvalidDriverException("Person Does Not Have A Driver License!");
			}
		}
		else {
			throw new InvalidDriverException("Person Does Not Exist!");
		}
	}
	
	public Person getDriver() {
		if(personsOnBoard[0][0] != null) {
			return personsOnBoard[0][0];
		}
		else {
			return null;
		}
	}
	
	public boolean hasDriver() {
		if(personsOnBoard[0][0] != null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public int getNumberOfAvailableSeats() {
		int empty = 0;
		for(int i = 0; i < personsOnBoard.length; i++) {
			for(int j = 0; j < personsOnBoard[i].length; j++) {
				if(personsOnBoard[i][j] == null) {
					empty++;
				}
			}
		}
		return empty;
	}
	
	public int getNumberOfAvailableSeatsInRow(int row) {
		if(row < 0 || row >= personsOnBoard.length) {
			return -1;
		}
		else {
			int empty = 0;
			for(int j = 0; j < personsOnBoard[row].length; j++) {
				if(personsOnBoard[row][j] == null) {
					empty++;
				}
			}
			return empty;
		}
	}
	
	public int getNumberOfPeopleOnBoard() {
		int people = 0;
		for(int i = 0; i < personsOnBoard.length; i++) {
			for(int j = 0; j < personsOnBoard[i].length; j++) {
				if(personsOnBoard[i][j] != null) {
					people++;
				}
			}
		}
		return people;
	}
	
	public int getNumberOfPeopleInRow(int row) {
		if(row < 0 || row >= personsOnBoard.length) {
			return -1;
		}
		else {
			int people = 0;
			for(int j = 0; j < personsOnBoard[row].length; j++) {
				if(personsOnBoard[row][j] != null) {
					people++;
				}
			}
			return people;
		}
	}
	
	public Person getPersonInSeat(int row, int col) {
		if(row < 0 || row >= personsOnBoard.length || col < 0 || col >= personsOnBoard[row].length) {
			return null;
		}
		else {
			if(personsOnBoard[row][col] == null) {
				return null;
			}
			else {
				return personsOnBoard[row][col];
			}
		}
	}
	
	public int [] getLocationOfPersonInVehicle(Person p) {
		if(p != null) {
			int [] location = {-1, -1};
			for(int i = 0; i < personsOnBoard.length; i++) {
				for(int j = 0; j < personsOnBoard[i].length; j++) {
					if(personsOnBoard[i][j] != null && p.equals(personsOnBoard[i][j])) {
						location[0] = i;
						location[1] = j;
					}
				}
			}
			return location;
		}
		else {
			return new int [] {-1, -1};
		}
	}
	
	public Person [] getPeopleInRow(int row) {
		if(row < 0 || row >= personsOnBoard.length || getNumberOfPeopleInRow(row) == 0) {
			return null;
		}
		else {
			Person [] copy = new Person [getNumberOfPeopleInRow(row)];
			for(int j = 0; j < copy.length; j++) {
				copy[j] = personsOnBoard[row][j].clone();
			}
			return copy;
		}
	}
	
	public Person [][] getPeopleOnBoard(){
		Person [][] copy = new Person [numSeatsPerRow.length][];
		for(int i = 0; i < copy.length; i++) {
			copy[i] = new Person [numSeatsPerRow[i]];
		}
		for(int i = 0; i < copy.length; i++) {
			for(int j = 0; j < copy[i].length; j++) {
				if(personsOnBoard[i][j] != null) {
					copy[i][j] = personsOnBoard[i][j].clone();
				}
			}
		}
		return copy;
	}
	
	public boolean isPersonInVehicle(Person p) {
		if(p != null) {
			for(int i = 0; i < personsOnBoard.length; i++) {
				for(int j = 0; j < personsOnBoard[i].length; j++) {
					if(personsOnBoard[i][j] != null && p.equals(personsOnBoard[i][j])) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public boolean isPersonDriver(Person p) {
		if(p != null && personsOnBoard[0][0] != null && p.equals(personsOnBoard[0][0])) {
			return true;
		}
		return false;
	}
	
	public boolean isPersonAtRow(int row, Person p) {
		if(p != null && row >= 0 && row < numSeatsPerRow.length) {
			for(int j = 0; j < personsOnBoard[row].length; j++) {
				if(personsOnBoard[row][j] != null && p.equals(personsOnBoard[row][j])) {
					return true;
				}
			}
			return false;
		}
		else {
			return false;
		}
	}
}
