import java.util.Scanner;

public class RecursionQuestion {

	public static int binarySearch(Car [] cars, Car c) {
		System.out.println("Looking for " + c.toString());
		return binarySearch(cars, c, 0, cars.length - 1);
	}
	
	public static int binarySearch(Car [] cars, Car c, int s, int e) {
		if(s > e) {
			return -1;
		}
		else {
			int midpoint = (s + e) / 2;
			System.out.println("s=" + s + ", e=" + e + ", mid=" + midpoint);
			if(c.compareTo(cars[midpoint]) == 0) {
				return midpoint;
			}
			else if(c.compareTo(cars[midpoint]) == 1) {
				System.out.println("go right");
				return binarySearch(cars, c, midpoint + 1, e);
			}
			else {
				System.out.println("go left");
				return binarySearch(cars, c, s, midpoint - 1);
			}
		}
	}

//do not remove main method or its content
	public static void main(String[] args) {
		Car [] cars = new Car[10];
		int [][] seatConfigurations = {new int[]{2,2}, new int[]{2,3}, 
				new int[]{2,2,3}, new int[]{2,3,3}, new int[]{2,3,4}, new int[]{2,4,3}, 
				new int[]{2,3,5}, new int[]{2,4,4}, new int[]{2,4,5}, new int[]{3,4,5}};
		for(int i=0; i<cars.length; i++){
			cars[i] = new Car(2, 4, seatConfigurations[i]);
		}
		Scanner kb = new Scanner(System.in);
// 		System.out.print("enter seat info");   //uncomment only when testing on your local system
		String [] input = kb.nextLine().split(" ");
		int [] rowSeats = new int[input.length];
		for(int i=0; i<input.length; i++){
			rowSeats[i] = Integer.parseInt(input[i]);
		}
		
		Car c = new Car(2, 4, rowSeats);
		
		int x = binarySearch(cars, c);
		
		if(x == -1) {
			System.out.println("Not Found");
		}
		else {
			System.out.println("FOUND at " + x);
		}
		
		System.out.println();
		System.out.println();




   }


}