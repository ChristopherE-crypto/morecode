
public class Bus extends Car{
	public Bus(int [] numSeatsPerRow) {
		super(2, (2 * numSeatsPerRow.length) - 1, numSeatsPerRow);
	}
	
	public Bus(Person driver, int [] numSeatsPerRow) {
		super(2, (2 * numSeatsPerRow.length) - 1, numSeatsPerRow);
		try {
			setDriver(driver);
		} catch (InvalidDriverException e) {
			e.printStackTrace();
		}
	}
	
	public boolean canOpenDoor(Person p) {
		if(p != null) {
			if(p.equals(getDriver()) || isPersonAtRow(numSeatsPerRow.length - 1, p)) {
				if(p.getAge() > 5 && p.getHeight() > 40) {
					return true;
				}
			}
			return false;
		}
		return false;
	}
	
	public boolean canOpenWindow(Person p) {
		if(p != null && super.canOpenWindow(p)) {
			if(p.getAge() > 5) {
				return true;
			}
			return false;
		}
		else {
			return false;
		}
	}
	
	public String toString() {
		return "Bus is an extension of " + super.toString();
	}
	
	public String departure() {
		return super.departure() + "The Bus\n";
	}
	
	public String arrival() {
		return super.arrival() + "Of The Bus\n";
	}
	
	public String doNotDisturbTheDriver() {
		return super.doNotDisturbTheDriver() + "On The Bus\n";
	}
}
