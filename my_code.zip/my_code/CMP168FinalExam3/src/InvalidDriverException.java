
public class InvalidDriverException extends Exception {
	public InvalidDriverException() {
		super();
	}
	
	public InvalidDriverException(String message) {
		super(message);
	}
}
