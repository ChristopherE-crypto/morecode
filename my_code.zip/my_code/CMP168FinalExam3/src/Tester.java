import java.util.Arrays;

public class Tester {

	public static void main(String[] args) {
		Person p1 = new Person("Carlos", true, 20, 60);
		Person p2 = new Person("Maria", false, 40, 50);
		Person p3 = new Person("Pepe", false, 10, 30);
		
		Bicycle bicycle = new Bicycle(p1, 20);
		Bicycle bicycle2 = new Bicycle(p2, 20);
		Bicycle bicycle3 = new Bicycle();
		
		System.out.println(bicycle.toString());
		
		System.out.println(bicycle2.toString());
		
		System.out.println(bicycle3.toString());

	}

}
