import java.util.Arrays;

public class MinimumSwaps2 {
	
	public static int minimumSwaps3(int [] arr) {
		int swap=0;
        for(int i=0;i<arr.length;i++){
            if(i+1!=arr[i]){
                int t=i;
                while(arr[t]!=i+1){
                    t++;  
                }
                int temp=arr[t];
                arr[t]=arr[i];
                arr[i]=temp;
                swap++;
            }
        }
        return swap;
	}
	
	public static int minimumSwaps2(int [] arr) {//My own algorithm O(n) time complexity
		int count = 0;
		
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] != i + 1) {
				int temp = arr[i];
				arr[i] = i + 1;
				arr[temp - 1] = temp;
				count++;
			}
		}
		return count;
	}
	
	public static int minimumSwaps(int [] arr) {// O(n^2) time complexity
		int count = 0;
		for(int i = 0; i < arr.length; i++) {
			for(int j = 1; j < arr.length; j++) {
				if(arr[i] != i + 1) {
					if(arr[j] == i + 1) {
						int temp = arr[i];
						arr[i] = arr[j];
						arr[j] = temp;
						count++;
					}
				}
			}
		}
		return count;
	}

	public static void main(String[] args) {
		
		int [] arr = {10, 6, 9, 5, 3, 1, 8, 4, 7, 2};
		
		//System.out.println("First Method: " + minimumSwaps(arr));
		
		System.out.println("Second Method: " + minimumSwaps2(arr));
		
		//System.out.println("Third Method: " + minimumSwaps3(arr));
		
		System.out.println(Arrays.toString(arr));

	}

}
