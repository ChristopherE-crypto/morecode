
public class SpecialSubstring {
	
	public static long substrCount(int n, String s) {
		long count = n;
		
		for(int i = 0; i < n; i++) {
			int repeat = 0;
			
			while(i + 1 < n && s.charAt(i) == s.charAt(i + 1)) {
				repeat++;
				i++;
			}
			count += (repeat * (repeat + 1)) / 2;
			
			int pointer = 1;
			
			while(i - pointer >= 0 && i + pointer < n && s.charAt(i + pointer) == s.charAt(i - 1) && s.charAt(i - pointer) == s.charAt(i - 1)) {
				count++;
				pointer++;
			}
		}
		
		return count;
	}

	public static void main(String[] args) {
		String s = "aaaa";
		int n = s.length();
		
		System.out.println(substrCount(n, s));

	}

}
