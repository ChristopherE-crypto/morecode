import java.util.ArrayList;
import java.util.Arrays;

public class SecondProblem {
	
	public static boolean contains(int [] arr, int num) {
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] == num) {
				return true;
			}
		}
		return false;
	}
	
	public static void remove(int [] arr, int num) {
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] == num) {
				arr[i] = 0;
			}
		}
	}
	
	public static int sockMerchant(int n, int [] arr) {
		int count = 0;
		
		int [] nums = new int [n];
		
		for(int i = 0; i < n; i++) {
			int element = arr[i];
			if(contains(nums, element)) {
				remove(nums, element);
				count++;
			}
			else {
				nums[i] = element;
			}
		}
	
		return count;
	}
	
	public static void main(String [] args) {
		int [] arr = {1, 2, 1, 2, 1, 2, 3};
		int n = 7;
		
		System.out.println(sockMerchant(n, arr));
	}

}
