import java.util.ArrayList;
import java.util.Arrays;

public class LeftRotation {
	
	public static ArrayList<Integer> rotLeft(ArrayList <Integer> a, int d){
		int size = a.size();
        ArrayList <Integer> rotatedArr = new ArrayList<Integer>(size);
        int i = 0; 
        int rotateIndex = d;
        
        while(rotateIndex < size) {
            int temp = a.get(rotateIndex);
            rotatedArr.add(i, temp);
            i++;
            rotateIndex++;
        }
        
        rotateIndex = 0;
        
        while(rotateIndex < d) {
            //rotatedArr.set(i, a.get(rotateIndex));
        	int temp = a.get(rotateIndex);
            rotatedArr.add(i, temp);
            i++;
            rotateIndex++;
        }
        
        return rotatedArr;
	}
	
	public static int [] rotLeft(int [] a, int d) {
		int size = a.length;
		int [] rotatedArr = new int [size];
		int i = 0; 
		int rotateIndex = d;
		
		while(rotateIndex < size) {
			rotatedArr[i] = a[rotateIndex];
			i++;
			rotateIndex++;
		}
		
		rotateIndex = 0;
		
		while(rotateIndex < d) {
			rotatedArr[i] = a[rotateIndex];
			i++;
			rotateIndex++;
		}
		
		return rotatedArr;
	}
	
	public static void main(String [] args) {
		int [] arr = {1, 2, 3, 4, 5};
		
		ArrayList <Integer> list = new ArrayList<Integer>(5);
		
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		
		
		
		System.out.println(Arrays.toString(rotLeft(arr, 2)));
		
		System.out.println(rotLeft(list, 2).toString());
	}

}
