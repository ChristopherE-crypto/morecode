import java.util.Arrays;

public class FirstProblem {
	
	public static int[] twoSum(int[] nums, int target) {
        int [] solution = {-1, -1};
        
        for(int i = 0; i < nums.length; i++) {
        	for(int j = 1; j < nums.length; j++) {
        		if(nums[i] + nums[j] == target && i != j) {
        			solution[0] = i;
        			solution[1] = j;
        			return solution;
        		}
        	}
        }
        return solution;
    }

	public static void main(String[] args) {
		int [] nums = {2, 5, 5, 11};
		int target = 10;
		
		System.out.println(Arrays.toString(twoSum(nums, target)));

	}

}
