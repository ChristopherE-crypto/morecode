import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GradingStudents {
	
	public static List<Integer> gradingStudents(List<Integer> grades) {
        int [] multiples = {40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100};
        
        for(int i = 0; i < grades.size(); i++){
            for(int j = 0; j < multiples.length; j++){
                if(grades.get(i) >= 38 && multiples[j] > grades.get(i) && (multiples[j] - grades.get(i)) < 3){
                    grades.set(i, multiples[j]);
                }
            }
        }
        return grades;
	}
	
	public static int [] gradingStudents(int [] grades) {
		
		int [] multiples = {40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100};
		
		for(int i = 0; i < grades.length; i++) {
			for(int j = 0; j < multiples.length; j++) {
				if(grades[i] >= 38 && multiples[j] > grades[i] && (multiples[j] - grades[i]) < 3) {
					grades[i] = multiples[j];
				}
			}
		}
		return grades;
	}

	public static void main(String[] args) {
		
		ArrayList <Integer> grades = new ArrayList<Integer>();
		grades.add(73);
		grades.add(67);
		grades.add(38);
		grades.add(33);
		
		
		int [] grades2 = {84, 29, 57};
		
		System.out.println(Arrays.toString(gradingStudents(grades2)));
		
		System.out.println(gradingStudents(grades));

	}

}
