
public class alternatingCharacters {
	
	public static int alternatingCharacters(String s) {
		int deletions = 0;
		for(int i = 0; i < s.length() - 1; i++) {
			if((s.charAt(i) == 'A' && s.charAt(i + 1) == 'A') || (s.charAt(i) == 'B' && s.charAt(i + 1) == 'B')) {
				deletions++;
			}
		}
		return deletions;
	}

	public static void main(String[] args) {
		String s = "AAABBB";
		
		System.out.println(alternatingCharacters(s));

	}

}
