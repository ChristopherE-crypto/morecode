
public class TimeConversion {
	
	public static String timeConversion(String s) {
		int length = s.length();
		
		String check = s.substring(8, 10);
		
		s = s.substring(0, length - 2);
		
		s = s.replaceAll(":", "");
		
		int hours = Integer.parseInt(s.substring(0, 2));
		
		if(hours == 12 && check.equals("AM")) {
			hours -= 12;
		}
		else if(check.equals("PM") && hours < 12) {
			hours += 12;
		}
		
		String seconds = s.substring(4, 6);
		String minutes = s.substring(2, 4);
		
		 s = String.format("%02d:%s:%s", hours, minutes, seconds);
		
		return s;
	}

	public static void main(String[] args) {
		String s = "12:05:45AM";
		
		System.out.println(timeConversion(s));

	}

}
