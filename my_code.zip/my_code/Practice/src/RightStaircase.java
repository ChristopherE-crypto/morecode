
public class RightStaircase {

	public static void main(String[] args) {
		int n = 6;
		
		String rstr="";
	    for(int i=0;i<n;i++){
	       rstr+="#";
	       System.out.format("%"+n+"s%n",rstr);
	    }
	    

	}

}
