import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class ValidString {
	
	public static String isValid(String s) {
		
		Map <Character, Integer> charFreqMap = new HashMap<>();
		for(int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			int freq = charFreqMap.getOrDefault(c, 0);
			charFreqMap.put(c, ++freq);
		}
		
		int [] arr = new int[charFreqMap.size()];
		int idx = 0;
		for(Map.Entry<Character, Integer> characterIntegerEntry : charFreqMap.entrySet()) {
			arr[idx++] = characterIntegerEntry.getValue();
		}
		
		Arrays.sort(arr);
		
		if(charFreqMap.size() == 1) {
			return "YES";
		}
		
		int first = arr[0];
		int second = arr[1];
		int secondLast = arr[arr.length - 2];
		int last = arr[arr.length - 1];
		
		if(first == last) {
			return "YES";
		}
		
		if(first == 1 && second == last) {
			return "YES";
		}
		
		if(first == second && second == secondLast && secondLast == (last - 1)) {
			return "YES";
		}
		
		return "NO";
	}

	public static void main(String[] args) {
		
		String s = "aabbcd";
		
		System.out.println(isValid(s));

	}

}
