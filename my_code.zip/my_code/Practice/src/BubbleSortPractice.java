import java.util.Arrays;

public class BubbleSortPractice {
	
	public static void countSwaps(int [] a) {
		int count = 0;
		
		for(int i = 0; i < a.length - 1; i++) {
			for(int j = 0; j < a.length - i - 1; j++) {
				if(a[j] > a[j + 1]) {
					int temp = a[j];
					a[j] = a[j + 1];
					a[j + 1] = temp;
					System.out.println(Arrays.toString(a));
					count++;
				}
			}
		}
		
		System.out.println("Array is sorted in " + count + " swaps.");
		System.out.println("First Element: " + a[0]);
		System.out.println("Last Element: " + a[a.length - 1]);
		
		return;
	}

	public static void main(String[] args) {
		int [] arr = {3, 2, 1};
		
		countSwaps(arr);
		
		System.out.println(Arrays.toString(arr));

	}

}
