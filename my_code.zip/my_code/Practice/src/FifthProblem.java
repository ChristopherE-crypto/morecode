
public class FifthProblem {
	
	public static long repeatedString(String s, long n) {
		int strLength = s.length();
		long q = 0, r = 0;
		q = n / strLength;
		r = n % strLength;
		long partialStrLength = (r == 0) ? 0 : r;
		long aCount = q * getLetterCount(s, s.length()) + getLetterCount(s, partialStrLength);
		return aCount;
	}
	
	public static long getLetterCount(String s, long strLength) {
		long count = 0;
		for(int i = 0; i < strLength; i++) {
			if(s.charAt(i) == 'a') {
				count++;
			}
		}
		return count;
	}
	
	public static void main(String [] args) {
		String s = "ab";
		long n = 7;
		
		System.out.println(repeatedString(s, n));
	}
}
