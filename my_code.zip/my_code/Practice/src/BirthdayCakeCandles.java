import java.util.List;

public class BirthdayCakeCandles {
	
	public static int birthdayCakeCandles(List<Integer> candles) {
        int max = 0;
        int maxCount = 0;
        
        for(int i = 0; i < candles.size(); i++){
            if(candles.get(i) > max){
                max = candles.get(i);
            }
        }
        
        for(int i = 0; i < candles.size(); i++){
            if(candles.get(i) == max){
                maxCount++;
            }
        }
        return maxCount;
    }

	public static void main(String[] args) {
		

	}

}
