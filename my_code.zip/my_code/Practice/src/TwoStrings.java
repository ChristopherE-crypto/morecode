import java.util.HashSet;

public class TwoStrings {
	
	public static String twoStrings(String s1, String s2) {
		
		HashSet <Character> string1_chars = new HashSet();
		HashSet <Character> string2_chars = new HashSet();
		
		for(int i = 0; i < s1.length(); i++) {
			string1_chars.add(s1.charAt(i));
		}
		
		for(int i = 0; i < s2.length(); i++) {
			string2_chars.add(s2.charAt(i));
		}
		
		string1_chars.retainAll(string2_chars);
		
		if(!string1_chars.isEmpty()) {
			return "YES";
		}
		else {
			return "NO";
		}
	}

	public static void main(String[] args) {
		String s1 = "hi";
		String s2 = "world";
		
		System.out.println(twoStrings(s1, s2));

	}

}
