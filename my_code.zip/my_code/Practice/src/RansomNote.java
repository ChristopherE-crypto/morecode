import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class RansomNote {
	
	public static void checkMagazine2(String [] magazine, String [] note) {
		if(magazine.length < note.length){
            System.out.println("No");
            return;
        }

        Map<String,Integer> mgzMap = new HashMap<String, Integer>(magazine.length);
        
        for(String w: magazine){
            //1. mgzMap.put(w, count.getOrDefault(w, 0) + 1);
            
            /*2.
            if(mgzMap.containsKey(w)){
                mgzMap.put(w, mgzMap.get(w) + 1);
            }else{
                mgzMap.put(w, 1);
            }*/
            
            mgzMap.merge(w, 1, Integer::sum);
        }
        
        for(String noteWord : note){
            if( ! mgzMap.containsKey(noteWord) || mgzMap.get(noteWord) == 0){
                System.out.println("No");
                return;
            }
            mgzMap.put(noteWord, mgzMap.get(noteWord) - 1);
        }
        System.out.println("Yes");
        return;           
	}
	
	public static void checkMagazine(String [] magazine, String [] note) {
		
		int correct = 0;
		
		for(int i = 0, j = 0; i < magazine.length; i++) {
			if(j < note.length) {
				if(magazine[i].equals(note[j])) {
					correct++;
					j++;
				}
				
			}
		}
		
		if(correct == note.length || magazine.length == note.length) {
			System.out.println("Yes");
		}
		else if(magazine.length < note.length) {
			System.out.println("No");
		}
		else {
			System.out.println("No");
		}
	}

	public static void main(String[] args) {
		String [] magazine = {"pepe", "is", "a"};
		
		String [] note = {"pepe", "is", "a", "pete"};
		
		checkMagazine(magazine, note);

	}

}
