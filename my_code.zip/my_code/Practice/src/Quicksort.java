import java.util.Arrays;

public class Quicksort {
	
	public static int partition(int [] numbers, int lowIndex, int highIndex) {
		int midpoint = lowIndex + (highIndex - lowIndex) / 2;
		int pivot = numbers[midpoint];
		
		System.out.println("Midpoint : " + midpoint + "\nPivot : " + pivot);
		
		boolean done = false;
		while(!done) {
			
			System.out.println(Arrays.toString(numbers));
			
			while(numbers[lowIndex] < pivot) {
				lowIndex += 1;
			}
			
			while(pivot < numbers[highIndex]) {
				highIndex -= 1;
			}
			
			if(lowIndex >= highIndex) {
				done = true;
			}
			else {
				int temp = numbers[lowIndex];
				numbers[lowIndex] = numbers[highIndex];
				numbers[highIndex] = temp;
				
				System.out.println(Arrays.toString(numbers));
				
				lowIndex += 1;
				highIndex -= 1;
			}
		}
		
		System.out.println("Final result : " + Arrays.toString(numbers));
		
		return highIndex;
	}

	public static void main(String[] args) {
		int [] numbers = {46, 19, 57, 38, 50, 43, 93, 59, 58, 86};
		
		int index = partition(numbers, 0, 5);
		
		System.out.println(index);

	}

}
