import java.util.Arrays;

public class InvertArray {
	
	public static void invert(int [] arr) {
		//[1, 2, 3, 4, 5] -> [5, 4, 3, 2, 1]
		
		for(int i = 0; i < arr.length / 2; i++) {
			int temp = arr[i];
			arr[i] = arr[arr.length - 1 - i];
			arr[arr.length - 1 - i] = temp;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] arr = {5, 3, 2, 1, 4};
		
		invert(arr);
		
		System.out.println(Arrays.toString(arr));

	}

}
