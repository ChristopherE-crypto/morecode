import java.util.HashMap;

public class TestingHashMaps {

	public static void main(String[] args) {
		
		int count = 0;
		
		String [] magazine = {"Hello", "Pepe", "go", "to", "sleep"};
		
		String [] note = {"Hello", "Pepe", "sleep"};
		
		HashMap <Integer, String> words = new HashMap <Integer, String>();
		
		for(int i = 0; i < magazine.length; i++) {
			words.put(i, magazine[i]);
		}
		
		System.out.println(words);
		
		for(int i = 0; i < note.length; i++) {
			if(words.containsValue(note[i])) {
				count++;
			}
		}
		
		if(count == note.length) {
			System.out.println("Yes");
		}
		else {
			System.out.println("No");
		}
		

	}

}
