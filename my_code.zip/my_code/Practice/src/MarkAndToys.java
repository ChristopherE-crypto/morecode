import java.util.ArrayList;
import java.util.Collections;

public class MarkAndToys {
	
	public static int maximumToys(ArrayList<Integer> prices, int k) {
		
		int maxToys = 0;
		
		if(prices.size() == 0 || k == 0) {
			return maxToys;
		}
		
		Collections.sort(prices);
		
		for(int i = 0; i < prices.size(); i++) {
			k -= prices.get(i);
			if(k < 0) {
				return maxToys;
			}
			else {
				maxToys++;
			}
		}
		
		return maxToys;
	}

	public static void main(String[] args) {
		ArrayList<Integer> arr = new ArrayList<Integer>();
		
		int k = 15;
		
		arr.add(3);
		arr.add(7);
		arr.add(2);
		arr.add(9);
		arr.add(4);
		
		System.out.println(arr);
		
		System.out.println(maximumToys(arr, k));

	}

}
