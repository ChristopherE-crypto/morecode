package myfirstpackage;
import java.util.Scanner;
public class Xdvdgfgfdg {
public static void main(String [] args) {
int num1;
int num2;

Scanner scnr = new Scanner(System.in);
num1 = scnr.nextInt();
num2 = scnr.nextInt();

int Ans = num1+num2;
System.out.print("Your answer is: " + Ans);

}




}
