
public class User {
	
	public static void main(String [] args) {
		
		Course c1 = new Course("CMP 167");
		Course c2 = new Course("CMP 202");
		Course c3 = new Course("MAT 132");
		Course c4 = new Course("MAT 230");
		Course c5 = new Course("ENG 105");
		Course c6 = new Course("ENG 340");
		
		//Student st = new Student("Lehman", 34656);
		
		//st.addCourse(c1);
		//st.addCourse(c3);
		//st.addCourse(c5);
		
		//st.print();
		
		//c1.setGrade(54);
		//c2.setGrade(75);
		//c5.setGrade(80);
		
		//st.print();
		
		Student billy = new Student("Billy", 893820);
		billy.addCourse(c1);
		billy.addCourse(c2);
		billy.addCourse(c3);
		billy.addCourse(c4);
		billy.addCourse(c5);
		billy.addCourse(c6);
		
		c1.setGrade(48);
		c2.setGrade(57);
		c3.setGrade(90);
		c4.setGrade(67);
		c5.setGrade(94);
		c6.setGrade(41);
		
		billy.print();
	}

}
