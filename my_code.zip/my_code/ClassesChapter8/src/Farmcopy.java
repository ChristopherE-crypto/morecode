
public class Farmcopy {
private Animal animals [];
private String farmName;
private int numAnimals;
private boolean isRemoved;
private Animal animals2 [];
public Farmcopy() {
	animals = new Animal [10];
	farmName = "";
	numAnimals = 0;
     }
public Farmcopy(String farmName) {
	this.farmName = farmName;
	animals = new Animal [10];
	numAnimals = 0;
     }
public Farmcopy(int maxAnimals) {
	if(maxAnimals < 0)
		maxAnimals = 0;
	farmName = "";
	numAnimals = 0;
	animals = new Animal [maxAnimals];
     }
public Farmcopy(String farmName, int maxAnimals) {
	if(maxAnimals > 0)
		maxAnimals = 0;
	this.farmName = farmName;
	numAnimals = 0;
	animals = new Animal [maxAnimals];
     }
public Animal [] resizeAnimalArray(Animal [] animals) {
	Animal [] biggerAnimals = new Animal [animals.length * 2];
	
	for(int i = 0; i < animals.length; i++) {
		biggerAnimals[i] = animals[i];
	}
	return biggerAnimals;
}
public void addAnimal(Animal a) {
	if(animals != null && a != null && numAnimals < animals.length)
		animals[numAnimals] = a;
        numAnimals++;
    if(numAnimals > animals.length)
    	resizeAnimalArray(animals);
    	
    }
public String getFarmName() {
	return farmName;
    }
public void setFarmName(String farmName) {
	this.farmName = farmName;
    }
public Animal getAnimal(int index) {
	if(index < 0 && index < animals.length && animals != null)
		return animals[index];
	else
		return null;
    }
public int getNumAnimals() {
	return numAnimals;
    }
public Animal getFirstAnimal() {
	if(animals != null)
		return animals[0];
	else
		return null;
    }
public Animal getLastAnimal() {
	if(animals != null)
		return animals[numAnimals - 1];
	else
		return null;
    }
public Animal [] getAnimals() {
	if(isRemoved == true)
	   return animals2;
	else
		return animals;
    }
public void printAllDetails() {
	System.out.printf("FarmName: %20s | Number of Animals: %4d | Farm Size: %4d\n", getFarmName(), getNumAnimals(), getNumAnimals());
	for(int i = 0; i < numAnimals; i++) {
		animals[i].printDetails();
	   }
    }
public Animal removeAnimal(int index) {
	if(index >= 0 && index < numAnimals) {
		animals2 = new Animal [animals.length - 1];
		isRemoved = true;
		for(int i = 0, k = 0; i < animals.length; i++) {
			if(i == index)
				continue;
			animals2[k++] = animals[i];
		}
		numAnimals--;
		return animals[index];
	}
	else {
		return null;
	    }
    }
public void removeAllAnimals() {
	if(isRemoved == true) {
	for(int i = 0; i < numAnimals; i++) {
		animals2[i] = null;
	}
	numAnimals = 0;
	}
	else {
		for(int i = 0; i < numAnimals; i++) {
			animals[i] = null;
		}
		numAnimals = 0;
	}
    }
public double getTotalWeightOfAllAnimals() {
	double sum = 0;
	if(isRemoved == true) {
	for(int i = 0; i < numAnimals; i++) {
		sum += animals2[i].getWeight();
	}
	return sum;
	}
	else {
		for(int i = 0; i < numAnimals; i++) {
			sum += animals[i].getWeight();
		}
		return sum;
	}
    }
public double getAverageWeightOfAllAnimals() {
	double average = getTotalWeightOfAllAnimals() / numAnimals;
	return average;
	
    }
public int getNumberOfAnimalsAboveWeight(double weight) {
	int counter = 0;
	if(isRemoved == true) {
	for(int i = 0; i < numAnimals; i++) {
		if(animals2[i].getWeight() > weight)
			counter++;
	   }
	return counter;
	}
	else {
		for(int i = 0; i < numAnimals; i++) {
			if(animals[i].getWeight() > weight)
				counter++;
		   }
		return counter;
	}
    }
public int getNumberOfAnimalsBelowWeight(double weight) {
	int counter = 0;
	if(isRemoved == true) {
	for(int i = 0; i < numAnimals; i++) {
		if(animals2[i].getWeight() < weight)
			counter++;
	}
	return counter;
	}
	else {
		for(int i = 0; i < numAnimals; i++) {
			if(animals[i].getWeight() < weight)
				counter++;
		}
		return counter;
	}
    }
public void increaseWeightOfAllAnimals() {
	if(isRemoved == true) {
	for(int i = 0; i < numAnimals; i++) {
		animals2[i].gainWeight();
	}
	}
	else {
		for(int i = 0; i < numAnimals; i++) {
			animals[i].gainWeight();
		}
	}
    }
public void increaseWeightOfAllAnimals(double weight) {
	if(isRemoved == true) {
	for(int i = 0; i < numAnimals; i++) {
		animals2[i].gainWeight(weight);
	}
}
	else {
		for(int i = 0; i < numAnimals; i++) {
			animals[i].gainWeight(weight);
		}
	}
}
}
