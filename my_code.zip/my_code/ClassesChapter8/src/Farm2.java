import java.util.ArrayList;
public class Farm2{
	private ArrayList <Animal> animals;
	private String farmName;
	private int numAnimals;
	
	public Farm2() {
		farmName = "";
		numAnimals = 0;
		animals = new ArrayList <Animal> (10);
	}
	public Farm2(String farmName) {
		this.farmName = farmName;
		numAnimals = 0;
		animals = new ArrayList <Animal> (10);
	}
	public Farm2(int maxAnimals) {
		if(maxAnimals < 0) {
			maxAnimals = 0;
		}
		farmName = "";
		numAnimals = 0;
		animals = new ArrayList <Animal> (maxAnimals);
	}
	public Farm2(String farmName, int maxAnimals) {
		if(maxAnimals < 0) {
			maxAnimals = 0;
		}
		this.farmName = farmName;
		numAnimals = 0;
		animals = new ArrayList <Animal> (maxAnimals);
	}
	public void addAnimal(Animal a) {
		if(animals != null && a != null && numAnimals < 10) {
			animals.add(a);
			numAnimals++;
		}
	}
	public Animal removeAnimal(int index) {
		if(index >= 0 && index < numAnimals) {
			Animal fixed = animals.get(index);
			animals.remove(index);
			numAnimals--;
			return fixed;
		}
		else {
			return null;
		}
	}
	public String getFarmName() {
		return farmName;
	}
	public void setFarmName(String farmName) {
		this.farmName = farmName;
	}
	public int getNumAnimals() {
		return numAnimals;
	}
	public void printAllDetails() {
		
	}
	public Animal getAnimal(int index) {
		if(index > 0 && index < numAnimals && animals != null) {
			return animals.get(index);
		}
		else {
			return null;
		}
	}
	public Animal getFirstAnimal() {
		if(animals != null && animals.get(0) != null) {
			return animals.get(0);
		}
		else {
			return null;
		}
	}
	public Animal getLastAnimal() {
		if(animals != null && animals.get(numAnimals - 1) != null) {
			return animals.get(numAnimals - 1);
		}
		else {
			return null;
		}
	}
	public ArrayList <Animal> getAnimals(){
		return animals;
	}
	public void removeAllAnimals() {
		animals.clear();
	}
	public double getTotalWeightOfAllAnimals() {
		double sum = 0;
		for(int i = 0; i < numAnimals; i++) {
			sum += animals.get(i).getWeight();
		}
		return sum;
	}
	public double getAverageWeightOfAllAnimals() {
		double average = 0;
		average = getTotalWeightOfAllAnimals() / numAnimals;
		return average;
	}
	public int getNumberOfAnimalsAboveWeight(double weight) {
		int counter = 0;
		for(int i = 0; i < numAnimals; i++) {
			if(animals.get(i).getWeight() > weight) {
				counter++;
			}
		}
		return counter;
	}
	public int getNumberOfAnimalsBelowWeight(double weight) {
		int counter = 0;
		for(int i = 0; i < numAnimals; i++) {
			if(animals.get(i).getWeight() < weight) {
				counter++;
			}
		}
		return counter;
	}
	public void increaseWeightOfAllAnimals() {
		for(int i = 0; i <numAnimals; i++) {
			animals.get(i).gainWeight();
		}
	}
	public void increaseWeightOfAllAnimals(double weight) {
		for(int i = 0; i < numAnimals; i++) {
			animals.get(i).gainWeight(weight);
		}
	}
}
