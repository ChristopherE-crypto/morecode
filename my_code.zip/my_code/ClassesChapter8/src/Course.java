
public class Course {
	
	private String name;
	private int credits;
	private int grade;
	
	public Course() {
		this.name = "None";
		this.credits = 3;
		
	}
	public Course(String name) {
		this.name = name;
		this.grade = 100;
		
	}
	public String getName() {
		return name;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	

}
