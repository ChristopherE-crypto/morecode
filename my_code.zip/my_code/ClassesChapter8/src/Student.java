
public class Student {
	
	private String name;
	private int ID;
	private double GPA;
	private String email;
	private int numCourses;
	private Course [] courses;
	
	public Student() {
		this.name = "Lehman Student";
		this.ID = 0000;
		this.email = name + "@lc.cuny.edu";
		courses = new Course[10];
	}
	public Student(String name, int ID) {
		this.name = name;
		this.ID = ID;
		this.email = name + "@lc.cuny.edu";
		courses = new Course[5];
	}
	public String getName() {
		return name;
	}
	public double getGPA() {
		return GPA;
	}
	public void addCourse(Course c) {
		if(numCourses < 5) {
		courses[numCourses] = c;
		numCourses += 1;
		}
		else {
			System.out.println("WARNING: You reached the course limit.");
		}
	}
	public double average() {
		double sum = 0;
		for(int i = 0; i < numCourses; i++) {
			
			sum += courses[i].getGrade();
		}
		return sum / numCourses;
	}
	public double computeGPA() {
		return 4.0 * average() / 100;
	}
	public void print() {
		System.out.println("Name: "+ name + " ID: " + ID + " Email: " + email);
		for(int i = 0; i < numCourses; i++) {
			System.out.println("Course name: " + courses[i].getName() + " Course grade: " + courses[i].getGrade());
		}
		System.out.println("Average: " + average() + " GPA: " + computeGPA());
	}
	

}
