import java.util.Arrays;
import java.util.Scanner;

public class AnimalTester {

	public static void main(String[] args) {
		Animal tiger = new Animal("Tiger", 2008, 40, 'z');
		Farm farm = new Farm("El paso");
		Farmcopy farm2 = new Farmcopy("Pollo");
		Scanner scnr = new Scanner(System.in);
		Animal sheep = new Animal("Sheep", 2005, 30, 'm');
		Animal horse = new Animal("Horse", 2001, 100, 'f');
		//System.out.println("Enter the name of your animal: ");
		//tiger.setName(scnr.next());
		
		//System.out.println("Enter the birthyear of your animal: ");
		//tiger.setBirthYear(scnr.nextInt());
		
		//System.out.println("Enter the weight of your animal: ");
		//tiger.setWeight(scnr.nextDouble());
		
		//tiger.setGender('m');
		
		//tiger.gainWeight(3.5);
		
		//System.out.println(tiger.calculateAge(2020));
		
		//System.out.println(tiger.isFemale());
		
		//tiger.printDetails();
		
		//System.out.println(farm.getFarmName());
		//farm.addAnimal(tiger);
		//farm.addAnimal(horse);
		//farm.removeAnimal(1);
		farm.addAnimal(tiger);
		//farm2.printAllDetails();
		farm.addAnimal(horse);
		farm.addAnimal(sheep);
		farm.removeAnimal(0);
		//farm.printAllDetails();
		
		//System.out.println(Arrays.toString(farm.getAnimals()));
		System.out.println(farm.getTotalWeightOfAllAnimals());
		System.out.println(farm.getNumberOfAnimalsAboveWeight(35.0));
		System.out.println(farm.getFirstAnimal());
		
		System.out.println(farm.getAnimal(0));
		//farm.printAllDetails();

	}

}
