
/**
 * @author ChrisE
 *
 */
public class Animal {
	
	private String name;
	private int birthYear;
	private double weight;
	private char gender;
	
	public Animal() {
		name = "";
		birthYear = 1900;
		weight = 0.0;
		gender = 'u';
	}
	
	public Animal(String name, int birthYear, double weight, char gender) {
		this.name = name;
		this.birthYear = birthYear;
		if(weight > 0)
		   this.weight = weight;
		else
			this.weight = -1;
		if(gender == 'm' || gender == 'f')
		   this.gender = gender;
		else
			this.gender = 'u';
	}
	
	
	public String getName() {
		return name;
	}
	
	public void setName(String n) {
		name = n;
	}
	
	public int getBirthYear() {
		return birthYear;
	}
	
	public void setBirthYear(int a) {
		birthYear = a;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public void setWeight(double d) {
		if(d >= 0)
		   weight = d;
		else
			weight = -1;
	}
	
	public char getGender() {
		return gender;
	}
	
	public void setGender(char g) {
		if(g == 'm' || g == 'f')
		   gender = g;
		else
			gender = 'u';
	}
	
	public int calculateAge(int currentYear) {
		
		if(currentYear < birthYear)
			return -1;
		else
			return currentYear - birthYear;
	}
	
	public boolean isMale() {
		if(gender == 'm')
			return true;
		else
			return false;
	}
	
	public boolean isFemale() {
		if(gender == 'f')
			return true;
		else
			return false;
	}
	
	public void printDetails() {
		System.out.printf("Name: %20s | Year of birth: %4d | Weight: %10.2f | Gender: %c\n", name, birthYear, weight, gender);
	}
	
	public void gainWeight() {
		weight = weight + 1;
	}
	
	public void gainWeight(double a) {
		if(a > 0)
		   weight = weight + a;
	}
	
	public void loseWeight() {
		if(weight >= 1)
		   weight = weight - 1;
	}
	
	public void loseWeight(double b) {
		if(b < weight)
			weight = weight - b;
	}

}
