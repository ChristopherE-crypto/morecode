public class Farm {
	private Animal animals [] = new Animal [10];
	private String farmName;
	private int numAnimals;
	
	public Farm() {
		animals = new Animal [10];
		farmName = "";
		numAnimals = 0;
	}
	public Farm(String farmName) {
		this.farmName = farmName;
		animals = new Animal [10];
		numAnimals = 0;
	}
	public Farm(int maxAnimals) {
		if(maxAnimals < 0)
			maxAnimals = 0;
		farmName = "";
		numAnimals = 0;
		animals = new Animal [maxAnimals];
	}
	public Farm(String farmName, int maxAnimals) {
		if(maxAnimals < 0)
			maxAnimals = 0;
		this.farmName = farmName;
		numAnimals = 0;
		animals = new Animal [maxAnimals];
	}
	public void resizeAnimalArray(Animal [] animals) {
		Animal [] resized = new Animal [numAnimals * 2];
		
		for(int i = 0; i < numAnimals; i++) {
			resized[i] = animals[i];
		}
		animals = resized;
		
	}
	public void addAnimal(Animal a) {
		if(animals != null && numAnimals < 10) {
			animals[numAnimals] = a;
			numAnimals++;
		}
		if(numAnimals > 10) {
			resizeAnimalArray(animals);
		}
	}
	public String getFarmName() {
		return farmName;
	}
	public void setFarmName(String farmName) {
		this.farmName = farmName;
	}
	public Animal getAnimal(int index) {
		if(index > 0 && index < animals.length && animals != null) {
			return animals[index];
		}
		else {
			return null;
		}
	}
	public int getNumAnimals() {
		return numAnimals;
	}
	public Animal getFirstAnimal() {
		return animals[0];
	}
	public Animal getLastAnimal() {
		return animals[numAnimals - 1];
	}
	public Animal [] getAnimals() {
		return animals;
	}
	//print details here.
	public Animal removeAnimal(int index) {
		if(index < 0 && index > numAnimals) {
			Animal fixed = animals[index];
			Animal [] copy = new Animal[numAnimals - 1];
			System.arraycopy(animals, 0, copy, 0, index);
			System.arraycopy(animals, index + 1, copy, index, numAnimals - index - 1);
			//animals[index] = animals[numAnimals - 1];
			animals = copy;
			numAnimals--;
			return fixed;
		}
		else {
			return null;
		}
	}
	public void removeAllAnimals() {
		for(int i = 0; i < numAnimals; i++) {
			animals[i] = null;
		}
		numAnimals = 0;
	}
	public double getTotalWeightOfAllAnimals() {
		double sum = 0;
		for(int i = 0; i < numAnimals; i++) {
			sum += animals[i].getWeight();
		}
		return sum;
	}
	public double getAverageWeightOfAllAnimals() {
		return getTotalWeightOfAllAnimals() / numAnimals;
	}
	public int getNumberOfAnimalsAboveWeight(double weight) {
		int counter = 0;
		for(int i = 0; i < numAnimals; i++) {
			if(animals[i].getWeight() > weight)
				counter++;
		   }
		return counter;
	}
	public int getNumberOfAnimalsBelowWeight(double weight) {
		int counter = 0;
		for(int i = 0; i < numAnimals; i++) {
			if(animals[i].getWeight() < weight)
				counter++;
		}
		return counter;
	}
	public void increaseWeightOfAllAnimals() {
		for(int i = 0; i < numAnimals; i++) {
			animals[i].gainWeight();
		}
	}
	public void increaseWeightOfAllAnimals(double weight) {
		for(int i = 0; i < numAnimals; i++) {
			animals[i].gainWeight(weight);
		}
	}
	
	
	
	
}