import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class GUI extends JFrame{
	
	int spacing = 5;//Space between each cell
	
	int neighs = 0;//Number of bombs next to selected cell
	
	public int mX = -100;//X coordinate for mouse position
	public int mY = -100;//Y coordinate for mouse position
	
	public int smileyX = 605;//X coordinate for smiley face
	public int smileyY = 5;//Y coordinate for smiley face
	
	public boolean happy = true;//Checks if the face is happy 
	
	Random random = new Random();
	
	int [][] mines = new int [16][9];
	int [][] neighbours = new int [16][9];//Saves the numbers next to bombs
	boolean [][] revealed = new boolean [16][9];
	boolean [][] flagged = new boolean [16][9];
	
	public GUI() {
		setTitle("Minesweeper");
		setSize(1286, 829);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		
		for(int i = 0; i < 16; i++) {
			for(int j = 0; j < 9; j++) {
				if(random.nextInt(100) < 20) {//Adds bombs to the array. Only 20% of the grid are bombs
					mines[i][j] = 1;
				}
				else {
					mines[i][j] = 0;
				}
				revealed[i][j] = false;
			}
		}
		
		for(int i = 0; i < 16; i++) {
			for(int j = 0; j < 9; j++) {
				neighs = 0;
				for(int k = 0; k < 16; k++) {
					for(int l = 0; l < 9; l++) {
						if(!(k == i && l == j)) {
							if(isN(i, j, k, l) == true) {
								neighs++;
							}
						}
					}
					neighbours[i][j] = neighs;
				}
			}
		}
		
		Board board = new Board();
		setContentPane(board);
		
		Move move = new Move();
		addMouseMotionListener(move);
		
		Click click = new Click();
		addMouseListener(click);
	}
	
	public class Board extends JPanel {
		public void paintComponent(Graphics g) {
			g.setColor(Color.DARK_GRAY);
			g.fillRect(0, 0, 1280, 800);
			for(int i = 0; i < 16; i++) {
				for(int j = 0; j < 9; j++) {
					g.setColor(Color.GRAY);//Set all panels to gray
					if(mines[i][j] == 1) {
						g.setColor(Color.YELLOW);//If it contains a mine, change color to yellow
					}
					if(revealed[i][j] == true) {//If the cell is revealed, change color to white
						g.setColor(Color.WHITE);
						if(mines[i][j] == 1) {//If the cell contains a bomb, change color to red
							g.setColor(Color.red);
						}
					}
					if(mX >= spacing + i * 80 && mX < i * 80 + 80 - spacing && mY >= spacing + j * 80 + 106 && mY < spacing + j * 80 + 186 - spacing) {//Change the color of the cell to light gray when the cursor is over it
						g.setColor(Color.LIGHT_GRAY);
					}
					g.fillRect(spacing + i * 80, spacing + j * 80 + 80, 80 - 2 * spacing, 80 - 2 * spacing);
					if(revealed[i][j] == true) {
						g.setColor(Color.BLACK);
						if(mines[i][j] == 0 && neighbours[i][j] != 0) {
							if(neighbours[i][j] == 1) {
								g.setColor(Color.BLUE);
							}
							else if(neighbours[i][j] == 2) {
								g.setColor(Color.GREEN);
							}
							else if(neighbours[i][j] == 3) {
								g.setColor(Color.RED);
							}
							else if(neighbours[i][j] == 4) {
								g.setColor(new Color(0, 0, 128));
							}
							else if(neighbours[i][j] == 5) {
								g.setColor(new Color(178, 34, 34));
							}
							else if(neighbours[i][j] == 6) {
								g.setColor(new Color(72, 209, 204));
							}
							else if(neighbours[i][j] == 7) {
								g.setColor(Color.BLACK);
							}
							else if(neighbours[i][j] == 8) {
								g.setColor(Color.DARK_GRAY);
							}
							g.setFont(new Font("Tahoma", Font.BOLD, 40));
							g.drawString(Integer.toString(neighbours[i][j]), i * 80 + 27, j * 80 + 80 + 55);
						}
						else if(mines[i][j] == 1){//Create bomb shape
							g.fillRect(i * 80 + 10 + 20, j * 80 + 80 + 20, 20, 40);
							g.fillRect(i * 80 + 20, j * 80 + 80 + 20 + 10, 40, 20);
							g.fillRect(i * 80 + 5 + 20, j * 80 + 80 + 25, 30, 30);
							g.fillRect(i * 80 + 38, j * 80 + 80 + 15, 4, 50);
							g.fillRect(i * 80 + 15, j * 80 + 80 + 38, 50, 4);
						}
					}
				}
			}
			//Smiley Painting
			g.setColor(Color.YELLOW);
			g.fillOval(smileyX, smileyY, 70, 70);
			g.setColor(Color.BLACK);
			g.fillOval(smileyX + 15, smileyY + 20, 10, 10);
			g.fillOval(smileyX + 45, smileyY + 20, 10, 10);
			
			if(happy == true) {
				g.fillRect(smileyX + 20, smileyY + 50, 30, 5);
				g.fillRect(smileyX + 17, smileyY + 45, 5, 5);
				g.fillRect(smileyX + 48, smileyY + 45, 5, 5);
			}
			else {
				g.fillRect(smileyX + 20, smileyY + 45, 30, 5);
				g.fillRect(smileyX + 17, smileyY + 50, 5, 5);
				g.fillRect(smileyX + 48, smileyY + 50, 5, 5);
			}
			
		}
	}
	
	public class Move implements MouseMotionListener {

		@Override
		public void mouseDragged(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			//System.out.println("The mouse was moved!");
			mX = e.getX();
			mY = e.getY();
			//System.out.println("X: " + mX + ", Y: " + mY);
		}
		
	}
	
	public class Click implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {
			
			if(inBoxX() != -1 && inBoxY() != -1) {
				revealed[inBoxX()][inBoxY()] = true;
			}
			
			if(inBoxX() != -1 && inBoxY() != -1) {
				System.out.println("The mouse is the [" + inBoxX() + "," + inBoxY() + "], Number of mine neighbours: " + neighbours[inBoxX()][inBoxY()]);
			}
			else {
				System.out.println("The pointer is not inside of any box!");
			}
			
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	public int inBoxX() {
		for(int i = 0; i < 16; i++) {
			for(int j = 0; j < 9; j++) {
				if(mX >= spacing + i * 80 && mX < spacing + i * 80 + 80 - 2 * spacing && mY >= spacing + j * 80 + 80 + 26 && mY < spacing + j * 80 + 26 + 80 + 80 - 2 * spacing) {
					return i;
				}
			}
		}
		return -1;
	}
	
	public int inBoxY() {
		for(int i = 0; i < 16; i++) {
			for(int j = 0; j < 9; j++) {
				if(mX >= spacing + i * 80 && mX < spacing + i * 80 + 80 - 2 * spacing && mY >= spacing + j * 80 + 80 + 26 && mY < spacing + j * 80 + 26 + 80 + 80 - 2 * spacing) {
					return j;
				}
			}
		}
		return -1;
	}
	
	public boolean isN(int mX, int mY, int cX, int cY) {
		if(mX - cX < 2 && mX - cX > -2 && mY - cY < 2 && mY - cY > -2 && mines[cX][cY] == 1) {
			return true;
		}
		return false;
	}

}
