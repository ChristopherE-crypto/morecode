
public class Doctor implements SeesPatients, Comparable <Doctor>{
	private static int numDoctors = 0;
	private String name;
	private int licenseNumber;
	private Patient [] patients;
	private int numberOfPatients;
	
	public Doctor(String name) {
		this.name = name;
		patients = new Patient[MAX_PATIENTS];
		licenseNumber = ++numDoctors;
	}
	
	public static int getNumDoctors() {
		return numDoctors;
	}
	
	public int getLicenseNumber() {
		return licenseNumber;
	}
	
	public String getName() {
		return name;
	}
	
	public int getNumberOfPatients() {
		return numberOfPatients;
	}
	
	public String getPatientsAsString() {
		String text = "patients= ";
		for(int i = 0; i < numberOfPatients; i++) {
			text += patients[i].toString() + ", ";
		}
		text = text.substring(0, text.length()-2);
		
		return text;
	}
	
	public void addPatient(Patient p) throws PatientException{//FIXME: Add Exception
		if(p != null && numberOfPatients < MAX_PATIENTS) {
			patients[numberOfPatients] = p;
			numberOfPatients++;
		}
		else {
			throw new PatientException("MAX PATIENTS REACHED!");
		}
	}
	
	public String toString() {
		return String.format("Doctor: name= %20s | license number= %06d | %s", name, licenseNumber, getPatientsAsString());
	}
	
	public boolean equals(Object obj) {
		if(obj == null) {return false;}
		if(this == obj) {return true;}
		if(obj instanceof Doctor) {
			Doctor otherD = (Doctor)obj;
			if(this.name.equals(otherD.name)) {
				if(this.numberOfPatients == otherD.numberOfPatients) {
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public int compareTo(Doctor d) {
		if(this.numberOfPatients > d.numberOfPatients) {
			return 1;
		}
		else if(this.numberOfPatients < d.numberOfPatients) {
			return -1;
		}
		else {
			return 0;
		}
	}

	@Override
	public Patient[] getPatients() {
		return patients;
	}

	@Override
	public boolean isPatient(Patient p) {
		for(int i = 0; i < numberOfPatients; i++) {
			if(patients[i].equals(p)) {
				return true;
			}
		}
		return false;
	}
	
	
}
