
public class idk {

	public static void main(String[] args) {
		Gerontologist g1 = new Gerontologist("Charles");
		
		System.out.println(g1);
		
		System.out.println();
		
		g1.setVisitFee(35.55);
		
		System.out.println(g1);
		
		g1.setVisitFee(33.6);
		
		System.out.println();
		
		System.out.println(g1);
		
		

	}

}
