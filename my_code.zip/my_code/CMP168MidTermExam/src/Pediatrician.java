
public class Pediatrician extends Doctor{
	private boolean hasPrivatePractice = false;
	private String hospitalName = "";
	
	public Pediatrician(String name) {
		super(name);
	}
	
	public Pediatrician(String name, boolean hasPrivatePractice, String hospitalName) {
		super(name);
		this.hasPrivatePractice = hasPrivatePractice;
		this.hospitalName = hospitalName;
	}
	
	public boolean hasPrivatePractice() {
		return hasPrivatePractice;
	}
	
	public String getHospitalName() {
		return hospitalName;
	}
	
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	
	public void addPatient(Patient p) throws PatientException {
		if(Math.abs(2021 - p.getBirthYear()) < 18) {
			super.addPatient(p);
		}
		else {
			throw new PatientException("PATIENT OVER THE AGE OF 18!");
		}
	}
	
	public String toString() {
		return super.toString() + String.format("\nPediatrician: %s | hospital name=%15s", (hasPrivatePractice ? "has private practice": "does not have private practice"), hospitalName);//FIXME: Maybe need to chaange the first thingy. 
	}
	
	public boolean equals(Object obj) {
		if(obj == null) {return false;}
		if(this == obj) {return true;}
		if(obj instanceof Pediatrician) {
			Pediatrician otherP = (Pediatrician)obj;
			if(this.hasPrivatePractice == otherP.hasPrivatePractice) {
				if(this.hospitalName.equals(otherP.hospitalName)) {
					return true;
				}
			}
		}
		return false;
	}
}
