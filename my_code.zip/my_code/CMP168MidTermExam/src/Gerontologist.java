
public class Gerontologist extends Doctor{
	private boolean performsHouseCalls = true;
	private double visitFee = 0.0;
	
	public Gerontologist(String name) {
		super(name);
	}
	
	public Gerontologist(String name, boolean performsHouseCalls, double visitFee) {
		super(name);
		this.performsHouseCalls = performsHouseCalls;
		if(visitFee >= 0) {
			this.visitFee = visitFee;
		}
		else {
			this.visitFee = 0.0;
		}
	}
	
	public boolean performsHouseCalls() {
		return performsHouseCalls;
	}
	
	public double getVisitFee() {
		return visitFee;
	}
	
	public void setPerformsHouseCalls(boolean performsHouseCalls) {
		this.performsHouseCalls = performsHouseCalls;
	}
	
	public void setVisitFee(double fee) {
		if(fee >= 0) {
			this.visitFee = fee;
		}
		else {
			this.visitFee = 0.0;
		}
	}
	
	public void addPatient(Patient p) throws PatientException {
		if(Math.abs(2021 - p.getBirthYear()) > 65) {
			super.addPatient(p);
		}
		else {
			throw new PatientException("PATIENT IS UNDER 65 years!");
		}
	}
	
	public String toString() {
		return super.toString() + String.format("\nGerontologist: %s | visit fee=%02.2f", (performsHouseCalls ? "performs house calls": "no house calls"), visitFee);
	}
	
	public boolean equals(Object obj) {
		if(obj == null) {return false;}
		if(this == obj) {return true;}
		if(obj instanceof Gerontologist) {
			Gerontologist otherG = (Gerontologist)obj;
			if(this.performsHouseCalls == otherG.performsHouseCalls) {
				if(Math.abs(this.visitFee - otherG.visitFee) < 0.05) {
					if(super.equals(otherG)) {//new
						return true;
					}//new
				}
			}
		}
		return false;
	}
}
