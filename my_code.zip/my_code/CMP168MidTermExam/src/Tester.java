
public class Tester {

	public static void main(String[] args) {
		Patient p1 = new Patient("Kevin", 1990, "Coronavirus");
		Patient p2 = new Patient("Jose", 1988, "Cancer");
		Patient p3 = new Patient("Pepe", 2004, "Flu");
		Patient p4 = new Patient("Sandra", 2006, "Head trauma");
		
		Doctor d1 = new Doctor("Don");
		Doctor d2 = new Doctor("Mary");
		
		Pediatrician pd1 = new Pediatrician("Pedro", false, "Saint Patrick");
		Pediatrician pd2 = new Pediatrician("Eva", true, "Saint Gabs");
		
		Gerontologist g1 = new Gerontologist("Charles");
		
		g1.setVisitFee(46.6);
		g1.setPerformsHouseCalls(true);
		
		try {
			d1.addPatient(p1);
			d2.addPatient(p1);
			d1.addPatient(p2);
			d1.addPatient(p1);
			d1.addPatient(p4);
			pd1.addPatient(p4);
			pd2.addPatient(p3);
		} catch (PatientException e) {
			e.printStackTrace();
		}
		
		System.out.println(g1);

	}

}
