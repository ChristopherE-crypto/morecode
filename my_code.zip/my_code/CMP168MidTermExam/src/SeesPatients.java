
public interface SeesPatients {
	
	void addPatient (Patient p) throws PatientException;//FIXME: throws PatientException
	Patient [] getPatients();
	String getPatientsAsString();
	boolean isPatient(Patient p);
	static final int MAX_PATIENTS = 100;

}
