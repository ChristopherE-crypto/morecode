package bBPart;
import java.io.FileOutputStream;
import java.io.PrintWriter;
public class BB {
	

	public static void main(String[] args) throws Exception {
		FileOutputStream foStream = null; 
		PrintWriter outFS = null; 
		foStream = new FileOutputStream("outfile.txt");
		outFS = new PrintWriter("outfile.txt");
		outFS.println("Java is my favorite language!");
	}

}
