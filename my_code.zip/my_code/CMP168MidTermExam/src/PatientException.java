
public class PatientException extends Exception{
	public PatientException() {
		super("PatientException. MAX LIMIT REACHED!");
	}
	
	public PatientException(String error) {
		super("PatientException. MAX CAPACITY REACHED: " + error);
	}
	
	
}
