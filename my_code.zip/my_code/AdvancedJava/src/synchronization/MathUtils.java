package synchronization;

public class MathUtils {
	
	//To make one thread go first and then the other, use the keyword synchronized. You can synchronize a whole method or just a part of the method by using synchronized (this)
	
	void getMultiples(int n) {
		
		synchronized (this) {
			for(int i = 1; i <= 5; i++) {
				System.out.println(n * i);
				try {
					Thread.sleep(400);
				}
				catch(Exception e) {
					System.out.println(e);
				}
			}
		}
	}
}
