package lambda;

public interface Greeting {
	public void perform();

}
