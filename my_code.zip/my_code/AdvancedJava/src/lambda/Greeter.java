package lambda;

public class Greeter {
	
	public void greet(Greeting greeting) {
		greeting.perform();
	}
	
	public static void main(String[] args) {
		Greeter greeter = new Greeter();
		HelloWorldGreeting helloWorldGreeting = new HelloWorldGreeting();
		greeter.greet(helloWorldGreeting);
		
		Greeting myLambdaFunction = () -> System.out.println("Hello World!");
		MyAdd addFunction = (int a, int b) -> a + b;
	}

}

interface MyAdd {
	int foo(int a, int b);
}
