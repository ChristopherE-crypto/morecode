package regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExDemo {
	
	public static void main(String [] args) {
		String regexStr = ".*[a-z][0-9].";//String can start with any character, then it should have letters, then numbers and then any character
		Pattern pattern = Pattern.compile(regexStr);
		
		Matcher matcher = pattern.matcher("123435646adadaf242341234");
		
		boolean matchFound = matcher.find();
		
		if(matchFound) {
			System.out.println("Match Found!");
		}
		else {
			System.out.println("Match Not Found!");
		}
	}

}
