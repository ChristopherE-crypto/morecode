package stringhandling;

import java.util.Arrays;

public class StringHandlingDemo {

	public static void main(String[] args) {
		String str1 = "John is studying";
		String str2 = "in college";
		System.out.println(str1.length());
		
		String result = str1.concat(str2);
		System.out.println(result);
		
		String r = String.format("The name of the student is " + "%s, and the age is %d", "John", 21);
		System.out.println(r);
		
		System.out.println(str1.charAt(5));
		
		if(str1.equals(str2)) {
			System.out.println("Same strings!");
		}
		else {
			System.out.println("Different strings!");
		}
		
		System.out.println(str1.indexOf('y'));
		
		System.out.println(str1.replace('s', 'r'));
		
		String [] arr = str1.split(" ");
		Arrays.asList(arr).forEach(s -> System.out.println(s));
		
		String newStr1 = str1.substring(1, 5);
		System.out.println(newStr1);

	}

}
