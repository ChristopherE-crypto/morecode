import java.util.Arrays;
import java.util.Scanner;

public class calc {
	
	public static int[] generateRandom(int lower, int upper, 
            int length) {
int[] arrayReference = new int[length];
int index;

for (index = 0; index < arrayReference.length; ++index) {
arrayReference[index] = (int)(Math.random() * 
       (upper - lower + 1)) + lower;
}

return arrayReference;
}



	public static void main(String[] args) {

		Scanner scnr = new Scanner(System.in);
		int i;
		int [] numbers = new int [6];
		numbers = generateRandom(1, 5, 6);
		int indexSmallest;
		int j;
		int temp;
		
		for (i = 0; i < numbers.length - 1; ++i) {

			   // Find index of smallest remaining element
			   indexSmallest = i;
			   for (j = i + 1; j < numbers.length; ++j) {

			      if (numbers[j] < numbers[indexSmallest]) {
			         indexSmallest = j;
			      }
			   }

			   // Swap numbers[i] and numbers[indexSmallest]
			   temp = numbers[i];
			   numbers[i] = numbers[indexSmallest];
			   numbers[indexSmallest] = temp;
			}
	      
		System.out.println(Arrays.toString(numbers));

	}

}
