//import java.util.Scanner;
//public class xd {
	//public static int readInt(Scanner scnr) {
		//return scnr.nextInt();	
	//}
	
	//public static int toppingsMenuDST(Scanner scnr, String orderString) {
	//	int choice ;
	//	String nuts = "", MandMs = "", strawberrySyrup = "";
		
		//System.out.println("Toppings Menu:");
	//	System.out.println("0 - Nothing \n1 - Ice Cream \n2 - Strawberry Cake \n3 - Rice Pudding \nEnter te number selection");
	//	choice = readInt(scnr);
		
	//	return choice;
	//}
	
	//public static int toppingsMenuAMC(Scanner scnr, String orderString, int choice1) {
		
	//	String oliveOil = "", paprika = "", olives = "";
		
	//	System.out.println("Toppings Menu:");
	//	System.out.println("0 - Nothing \n1 - Olive Oil \n2 - Paprika \n3 - Olives \nEnter te number selection");
	//	choice1 = readInt(scnr);
		
	
		//	if (choice1 == 1) {
		//		 oliveOil = "Olive Oil";
		//		 orderString = orderString.concat(" " + oliveOil + ",");
		//		 System.out.println(orderString);
		//	 }
			 
		 
		
	//	return choice1;
	//}
	
	//public static int dessertMenu(Scanner scnr, String orderString) {
	//	int choice;
	//	String iceCream = "", strawberryCake = "", ricePudding = "";
		
	//	System.out.println("Dessert Menu:");
	//	System.out.println("0 - Nothing \n1 - Ice Cream \n2 - Strawberry Cake \n3 - Rice Pudding \nEnter te number selection");
	//	choice = readInt(scnr);
		
	//	return choice;
	//}
	
	//public static int mainCourseMenu(Scanner scnr, String orderString) {
	//	int choice;
	//	String steak = "", chicken = "", fish = "", vegetarian = "";
	//	String oliveOil = "", paprika = "", olives = "";
		
	//	System.out.println("Main Course Menu:");
	//	System.out.println("0 - Nothing \n1 - Steak \n2 - Chicken \n3 - Fish \n4 - Vegetarian \nEnter the number selection:");
	//	choice = readInt(scnr);
		
	//	return choice;
		
	//}
	
	//public static int aptzMenu (Scanner scnr, String orderString) {
		//int choice, choice1 = 0;
		//String oysters = "", grilledCheese = "", hummus = "";
		//String oliveOil = "", paprika = "", olives = "";
		//orderString = orderString.concat("Appetizer: ");
		//orderString = orderString.concat("[");
		
	//	System.out.println("Appetizer Menu:");
		//System.out.println("0 - Nothing \n1 - Oysters \n2 - Grilled Cheese \n3 - Hummus \nEnter the number selection:");
		//choice = readInt(scnr);
		
		
		//	if (choice == 1) {
			//	oysters = "Oysters";		
			//	orderString = orderString.concat(" " + oysters + ":");
			//	choice1 = toppingsMenuAMC(scnr, orderString, choice1);
			//	 while (choice1 != 0) {
			//		 choice1 = toppingsMenuAMC(scnr, orderString, choice1); 
			//	 }
				
		//	}
		
	//return choice;		
	
	//} 
	
	//public static int menu (Scanner scnr, String userName, String orderString) {
	//	int choice, choice1, choice2, choice3;

		//	System.out.println("Select from menu " + userName + ":");
		//	System.out.println("0 - Nothing \n1 - Appetizer\n2 - Main Course \n3 - Dessert \nEnter the number for your selection:");
		//	choice = readInt(scnr); 
		//	System.out.println();
			
			//if (choice == 1) {
				//choice1 = aptzMenu(scnr, orderString);
				//while (choice1 != 0) {
				//	choice1 = aptzMenu(scnr, orderString);
			//	}
		//	}
			//else if (choice == 2) {
				//choice2 = mainCourseMenu(scnr, orderString);
			//	while (choice2 != 0) {
			//		choice2 = mainCourseMenu(scnr, orderString);
			//	}
			//}
			//else if (choice == 3) {
				//choice3 = dessertMenu(scnr, orderString);
			//	while (choice3 != 0) {
				//	choice3 =  dessertMenu(scnr, orderString);
				//}
		//	}
		
		//return choice;
	//}
	
	//public static void main(String [] args) {
		//Scanner scnr = new Scanner(System.in);
		
		//String userName = "", orderString = "", orderAswr = "";
		//int  choice;	
		//System.out.println("Welcome to the Food Festival \nWould you like to place an order?");
		//orderAswr = scnr.next();
				
		//while (!(orderAswr.equalsIgnoreCase("yes") || orderAswr.equalsIgnoreCase("no"))) {
			//System.out.println("Welcome to the Food Festival \nWould you like to place an order?");
			//orderAswr = scnr.next();
		//}
			 
		//if (orderAswr.equalsIgnoreCase("yes")) {
		//	System.out.println("What is your name for the order?");
		//	userName = scnr.next();
		//	choice = menu(scnr, userName, orderString); // Like this, the aptzmenu has to repeat if you want the topping menu to go back to the aptzmenu (Might be confusing and a lot of work to do, don't complain)
		//	while (choice != 0) {
			//	choice = menu(scnr, userName, orderString);
			//}
	//	}	
		//else {
		//	System.out.println("Thank you for stopping by, maybe next time you�ll sample our menu.");
		//	System.exit(0);	
		//}
		
		//System.out.println("Here's your order " + userName + ":\n" + orderString);
		//System.out.println("Enjoy your meal!");
		
	//}
//}

import java.util.Scanner;
public class xd {
	
		public static String orderString(Scanner scnr, String orderString) {
			return orderString = scnr.next();
		}
		
		public static int readInt(Scanner scnr) {
			return scnr.nextInt();	
		}
		
		public static int toppingsMenuDST(Scanner scnr, String orderString) {
			int choice ;
			String nuts = "", MandMs = "", strawberrySyrup = "";
			
			System.out.println("Toppings Menu:");
			System.out.println("0 - Nothing \n1 - Ice Cream \n2 - Strawberry Cake \n3 - Rice Pudding \nEnter te number selection");
			choice = readInt(scnr);
			
			return choice;
		}
		
		public static int toppingsMenuAMC(Scanner scnr, String orderString, int choice1) {
			
			System.out.println("Toppings Menu:");
			System.out.println("0 - Nothing \n1 - Olive Oil \n2 - Paprika \n3 - Olives \nEnter te number selection");
			choice1 = readInt(scnr);
				 
			return choice1;
		}
		
		public static int dessertMenu(Scanner scnr, String orderString) {
			int choice;
			String iceCream = "", strawberryCake = "", ricePudding = "";
			
			System.out.println("Dessert Menu:");
			System.out.println("0 - Nothing \n1 - Ice Cream \n2 - Strawberry Cake \n3 - Rice Pudding \nEnter te number selection");
			choice = readInt(scnr);
			
			return choice;
		}
		
		public static int mainCourseMenu(Scanner scnr, String orderString) {
			int choice;
			String steak = "", chicken = "", fish = "", vegetarian = "";
			String oliveOil = "", paprika = "", olives = "";
			
			System.out.println("Main Course Menu:");
			System.out.println("0 - Nothing \n1 - Steak \n2 - Chicken \n3 - Fish \n4 - Vegetarian \nEnter the number selection:");
			choice = readInt(scnr);
			
			return choice;
			
		}
		
		public static int aptzMenu (Scanner scnr, String orderString) {
			int choice;
			
			orderString = orderString.concat("Appetizer: ");
			orderString = orderString.concat("[");
			
			System.out.println("Appetizer Menu:");
			System.out.println("0 - Nothing \n1 - Oysters \n2 - Grilled Cheese \n3 - Hummus \nEnter the number selection:");
			choice = readInt(scnr);
		
		return choice;		
		
		} 
		
		public static int menu (Scanner scnr, String userName, String orderString) {
			int choice, choice1, choice2, choice3;

				System.out.println("Select from menu " + userName + ":");
				System.out.println("0 - Nothing \n1 - Appetizer\n2 - Main Course \n3 - Dessert \nEnter the number for your selection:");
				choice = readInt(scnr); 
				System.out.println();
			
			return choice;
		}
		
		public static void main(String [] args) {
			Scanner scnr = new Scanner(System.in);
			
			String oysters = "", grilledCheese = "", hummus = "";
			String oliveOil = "", paprika = "", olives = "";
			String userName = "", orderString = "", orderAswr = "";
			int  choice;
			int  choice1, choice1_5, choice1_5_5;
			int choice2, choice2_5, choice2_5_5;
			int choice3, choice3_5, choice3_5_5;
			
			System.out.println("Welcome to the Food Festival \nWould you like to place an order?");
			orderAswr = scnr.next();
					
			while (!(orderAswr.equalsIgnoreCase("yes") || orderAswr.equalsIgnoreCase("no"))) {
				System.out.println("Welcome to the Food Festival \nWould you like to place an order?");
				orderAswr = scnr.next();
			}
				 
			if (orderAswr.equalsIgnoreCase("yes")) {
				System.out.println("What is your name for the order?");
				userName = scnr.next();
				choice = 0;
				while (true) {
					choice = menu(scnr, userName, orderString);
					if(choice == 0)
						break;
					if (choice == 1) {
						
						choice1 = 0;
						while (true) {
							orderString = orderString.concat("Appetizer: ");
							orderString = orderString.concat("[");
							choice1 = aptzMenu(scnr, orderString);
							if(choice1 == 0)
								break;
							
		// ------------------------------- APPETIZER MENU BELOW ------------------------------------------------------------
						
							if (choice1 == 1) {
								oysters = "Oysters";		
								orderString = orderString.concat(" " + oysters + ":");
								choice1_5 = 0;
								 while (true) {
									 choice1_5 = toppingsMenuAMC(scnr, orderString, choice1);
									 if(choice1_5 == 0)
										 break;
									 
									 // --------- TOPPINGS MENU BELOW ------------------------------------------------------------							 
								
									 if (choice1_5 == 1) {
										 oliveOil = " Olive Oil,";
										 orderString = orderString + oliveOil;
										 System.out.println(orderString);
									 }
									else if (choice1_5 == 2) {
										paprika = " Paprika,";
										orderString = orderString + paprika;
										System.out.println(orderString);
									}
									else if (choice1_5 == 3) {
										olives = " Olives,";
										orderString = orderString + olives;
										System.out.println(orderString);
									}
								 
									//  --------- TOPPINGS MENU ABOVE ------------------------------------------------------------	
								 
								 }
							}
							else if (choice1 == 2) {
								grilledCheese = "Grilled Cheese";
								orderString = orderString.concat(" " + grilledCheese + ":");
								choice1_5 = 0;
								 while (true) {
									 choice1_5 = toppingsMenuAMC(scnr, orderString, choice1); 
									 if(choice1_5 == 0)
										 break;
									 
									 // --------- TOPPINGS MENU BELOW ------------------------------------------------------------							 
										
									 if (choice1_5 == 1) {
										 oliveOil = " Olive Oil,";
										 orderString = orderString + oliveOil;
										 System.out.println(orderString);
									 }
									else if (choice1_5 == 2) {
										paprika = " Paprika,";
										orderString = orderString + paprika;
										System.out.println(orderString);
									}
									else if (choice1_5 == 3) {
										olives = " Olives,";
										orderString = orderString + olives;
										System.out.println(orderString);
									}
								 
									 //  --------- TOPPINGS MENU ABOVE ------------------------------------------------------------	
								 
								 }
							}
							else if (choice1 == 3) {
								hummus = "Hummus";
								orderString = orderString.concat(" " + hummus + ":");
								choice1_5 = 0;
								 while (true) {
									 choice1_5 = toppingsMenuAMC(scnr, orderString, choice1); 
									 if(choice1_5 == 0)
										 break;
									 
									 // --------- TOPPINGS MENU BELOW ------------------------------------------------------------							 
										
									 if (choice1_5 == 1) {
										 oliveOil = " Olive Oil,";
										 orderString = orderString + oliveOil;
										 System.out.println(orderString);
									 }
									else if (choice1_5 == 2) {
										paprika = " Paprika,";
										orderString = orderString + paprika;
										System.out.println(orderString);
									}
									else if (choice1_5 == 3) {
										olives = " Olives,";
										orderString = orderString + olives;
										System.out.println(orderString);
									}
								 
									//  --------- TOPPINGS MENU ABOVE ------------------------------------------------------------	
								 }
							}				
						}
					} // END OF OPTION 1(MAIN MENU)
					
					
					else if (choice == 2) {
						choice2 = 0;
						while (true) {
							choice2 = mainCourseMenu(scnr, orderString);
							if(choice2 == 0)
								break;
							
		// ------------------------------- MAIN COURSE MENU BELOW ------------------------------------------------------------

							
							
							
						}
					} // END OF OPTION 2(MAIN MENU)
					
					
					
					
					
					
					
					
					else if (choice == 3) {
						choice3 = 0;
						while (true) {
							choice3 =  dessertMenu(scnr, orderString);
							if(choice3 == 0)
								break;
						}
					} // END OF OPTION 3(MAIN MENU)
					
					
					
				}
			}	
			else {
				System.out.println("Thank you for stopping by, maybe next time you�ll sample our menu.");
				System.exit(0);	
			}
			
			System.out.println("Here's your order " + userName + ":\n" + orderString);
			System.out.println("Enjoy your meal!");
			
		}
	
}



