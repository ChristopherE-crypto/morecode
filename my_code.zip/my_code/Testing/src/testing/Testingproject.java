package testing;

import java.util.Scanner;

public class Testingproject {
	static void display(String menu[]) {
		for(int i = 0; i < menu.length; i++) {
			System.out.println(i + " - " + menu[i]);
		}
		System.out.print("Enter the number for your selection: ");
	}
	
	public static void main(String [] args) {
		String mainMenu[] = {"Nothing", "Appetizer", "Main Course", "Dessert"};
		String dessertMenu[] = {"Nothing", "Baklava", "Rice Pudding", "Chocolate Cake"};
		String appetizerMenu[] = {"Nothing", "Oysters", "Grilled Octopus", "Hummus"};
		String mainCourseMenu[] = {"Nothing", "Steak", "Chicken", "Fish"};
		String toppingsMenu[] = {"Nothing", "Olive Oil", "Paprika", "Olives"};
		
		String list = "";
		
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Welcome to the food festival!");
		System.out.println("Would you like to place an order?");
		String ans = scnr.next();
		
		if(ans.equalsIgnoreCase("No")) {
			System.out.println("Thank you for stopping by, maybe next time you'll sample our menu");
			return;
		}
		if(ans.equalsIgnoreCase("Yes")) {
			System.out.print("What is your name for the order?");
			String name = scnr.next();
			
			int m, n, k;
			
			System.out.println("Select from menu, " + name);
			while(true) {
				display(mainMenu);
				
				n =  scnr.nextInt();
				if(n == 0)
					break;
				switch(n) {
				case 1:
					System.out.println("Appetizer Menu:");
					display(appetizerMenu);
					
					m = scnr.nextInt();
					list = list + "Appetizer:[" + appetizerMenu[m] + ": ";
					
					while(true) {
						display(toppingsMenu);
						k = scnr.nextInt();
						if(k == 0)
							break;
						list = list + toppingsMenu[k] + ", ";
					
					}
					list =  list + "]\n";
					break;
				case 2:
					System.out.println("Main Course Menu:");
					display(mainCourseMenu);
					
					m =  scnr.nextInt();
					list = list + "Main Course: [" + mainCourseMenu[m] + "]\n";
					break;
				case 3:
					System.out.println("Dessert Menu:");
					display(dessertMenu);
					m = scnr.nextInt();
					list =  list + "Dessert: [" + dessertMenu[m] + "]\n";
				}
			}
			System.out.println("Here is your order " + name);
			System.out.println(list);
			System.out.println("Enjoy your meal!");
			
		}
	}

}
