package testing;
import java.util.Scanner;

public class WordCounter {
	
	public static void main(String [] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Hello user, what is your name?");
		String name = scnr.next();
		
		System.out.println("Hi " + name + ", my name is 001 and I calculate things for you!");
		System.out.println("Enter two numbers: ");
		
		double a = scnr.nextInt();
		double b = scnr.nextInt();
		
		System.out.println("Enter a number to execute an operation: ");
		System.out.println("1 - Addition");
		System.out.println("2 - Subtraction");
		System.out.println("3 - Multiplication");
		System.out.println("4 - Division");
		System.out.println("Enter 0 to exit.");
		
		String sign = scnr.next();
		
		if(sign.equals("1")) {
			double sum = a + b;
			
			for(int i = 1; i <= sum; i++) {
				System.out.println("Processing...");
			}
			System.out.println("Process completed!");
			System.out.println(sum);
			
		}
		else if(sign.equals("2")) {
			double sub = a - b;
			
			for(int i = 1; i <= sub; i++) {
				System.out.println("Processing...");
			}
			System.out.println("Process completed!");
			System.out.println(sub);
		}
		else if(sign.equals("3")) {
			double mult = a*b;
			
			for(int i = 1; i <= mult; i++) {
				System.out.println("Processing...");
			}
			System.out.println("Process completed!");
			System.out.println(mult);
		}
		else if(sign.equals("4")) {
			double div = a/b;
			
			for(int i = 1; i <= div; i++) {
				System.out.println("Processing...");
			}
			System.out.println("Process completed!");
			System.out.println(a/b);
		}
		else {
			System.out.println("Enter number 1-4 or 0 to exit.");
		}
		
	}
	
		    
		    
		
		

		
	

}
