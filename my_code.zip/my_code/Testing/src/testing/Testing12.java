package testing;
import java.util.Scanner;

public class Testing12 {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("Enter the number of rows: ");
	int n = scnr.nextInt();
	
	int i, j;  
    for(i=1; i<=n; i++) //outer loop for number of rows(n)
    { 
    for(j=2*(n-i); j>=0; j--) // inner loop for spaces 
        {           
            System.out.print(" "); // printing space
        } 
        for(j = i; j <= i; j++) //  inner loop for columns
        {       
            System.out.print(j); // print star
        }           
        System.out.println(); // ending line after each row
    } 
} 
	
}

