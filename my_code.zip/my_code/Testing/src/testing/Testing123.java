package testing;

import java.util.Scanner;

public class Testing123 {
public static void main(String [] args) {
	
//	int s = 0;
	
	
//	for(int i = 1; i <= 100; i++) {
//		s = s + i;
//	}
//	System.out.println("The sum is " + s);
	
	int A_grades = 0;
    int B_grades = 0;
    int C_grades = 0;
    int D_grades = 0;
    int F_grades = 0;
int count=0;
Scanner in = new Scanner(System.in);
System.out.println("Enter exam score as integer percentage in range 0 to 100");
System.out.println("And enter a negative score at the end of the list :");
int score = in.nextInt();
while(score>0)
 {
	System.out.println("Enter exam score as integer percentage in range 0 to 100");
   count++;
if(score>=90 && score<=100)
    A_grades++;
else if(score>=80 && score<=89)
    B_grades++;
else if(score>=70 && score<=79)
    C_grades++;
else if(score>=60 && score<=69)
    D_grades++;
else if(score>=0 && score<=59)
    F_grades++;
score = in.nextInt();
} //end while
System.out.println("Total number of grades :"+ count);
System.out.println("Total number of A grades :"+ A_grades);
System.out.println("Total number of B grades :"+ B_grades);
System.out.println("Total number of C grades :"+ C_grades);
System.out.println("Total number of D grades :"+ D_grades);
System.out.println("Total number of F grades :"+ F_grades);
	
	
	
	
	
	
	
	
	
	
	
	
}
}
