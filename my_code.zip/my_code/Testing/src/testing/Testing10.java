package testing;

public class Testing10 {
public static void main(String [] args) {
	
	System.out.print("Will start baking");
	
	for(int cookieNum = 0; cookieNum < 5; cookieNum++) {
		
		System.out.print("\ninside loop");
		if(cookieNum == 3){
			System.out.println(" DO NOT BAKE ANOTHER COOKIE!");
			break;
		}
		System.out.println(" bake a cookie");
		
	}
	System.out.print("\ndone baking");
	
	for(int cookieNum = 5; cookieNum > 0; cookieNum--) {
		System.out.print("\ninside loop");
		
		if(cookieNum == 3) {
			System.out.println(" look at cookie # "+ cookieNum);
		}
		
		System.out.println(" eat cookie # "+ cookieNum);
		
	}
	
	System.out.print("\ndone eating cookies");
	
	
	System.out.print("\n\n\nDone WITH EVERYTHING");
	
}
}
