package testing;
import java.util.Scanner; //https://youtu.be/usoVRc3C8Fs

public class Foodfestivaltesting {
	
	public static void displayMainMenu(String name) {
		
		System.out.println("Select from the menu " + name);
		System.out.println("0 - Nothing");
		System.out.println("1 - Appetizer");
		System.out.println("2 - Main Course");
		System.out.println("3 - Dessert");
		System.out.println("Enter the number for your selection:");
	}
	
	public static void displayMainCourse() {
		
		System.out.println("Main Course Menu:");
		System.out.println("0 - Nothing");
		System.out.println("1 - Steak");
		System.out.println("2 - Chicken");
		System.out.println("3 - Roast Beef");
		System.out.println("Enter the number for your main selection:");
	}
	
	public static void displayAppetizers() {
		
		System.out.println("Appetizer Menu:");
		System.out.println("0 - Nothing");
		System.out.println("1 - Oysters");
		System.out.println("2 - Grilled Salmon");
		System.out.println("3 - Caesar Salad");
		System.out.println("Enter the number for your appetizer selection:");
	}
	
	public static void displayDessert() {
		
		System.out.println("Dessert Menu:");
		System.out.println("0 - Nothing");
		System.out.println("1 - Vanilla Ice Cream");
		System.out.println("2 - Rice Pudding");
		System.out.println("3 - Chocolate Cake");
		System.out.println("Enter the number for your appetizer selection:");
	}
	
	public static void displayToppings() {
		
		System.out.println("Toppings Menu:");
		System.out.println("0 - Nothing");
		System.out.println("1 - Olive Oil");
		System.out.println("2 - Black Pepper Powder");
		System.out.println("3 - Olives");
		System.out.println("Enter the number for your topping selection:");
	}
	
	public static void displayDessertTop() {
		
		System.out.println("Toppings Menu:");
		System.out.println("0 - Nothing");
		System.out.println("1 - Powdered Sugar");
		System.out.println("2 - Syrup");
		System.out.println("3 - Nuts");
		System.out.println("Enter the number for your topping selection:");
	}
	
	public static void main(String [] args) {
		Scanner scnr = new Scanner(System.in);
		
		String order = "";
		
		String oysters = "";
		String grilled_Sal = "";
		String caesar = "";
		
		String olive_Oil = "";
		String blackPepper = "";
		String olives = "";
		
		String olive_Oil2 = "";
		String blackPepper2 = "";
		String olives2 = "";
		
		String steak = "";
		String chicken = "";
		String roastB = "";
		
		String vanilla = "";
		String rice_Pud = "";
		String choc_Cake = "";
		
		String powSugar = "";
		String syrup = "";
		String nuts = "";
		
		System.out.println("Welcome to the food festival!");     //This part welcomes the user and asks if the person wants to place an order.
		System.out.println("Would you like to place an order?");
		String answer = scnr.next();
		
		while(!(answer.equalsIgnoreCase("Yes") || (answer.equalsIgnoreCase("No")))) {
			System.out.println("Would you like to place an order?");
			answer = scnr.next();
		}
		
		if(answer.equalsIgnoreCase("No")) { //If the user enters "No", print the message and end the program.
			System.out.println("Thanks for stopping by, maybe next time you'll sample our menu.");
			
		}
		if(answer.equalsIgnoreCase("Yes")) { //If the user enters "Yes", ask for the user's name and continue with the program.
			System.out.println("What's your name for the order?");
			String name = scnr.next();  //The user's name is stored in a variable.
			
			
		
			while(true) { //Infinite loop that keeps displaying the main menu until the user enters 0.
				
				displayMainMenu(name);
				
				int a = scnr.nextInt();
				
				if(a == 0) 
				
					break;
				
				switch(a) {
					
				case 1:
					
					
					displayAppetizers(); //It displays the appetizer menu.
					
					int a1 = scnr.nextInt();
					
					
					if(a1 == 1) //If the user enters 1, then the String oysters is assigned with "Oysters", so later it can be user for the order. 
						
						oysters = "Oysters";
					
					
					if(a1 == 2) //Same thing as before. 
						
						grilled_Sal = "Grilled Salmon";
					
					if(a1 == 3)
						
						caesar = "Caesar Salad";
					
					
					while(true) { //Infinite loop that keeps displaying the toppings until the user enters 0.
						
						displayToppings();
						
						int a2 = scnr.nextInt();
						
						if(a2 == 1)
							
							olive_Oil = "Olive Oil";
						
						if(a2 == 2)
							
							blackPepper = "Black Pepper Powder";
						
						if(a2 == 3)
							
							olives = "Olives";
						
						if(a2 == 0)
							break;
						
						
					}
					break;
					
				case 2:
					
					displayMainCourse();
					
					int a3 = scnr.nextInt();
					
					if(a3 == 1)
						
						steak = "Steak";
					
					if(a3 == 2)
						
						chicken = "Chicken";
					
					if(a3 == 3)
						
						roastB = "Roast Beef";
					
                    while(true) {
						
						displayToppings();
						
						int a2 = scnr.nextInt();
						
						if(a2 == 1)
							
							olive_Oil2 = "Olive Oil";
						
						if(a2 == 2)
							
							blackPepper2 = "Black Pepper Powder";
						
						if(a2 == 3)
							
							olives2 = "Olives";
						
						if(a2 == 0)
							break;
						
					}
					
					break;
					
				case 3:
					
					displayDessert();
					
					int a4 = scnr.nextInt();
					
					if(a4 == 1)
						
						vanilla = "Vanilla Ice Cream";
					
					if(a4 == 2)
						
						rice_Pud = "Rice Pudding";
					
					if(a4 == 3)
						
						choc_Cake = "Chocolate Cake";
					
					while(true) {
						
						displayDessertTop();
						
						int aZ = scnr.nextInt();
						
						if(aZ == 1)
							
							powSugar = "Powdered Sugar, ";
						
						if(aZ == 2)
							
							syrup = "Syrup, ";
						
						if(aZ == 3)
							
							nuts = "Nuts";
						
						if(aZ == 0)
							break;
					}
					break;
					
				}


					
			
		}
			
			if(olive_Oil.equals("Olive Oil") && blackPepper.equals("Black Pepper Powder")) {
				olive_Oil = "Olive Oil, ";
				blackPepper = "Black Pepper Powder";
			}
			if(blackPepper.equals("Black Pepper Powder") && olives.equals("Olives")) {
				blackPepper = "Black Pepper Powder, ";
				olives = "Olives";
			}
			if(olive_Oil.equals("Olive Oil, ") && blackPepper.equals("Black Pepper Powder") && olives.equals("Olives")) {
				olives = ", Olives";
			}
			if(olive_Oil2.equals("Olive Oil") && blackPepper2.equals("Black Pepper Powder")) {
				olive_Oil2 = "Olive Oil, ";
				blackPepper2 = "Black Pepper Powder";
			}
			if(blackPepper2.equals("Black Pepper Powder") && olives2.equals("Olives")) {
				blackPepper2 = "Black Pepper Powder, ";
				olives2 = "Olives";
			}
			if(olive_Oil2.equals("Olive Oil, ") && blackPepper2.equals("Black Pepper Powder") && olives2.equals("Olives")) {
				olives2 = ", Olives";
			}
			
			//This last part outputs the user's order. 
			System.out.println("Here's your order " + name + ":");
			order = "Appetizer: [" + oysters + grilled_Sal + caesar + ": " + olive_Oil + blackPepper + olives + "]\nMain Course: [" + steak + chicken + roastB + ": " + olive_Oil2 + blackPepper2 + olives2 + "]\nDessert: [" + vanilla + rice_Pud + choc_Cake + ": " + powSugar + syrup + nuts + "]\n";
			System.out.println(order);
			System.out.println("Enjoy your meal!");
			
		}
			
			

}
}
