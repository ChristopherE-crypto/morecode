package testing;
import java.util.Scanner;

public class Testing1 {
public static void main(String [] Args) {
	Scanner scnr = new Scanner(System.in);
	
	int userAge;
	int userAgeDays;
	int userAgeHours;
	int userAgeMin;
	int userTotalHeartBeat;
	int avgBeatsPerMin = 72;
	
	System.out.println("Enter your age: ");
	userAge = scnr.nextInt();
	
	userAgeDays = userAge * 365;
	userAgeDays = userAgeDays + (userAge / 4);
	
	System.out.println("You are "+ userAgeDays + " days old.");
	
	userAgeHours = userAgeDays * 24;
	
	System.out.println("You are "+ userAgeHours + " hours old.");
	
	userAgeMin = userAgeHours * 60;
	
	System.out.println("You are "+ userAgeMin + " minutes old.");
	
	userTotalHeartBeat = userAgeMin * avgBeatsPerMin;
	
	System.out.println("Your heart has beat "+ userTotalHeartBeat + " Times.");
	
	
	
}
}
