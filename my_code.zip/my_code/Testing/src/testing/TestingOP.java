package testing;
import java.util.Random;
import java.util.Scanner;

public class TestingOP {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	Random rand = new Random();
	
	System.out.println("Enter 0 for rock, 1 for paper and 2 for scissors.");
	int userNum = scnr.nextInt();
	
	if(userNum == 0) {
		System.out.println("ROCK");
	}
	if(userNum == 1) {
		System.out.println("PAPER");
	}
	if(userNum == 2) {
		System.out.println("SCISSORS");
	}
	
	int randNum = rand.nextInt(3);
	
	switch (randNum) {
	case 0:
		System.out.println("ROCK!");
		break;
	case 1:
		System.out.println("PAPER!");
		break;
	case 2:
		System.out.println("SCISSORS");
		break;
	default:
		System.out.println("ERROR");
		break;
	}
	
	if(userNum == 0 && randNum == 2) {
		System.out.println("You win.");
	}
	else if(userNum == 1 && randNum == 0) {
		System.out.println("You win.");
	}
	else if(userNum == 2 && randNum == 1) {
		System.out.println("You win.");
	}
	else if(userNum == 0 && randNum == 1) {
		System.out.println("You suck.");
	}
	else if(userNum == 1 && randNum == 2) {
		System.out.println("You suck.");
	}
	else if(userNum == 2 && randNum == 0) {
		System.out.println("You suck.");
	}
	else if(userNum == 0 && randNum == 0) {
		System.out.println("...");
	}
	else if(userNum == 1 && randNum == 1) {
		System.out.println("...");
	}
	else if(userNum == 2 && randNum == 2) {
		System.out.println("...");
	}
   }
}
