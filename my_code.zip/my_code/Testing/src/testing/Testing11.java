package testing;

import java.util.Scanner;

public class Testing11 {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("Enter a word");
	String word = scnr.next();
	
	System.out.println("You entered: " + word);
	
	for(int i = 0; i < word.length(); i++) {
		System.out.print(word.charAt(i) + " ");
		
	}
	
	
}
}
