package testing;

public class TesingLoops {

	public static void main(String[] args) {
		
	//	for(int numCookies = 3; numCookies > 0; numCookies = numCookies -= 2) {
	//		System.out.println("Eat a cookie");
	//	}
		
   // int numCookies = 3;
    //while(numCookies > 0) {
    	//System.out.println("Eat a cookie");
    	//numCookies--;
		//int numCookies = 3;
		//do {
			//System.out.println("Eat a cookie");
			//numCookies--;
		//}while(numCookies > 0); 	
    }
	}


