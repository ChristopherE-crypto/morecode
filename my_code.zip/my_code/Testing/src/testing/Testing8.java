package testing;
import java.util.Scanner;

public class Testing8 {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	
	int s;
	double tip, amount;
	tip = 0;
	System.out.println("Enter the satisfaction level - 1: Totally satisfied, 2: Satisfied, 3: disatified");
	s = scnr.nextInt();
	System.out.println("Enter the amount: ");
	amount = scnr.nextDouble();
	
	if(s == 1) {
		tip = amount * 0.2;
	}
	else if( s == 2) {
		tip = amount * 0.15;
	}
	else if(s == 3) {
		tip = amount * 0.1;
	}
	System.out.println("Satisfaction level " + s + " tip = $" + tip);
	
	
}
}
