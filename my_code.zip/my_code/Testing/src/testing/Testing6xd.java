package testing;

public class Testing6xd {
public static void main(String [] args) {

	int degrees = 93;
	if(degrees > 80) {
		
		System.out.println("Go to the beach.");
	}
	else if(degrees > 70) {
		
		System.out.println("Go to the park.");
	}
	else if(degrees > 30) {
		System.out.println("Go to the movies.");
	}
	else {
		System.out.println("Hide and put the heat on it's COLD OUT!!!");
	}
	
	
	
	
	
	
	
    }
}
