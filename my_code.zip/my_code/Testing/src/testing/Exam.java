package testing;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Random;
import java.util.Scanner;

public class Exam {
	
	

	
	
	
	
		
		
	public static void main(String [] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		String myString = scnr.next();






		
		








			
			








		System.out.println(myString);
}
}
