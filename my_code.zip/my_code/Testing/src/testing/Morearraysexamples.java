package testing;

import java.util.Arrays;
import java.util.Scanner;

public class Morearraysexamples {
	
	//public static int [] sumsthenumbersofanarray() {
		
	     // Scanner scnr = new Scanner(System.in);
	     // final int SCORES_SIZE = 4;
	     // int[] bonusScores = new int[SCORES_SIZE];
	     // int i;

	     // for (i = 0; i < bonusScores.length; ++i) {
	     //    bonusScores[i] = scnr.nextInt();
	     // }

	    //  for(i = 0; i < bonusScores.length - 1; i++){
	    //     bonusScores [i] += bonusScores [i + 1];
	    //  }

	    //  for (i = 0; i < bonusScores.length; ++i) {
	     //    System.out.print(bonusScores[i] + " ");
	    //  }
	   //   System.out.println();
	//}
	
	//public static int [] rotateselemsinanarray1totheleft() {
		
	//	Scanner scnr = new Scanner(System.in);
	    //  final int SCORES_SIZE = 4;
	    //  int[] oldScores = new int[SCORES_SIZE];
	    //  int[] newScores = new int[SCORES_SIZE];
	    //  int i;

	    //  for (i = 0; i < oldScores.length; ++i) {
	    //     oldScores[i] = scnr.nextInt();
	    //  }
	   //   for(i = oldScores.length - 1; i >= 0; i--){
	     //    if(i == 0){
	     //       int temp = oldScores[3];
	      //      newScores[3] = oldScores[0];
	     //       newScores[2] = temp;
	      //      newScores[0] = oldScores[1];
	     //       newScores[1] = oldScores[2];
	     //    }
	         
	 //     }

	   //   for (i = 0; i < newScores.length; ++i) {
	    //     System.out.print(newScores[i] + " ");
	    // }
	    //  System.out.println();
	//}
	
	public static void reverseVals(int[] arrVals) {
		int i;             // Loop index
	    int tempValue;

	      for (i = 0; i < (arrVals.length / 2); ++i) {
	         tempValue = arrVals[i]; // Do swap
	         arrVals[i] = arrVals[arrVals.length - 1 - i];
	        arrVals[arrVals.length - 1 - i] = tempValue;
	      }
	}
	
	//Public static void main(String [] args){
	
	//Scanner scnr = new Scanner(System.in);
   // final int NUM_VALUES = 8;              // Array size
   // int[] userVals = new int[NUM_VALUES];  // User values
   // int i;                                 // Loop index

    // Prompt user to populate array
   // System.out.println("Enter " + userVals.length + " values...");
   // for (i = 0; i < userVals.length; ++i) {
    //   System.out.print("Value:  ");
   //    userVals[i] = scnr.nextInt();
   // }

    // Call method to reverse array values
   // reverseVals(userVals);

    // Print updated arrays
  //  System.out.print("\nNew values: ");
  //  for (i = 0; i < userVals.length; ++i) {
   //    System.out.print(userVals[i] + " ");
   // }
  //  System.out.println();
// }
	
	
	public static void main(String [] args) {
		Scanner scnr = new Scanner(System.in);
		
		int [] myArr = {1, 2, 3, 4, 5};
		
		reverseVals(myArr);
		
		System.out.println(Arrays.toString(myArr));
		}
		
		      
	}


