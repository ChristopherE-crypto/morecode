package testing;

public class Firstarrays {
	
	public static void displayArray(int [] arr) {
		
		for(int i = 0; i < arr.length; i++) {
			System.out.println("val at index " + i + ": " + arr [i]);
		}
		
		
	}
	
	
	
	
	public static void main(String [] args) {
		
		//int [] scores = new int [20];
		
		//scores[3] = 99;
		//scores[7] = 54;
		//scores[3] = 87;
		
		//System.out.println("YIPPE we have a value at index 3 " + scores[3]);
		
		int [] scores = {82, 97, 66, 78, 34, 21, 10};
		
		displayArray(scores);
		
		System.out.println("Val at index 0 " + scores[0]);
		System.out.println("Val at index 2 " + scores[2]);
		System.out.println("Val at index 3 " + scores[3]);
		System.out.println("Val at index 4 " + scores[4]);
		
		int temp = scores [3];
		scores [3] = scores[0];
		scores [0] = temp;
		System.out.println("After swapping!");
		
		System.out.println("Val at index 0 " + scores[0]);
		System.out.println("Val at index 2 " + scores[2]);
		System.out.println("Val at index 3 " + scores[3]);
		System.out.println("Val at index 4 " + scores[4]);
	}
	

}
