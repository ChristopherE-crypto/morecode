package testing;
import java.util.Scanner;
import java.util.Random;

public class Testing2 {
public static void main(String [] args) {
	Scanner scnr = new Scanner(System.in);
    Random randGen = new Random();
    int seedVal;

    seedVal = scnr.nextInt();
    randGen.setSeed(seedVal);

    seedVal = randGen.nextInt(6);
    
    
 
    System.out.println(seedVal);
    System.out.println(seedVal);

	
	
}
}
