package testing;

public class NEstedLoops {

	public static void main(String[] args) {
		
		int rows = 5;
		for(int i = 1; i <= rows; i++) {
			for(int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
		
		
		
//	for(char ltr = 'A'; ltr < 'G'; ltr++) {	
//	    for(int i = 0; i < 10; i++) {
//		System.out.println(ltr + " " + i);
//	    }
//	}
		

	}

}
