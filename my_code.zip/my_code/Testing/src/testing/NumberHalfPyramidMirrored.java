package testing;

import java.util.Scanner;

public class NumberHalfPyramidMirrored {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int size = 5;
		for(int j = 1; j <= size; j++) {
			int num = 1;
		    for(int i = size; i >= 1; i--) {
		    	if(i > j) {
			      System.out.print(" ");
		    	}
		    	else {
		    	  System.out.print(i);
		    	}
		    	num++;
		    	
		     }
		System.out.println();
		}

	}

}
