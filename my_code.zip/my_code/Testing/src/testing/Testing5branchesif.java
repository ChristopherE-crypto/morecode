package testing;
import java.util.Scanner;

public class Testing5branchesif {
public static void main(String [] args) {
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("What is your name?");
	String name = scnr.next();
	
	if(name.equals("Joseph")) {
		
		System.out.println("Eres un manco con Yasuo.");
		System.out.println("Te gusta Yasuo?");
		String sino = scnr.next();
		if(sino.equals("Si")) {
			
			System.out.println("No tienes manos.");
		}
		else {
			System.out.println("Deja de jugar Yasuo.");
		}
	}
	else if(name.equals("Jose")) {
		
		System.out.println("You are pendejo.");
		System.out.println("Do you like Roblox?");
		String yesno = scnr.next();
		if(yesno.equals("Yes")) {
			
			System.out.println("Stop hacking you noob");
			
		}
		else {
			
			System.out.println("Then stop playing XD.");
		}
	}
	
}
}
