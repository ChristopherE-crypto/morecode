package testing;
import java.util.Scanner;
public class Bromoment {
	
	//public static int f(int x) {
		
	//	int y = 1;
	//	x = x + y;
	//	System.out.println("In f: x = " + x);
	//	return x;
	//}
	
	//public static void main(String [] args) {
		
	//	int x = 3;
	//	int y = 2;
	//	int z = f(x);
	//	
	//	System.out.println("z = " + z);
	//	System.out.println("x = " + x);
	//	System.out.println("y = " + y);
	//}
	
	//public static int getIndexOf(String s, char c) {
		
		//for(int i = 0; i < s.length(); i++) {
			
		//	if(s.charAt(i) == c)
			//	return i;
		//}
		//return -1;
	//}
	
	//public static String convert(String str)
    //{

        // Create a char array of given String
       // char ch[] = str.toCharArray();
       // for (int i = 0; i < str.length(); i++) {

            // If first character of a word is found
        //    if (i == 0 && ch[i] != ' ' || 
          //      ch[i] != ' ' && ch[i - 1] == ' ') {

                // If it is in lower-case
            //    if (ch[i] >= 'a' && ch[i] <= 'z') {

                    // Convert into Upper-case
             //       ch[i] = (char)(ch[i] - 'a' + 'A');
            //    }
          //  }

            // If apart from first character
            // Any one is in Upper-case
            //else if (ch[i] >= 'A' && ch[i] <= 'Z') 

                // Convert into Lower-Case
               // ch[i] = (char)(ch[i] + 'a' - 'A');
        //}

        // Convert the char array to equivalent String
        //String st = new String(ch);
        //return st;
   // }
	
	public static void main(String [] args) {
		Scanner scnr = new Scanner(System.in);
		String s = scnr.nextLine();
		
		s = s.toLowerCase();
		//System.out.println(getIndexOf("Hello world!", 'v'));
		//int a = scnr.nextInt();
		//int b = scnr.nextInt();
		//int c = scnr.nextInt();
		
		//if((a <= b &&  b <= c) || (c <= b && b <= a))
		//	System.out.println(b);
		
		//else if((b <= a && a <= c) || (c <= a && a <= b))
		//	System.out.println(a);
		
		//else
		//	System.out.println(c);
		
		String words [] = s.split("\\s");
	    String capitalizeWord = "";
		for(String w: words) {
			String first = w.substring(0,1);
			String afterfirst = w.substring(1);
			capitalizeWord += first.toUpperCase() + afterfirst + " ";
		}
	     System.out.println(capitalizeWord.trim());
		//System.out.println(convert(str));
		
		

		}

}

