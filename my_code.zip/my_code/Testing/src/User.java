
public class User {

	public static void main(String[] args) {
		ArrayClass arr = new ArrayClass();
		
		arr.print();
		
		//insert 3 at position 1
		arr.insert(1, 3);
		System.out.println();
		arr.print();
		
		arr.delete(3);
		
		System.out.println();
		
		arr.print();

	}

}
