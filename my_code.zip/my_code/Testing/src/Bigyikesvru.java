import java.util.Scanner;
public class Bigyikesvru {
	
	//public static char getCharAtIndex (String s, int index) {
		
	//	if(index < 0 || index >= s.length()-1) {
			//return '?';
		//}
		//char chr;
		
		//chr = s.charAt(index);
		
		//return chr;
	//}
	
	public static void main(String [] args) {
		Scanner scnr = new Scanner(System.in);
		
		String s = scnr.nextLine();
		//int index = scnr.nextInt();
		//System.out.println(getCharAtIndex(s, index));
		
		Scanner in = new Scanner(System.in);
	     System.out.print("Input a Sentence: ");
		 String line = in.nextLine();
		 String upper_case_line = ""; 
	       Scanner lineScan = new Scanner(line); 
	         while(lineScan.hasNext()) {
	             String word = lineScan.next(); 
	             upper_case_line += Character.toUpperCase(word.charAt(0)) + word.substring(1) + " "; 
	         }
	      System.out.println(upper_case_line.trim());
	      
	}

}
