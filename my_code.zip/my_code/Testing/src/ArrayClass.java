import java.util.Random;

public class ArrayClass {
	
	private int [] myArray;
	private int size = 5;
	
	Random rand = new Random();
	
	public ArrayClass() {
	myArray = new int [10];
	
	for(int i = 0; i < size; i++) {
		myArray[i] = rand.nextInt(10);
	}
	
	}
	
	public int delete(int index) {
		for(int i = index; i < size + 1; i++) {
			if(i != myArray.length - 1)
				myArray[i] = myArray[i + 1];
			else
				myArray[i] = 0;
		}
		if(index < size)
			size--;
		return size;
	}
	
	public int insert(int index, int x) {
		if(size < myArray.length) {
			for(int i = size - 1; i >= index; i--) {
				myArray[i + 1] = myArray[i];
			}
			myArray[index] = x;
			}
			if(index < size)
			size++;
			else
				size = index + 1;
			return size;
	}
    public void print() {
		for(int i = 0; i < myArray.length; i++) {
			System.out.print(myArray[i] + " ");
		}
	}

}
