
public class Rubric {

	/*Has 2 or more classes.
	 * Greets & Prompts the user: "Hello, my name is Eliza. What is your name?
	 * Greets the user by name and initiates dialogue: "Hello ____. Tell me what is on your mind in one sentence".
	 * Uses the 1st word from the user input to form another prompt replacing the the appropriate place holder in the random sentence.
	 * Uses last word from user input to form another prompt replacing the the appropriate place holder in the random sentence.
	 * Uses methods that work with the starter code and the arrays to build the random statements and questions accordingly.
	 *Evaluates punctuation '?' and prompts the user with a question.
	 *Evaluates punctuation '!' and prompts the user with a statement prefixed by �WOW! Dramatic!
	 *Evaluates punctuation '.' or any other character and prompts the user with a statement.
	 *Repeats dialogue until user types "EXIT" independent of upper or lower case.
	 *Confirm the user's intention to exit by prompting them if they want to run the session again.
	 *if "YES" independent of upper or lower case.
	 *if "NO" independent of upper or lower case, say �Goodbye, until next time� and exit the application. 
	*/
	
}
