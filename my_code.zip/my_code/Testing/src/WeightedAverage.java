import java.util.Scanner;

public class WeightedAverage {
	
	public static final double WEIGHT_PC = 0.10;
	public static final double WEIGHT_HW = 0.15;
	public static final double WEIGHT_PROJECTS = 0.15;
	public static final double WEIGHT_EXAMS = 0.60;

	public static void main(String[] args) {
		
		int numPCs, numHWs, numProjects, numExams;
		double avgPC, avgHW, avgProjects, avgExams;
		
		double [] scoresPC;
		double [] scoresHW;
		double [] scoresProjects;
		double [] scoresExams;
		
		Scanner scnr = new Scanner(System.in);
		System.out.println("How many P&C");
		numPCs = scnr.nextInt();
		scoresPC = new double [numPCs];
		
		System.out.println("How many HW");
		numHWs = scnr.nextInt();
		scoresHW = new double [numHWs];
		
		System.out.println("How many Projects");
		numProjects = scnr.nextInt();
		scoresProjects = new double [numProjects];
		
		System.out.println("How many Exams");
		numExams = scnr.nextInt();
		scoresExams = new double [numExams];
		
//		for(int i = 0; i < numPCs; i++) {
//			System.out.println("Enter PC " + (i + 1) + " score:");
//			scoresPC[i] = scnr.nextDouble();
//		}
		promptAndStoreScores(scoresPC, scnr, "PC");
//		
//		for(int i = 0; i < numHWs; i++) {
//			System.out.println("Enter HW " + (i + 1) + " score:");
//			scoresHW[i] = scnr.nextDouble();
//		}
		promptAndStoreScores(scoresHW, scnr, "HW");
//		
//		for(int i = 0; i < numProjects; i++) {
//			System.out.println("Enter Project " + (i + 1) + " score:");
//			scoresProjects[i] = scnr.nextDouble();
//		}
		promptAndStoreScores(scoresProjects, scnr, "Project");
//		
//		for(int i = 0; i < numExams; i++) {
//			System.out.println("Enter Exam " + (i + 1) + " score:");
//			scoresExams[i] = scnr.nextDouble();
//		}
		promptAndStoreScores(scoresExams, scnr, "Exam");
		
		
		//Get avg
		//Create method for avg
		//wtAvg = (avgPC * WEIGHT_PC) + (avgHW * WEIGHT_HW) + (avgProjects * WEIGHT_PROJECTS) + (avgExams * WEIGHT_Exams)
		
		}
	
	private static void promptAndStoreScores(double [] arr, Scanner scnr, String scoreType) {
		
		for(int i = 0; i < arr.length; i++) {
			System.out.println("Enter " + scoreType + " " + (i + 1) + " score:");
			arr[i] = scnr.nextDouble();
		}
	}
	
		
		

	}


