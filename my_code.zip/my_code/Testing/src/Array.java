import java.util.Random;

public class Array {
	
	public static int delete(int index, int [] myArray, int size) {
		for(int i = index; i < size + 1; i++) {
			if(i != myArray.length - 1)
				myArray[i] = myArray[i + 1];
			else
				myArray[i] = 0;
		}
		if(index < size)
			size--;
		return size;
	}
	
	public static int insert(int [] myArray, int size, int index, int x) {
		if(size < myArray.length) {
		for(int i = size - 1; i >= index; i--) {
			myArray[i + 1] = myArray[i];
		}
		myArray[index] = x;
		}
		if(index < size)
		size++;
		else
			size = index + 1;
		return size;
	}

	public static void main(String[] args) {
		//Array methods
		//Max, Min, Delete, Insert, Increment elements by n number.
		
		Random rand = new Random(1);
		
		int [] myArray = new int [10];
		int size = 5;
		//int [] myArray = {4, 9, 7, 0, 1, 3, 6, 0, 0, 0};
		for(int i = 0; i < myArray.length; i++) {
			System.out.print(myArray[i] + " ");
		}
		
		System.out.println();
		
		for(int i = 0; i < size; i++) {
			myArray[i] = rand.nextInt(10);
		}
		
		for(int i = 0; i < myArray.length; i++) {
			System.out.print(myArray[i] + " ");
		}
		size = insert(myArray, size, 3, 21);
		
		System.out.println();
		
		for(int i = 0; i < myArray.length; i++) {
			System.out.print(myArray[i] + " ");
		}
		
		

	}

}
