package foodFestivalAdvanced;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MainMenuFrame extends JFrame implements ActionListener{
	private JButton button0, button1, button2, button3;
	private String [] order;
	
	public MainMenuFrame() {
		setLayout(new GridLayout(3, 1));
		
		button0 = new JButton("Nothing");
		button0.setPreferredSize(new Dimension(100, 110));
		button0.addActionListener(this);
		button1 = new JButton("Appetizers");
		button1.setPreferredSize(new Dimension(100, 110));
		button1.addActionListener(this);
		button2 = new JButton("Main Course");
		button2.setPreferredSize(new Dimension(100, 110));
		button2.addActionListener(this);
		button3 = new JButton("Dessert");
		button3.setPreferredSize(new Dimension(100, 110));
		button3.addActionListener(this);
		
		
		
		setTitle("Main Menu");
		add(button0);
		add(button1);
		add(button2);
		add(button3);
		setSize(600, 600);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setLocationRelativeTo(null);
		
	}
	
	public void printOrder() {
		System.out.println("Appetizer: " + AppetizersMenu.getAppetizer() + " | Main Course: " + MainCourseMenu.getMainCourse() + " | Dessert: " + DessertMenu.getDessert() + " | Toppings: " + ToppingsMenu.getToppings() + DessertToppings.getDessertTop());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == button0) {
			printOrder();
		}
		if(e.getSource() == button1) {
			new AppetizersMenu();
		}
		if(e.getSource() == button2) {
			new MainCourseMenu();
		}
		if(e.getSource() == button3) {
			new DessertMenu();
		}
		
	}

}
