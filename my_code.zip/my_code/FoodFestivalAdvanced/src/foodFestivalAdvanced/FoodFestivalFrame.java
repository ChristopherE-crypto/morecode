package foodFestivalAdvanced;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class FoodFestivalFrame extends JFrame implements ActionListener{
	private JButton button, button1;
	private JPanel panel, panel1, panel2;
	private JLabel label;
	private String name;
	
	public FoodFestivalFrame() {
		
		button = new JButton("NO");
		button.setBounds(100, 100, 250, 50);
		button.addActionListener(this);
		
		button1 = new JButton("YES");
		button1.setBounds(100, 100, 250, 50);
		button1.addActionListener(this);
		
		panel = new JPanel();
		label = new JLabel("Welcome to the Food Festival. Would you like to place an order?");
		panel.add(label);
		
		panel1 = new JPanel();
		panel2 = new JPanel();
		
		panel1.add(button);
		panel2.add(button1);
		
		setLayout(new BorderLayout());
		
		
		
		
		
		
		
		
		
		
		
		
		
		//JFrame Stuff
		add(panel, BorderLayout.NORTH);
		add(panel1, BorderLayout.SOUTH);
		add(panel2, BorderLayout.CENTER);
		setTitle("Food Festival Menu");
		setSize(600, 600);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setLocationRelativeTo(null);
		pack();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == button) {
			JOptionPane.showMessageDialog(this, "See you next time!");
			System.exit(1);
		}
		if(e.getSource() == button1) {
			name = JOptionPane.showInputDialog(this, "What is your name?");
			new MainMenuFrame();
		}
		
	}

}
