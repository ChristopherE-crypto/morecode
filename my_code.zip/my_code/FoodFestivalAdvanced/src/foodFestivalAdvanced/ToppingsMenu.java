package foodFestivalAdvanced;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ToppingsMenu extends JFrame implements ActionListener{
	private JButton button0, button1, button2, button3;
	private static ArrayList <String> toppings;
	
	public ToppingsMenu() {
		
		toppings = new <String> ArrayList();
		
		setLayout(new GridLayout(3, 1));
		
		button0 = new JButton("Nothing");
		button0.setPreferredSize(new Dimension(100, 110));
		button0.addActionListener(this);
		button1 = new JButton("Olive Oil");
		button1.setPreferredSize(new Dimension(100, 110));
		button1.addActionListener(this);
		button2 = new JButton("Black Pepper Powder");
		button2.setPreferredSize(new Dimension(100, 110));
		button2.addActionListener(this);
		button3 = new JButton("Olives");
		button3.setPreferredSize(new Dimension(100, 110));
		button3.addActionListener(this);
		
		add(button0);
		add(button1);
		add(button2);
		add(button3);
		setTitle("Toppings Menu");
		setSize(600, 600);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setLocationRelativeTo(null);
	}
	
	public static String getToppings() {
		return toppings.toString();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == button0) {
			new AppetizersMenu();
		}
		if(e.getSource() == button1) {
			JOptionPane.showMessageDialog(this, "Olive Oil added!");
			toppings.add("Olive Oil");
		}
		if(e.getSource() == button2) {
			JOptionPane.showMessageDialog(this, "Black Pepper added!");
			toppings.add("Black Pepper Powder");
		}
		if(e.getSource() == button3) {
			JOptionPane.showMessageDialog(this, "Olives added!");
			toppings.add("Olives");
		}
		
	}

}
