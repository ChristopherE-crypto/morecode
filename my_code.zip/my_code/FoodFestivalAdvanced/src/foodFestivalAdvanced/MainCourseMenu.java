package foodFestivalAdvanced;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MainCourseMenu extends JFrame implements ActionListener{
	private JButton button0, button1, button2, button3;
	private static String mainCourse;
	
	public MainCourseMenu() {
		setLayout(new GridLayout(3, 1));
		
		button0 = new JButton("Nothing");
		button0.setPreferredSize(new Dimension(100, 110));
		button0.addActionListener(this);
		button1 = new JButton("Steak");
		button1.setPreferredSize(new Dimension(100, 110));
		button1.addActionListener(this);
		button2 = new JButton("Chicken");
		button2.setPreferredSize(new Dimension(100, 110));
		button2.addActionListener(this);
		button3 = new JButton("Roast Beef");
		button3.setPreferredSize(new Dimension(100, 110));
		button3.addActionListener(this);
		
		
		
		
		add(button0);
		add(button1);
		add(button2);
		add(button3);
		setTitle("Main Course Menu");
		setSize(600, 600);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setLocationRelativeTo(null);
	}
	
	public static String getMainCourse() {
		return mainCourse;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == button0) {
			new MainMenuFrame();
		}
		if(e.getSource() == button1) {
			JOptionPane.showMessageDialog(this, "Steak selected!");
			mainCourse = "Steak";
			new ToppingsMenu();
		}
		if(e.getSource() == button2) {
			JOptionPane.showMessageDialog(this, "Chicken selected!");
			mainCourse = "Chicken";
			new ToppingsMenu();
		}
		if(e.getSource() == button3) {
			JOptionPane.showMessageDialog(this, "Roast Beef selected!");
			mainCourse = "Roast Beef";
			new ToppingsMenu();
		}
		
	}

}
