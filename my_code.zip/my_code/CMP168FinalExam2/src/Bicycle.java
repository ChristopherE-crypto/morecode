public class Bicycle extends Vehicle implements Comparable<Bicycle>{
	private double weight;
	
	public Bicycle() {
		super(1, 1);
		weight = 0.0;
	}
	
	public Bicycle(Person driver) {
		super(driver, new int [] {1});
		weight = 0.0;
	}
	
	public Bicycle(Person driver, double weight) {
		super(driver, new int [] {1});
		if(weight >= 0) {
			this.weight = weight;
		}
		else {
			this.weight = 0.0;
		}
	}
	
	public boolean equals(Object obj) {
		if(obj == null) {return false;}
		if(this == obj) {return true;}
		if(obj instanceof Bicycle) {
			Bicycle otherB = (Bicycle)obj;
			if(Math.abs(this.getWeight() - otherB.getWeight()) < 0.5) {
				return true;
			}
		}
		return false;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public void setWeight(double weight) {
		if(weight >= 0) {
			this.weight = weight;
		}
		else {
			this.weight = 0.0;
		}
	}
	
	public void setDriver(Person p) throws InvalidDriverException {
		if(p != null) {
			if(p.getAge() < 3) {
				throw new InvalidDriverException();
			}
			else {
				personsOnBoard[0][0] = p;
			}
		}
		else {
			throw new InvalidDriverException();
		}
	}
	
	public String toString() {
		return "Bicycle [rider= " + getDriver().getName() + " | weight= " + weight + "]";
	}

	@Override
	public int compareTo(Bicycle o) {
		if((this.getWeight() - o.getWeight()) > 0.5) {
			return -1;
		}
		else if((this.getWeight() - o.getWeight()) < 0.5) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean loadPassenger(Person p) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int loadPassengers(Person[] peeps) {
		// TODO Auto-generated method stub
		return 0;
	}
}
