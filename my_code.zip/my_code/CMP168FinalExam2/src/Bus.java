
public class Bus extends Car{
	
	public Bus(int [] numSeatsPerRow) {
		super(2, (2 * numSeatsPerRow.length) - 1, numSeatsPerRow);
	}
	
	public Bus(Person driver, int [] numSeatsPerRow) {
		super(2, (2 * numSeatsPerRow.length) - 1, driver, numSeatsPerRow);
	}
	
	public boolean canOpenDoor(Person p) {
		if(p != null && p.getAge() > 5 && p.getHeight() > 40) {
			if(isPersonDriver(p)) {
				return true;
			}
			else {
				if(getNumberOfPeopleInRow(personsOnBoard.length - 1) > 0) {
					for(int i = 0; i < personsOnBoard.length; i++) {
						if(personsOnBoard[personsOnBoard.length - 1][i] != null && personsOnBoard[personsOnBoard.length - 1][i].equals(p)) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	public boolean canOpenWindow(Person p) {
		if(p != null && super.canOpenWindow(p) && p.getAge() > 5) {
			return true;
		}
		return false;
	}
	
	public String toString() {
		return "Bus is an extension of " + super.toString();
	}
	
	@Override
	public String departure() {
		return super.departure() + "The Bus\n";
	}
	
	@Override
	public String arrival() {
		return super.arrival() + "Of The Bus\n";
	}
	
	@Override
	public String doNotDisturbTheDriver() {
		return super.doNotDisturbTheDriver() + "On The Bus\n";
	}
}
