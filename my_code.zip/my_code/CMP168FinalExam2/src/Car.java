import java.util.Arrays;

public class Car extends Vehicle implements Comparable<Car>, Announcements{
	private int numDoors;
	private int numWindows;
	
	public Car(int numDoors, int numWindows) {
		super(2, 2);
		this.numDoors = numDoors;
		this.numWindows = numWindows;
	}
	
	public Car(int numDoors, int numWindows, int numSeatsPerRow) {
		super(2, numSeatsPerRow);
		this.numDoors = numDoors;
		this.numWindows = numWindows;
	}
	
	public Car(int numDoors, int numWindows, int [] numSeatsPerRow) {
		super(numSeatsPerRow);
		this.numDoors = numDoors;
		this.numWindows = numWindows;
	}
	
	public Car(int numDoors, int numWindows, Person driver, int [] numSeatsPerRow) {
		super(driver, numSeatsPerRow);
		this.numDoors = numDoors;
		this.numWindows = numWindows;
	}
	
	public boolean canOpenDoor(Person p) {
		if(p != null && getNumDoors() > 2 * numberOfRows) {
			int [] location = getLocationOfPersonInVehicle(p);
			for(int i = 0; i < personsOnBoard.length; i++) {
				if(p.getAge() > 5 && (location[1] == 0 || location [1] == personsOnBoard[i].length - 1)) {
					return true;
				}
			}
		}
			return false;
	}
	
	public boolean canOpenWindow(Person p) {
		if(p != null && getNumWindows() > 2 * numberOfRows) {
			int [] location = getLocationOfPersonInVehicle(p);
			for(int i = 0; i < personsOnBoard.length; i++) {
				if(p.getAge() >= 2 && (location [1] == 0 || location [1] == personsOnBoard[i].length - 1)) {
					return true;
				}
			}
		}
			return false;
	}
	
	public int getNumDoors() {
		return numDoors;
	}
	
	public int getNumWindows() {
		return numWindows;
	}
	
	public boolean equals(Object obj) {
		if(obj == null) {return false;}
		if(this == obj) {return true;}
		if(obj instanceof Car) {
			Car otherC = (Car)obj;
			if(this.getNumDoors() == otherC.getNumDoors()) {
				if(this.getNumWindows() == otherC.getNumWindows()) {
					if(this.numberOfRows == otherC.numberOfRows) {
						if(this.maxSeatsPerRow == otherC.maxSeatsPerRow) {
							if(this.getNumberOfSeats() == otherC.getNumberOfSeats()) {
								for(int i = 0; i < numSeatsPerRow.length; i++) {
									if(this.numSeatsPerRow[i] == otherC.numSeatsPerRow[i]) {
										return true;
									}
								}
							}
						}
					}
				}
			}
		}
		return false;
	}
	
	public String toString() {
		String names = "";
		for(int i = 0; i < super.personsOnBoard.length; i++) {
			for(int j = 0; j < super.personsOnBoard[i].length; j++) {
				if(personsOnBoard[i][j] != null) {
					names += personsOnBoard[i][j].getName() + ",";
				}
			}
		}
		names = names.replaceAll(",$", "");
		
		names = names.substring(0, names.length()) + "]";
		
		return String.format("Car: number of doors = %02d | number of windows = %02d | number of rows = %02d | seats per row = %s | names of people on board = [%s\n", getNumDoors(), getNumWindows(), numberOfRows, Arrays.toString(numSeatsPerRow).replace(" ", ""), names);
	}
	
	public int compareTo(Car c) {
		if(this.getNumberOfSeats() < c.getNumberOfSeats()) {
			return -1;
		}
		else if(this.getNumberOfSeats() > c.getNumberOfSeats()) {
			return 1;
		}
		else {
			return 0;
		}
	}
	
	public int compareRows(Car c) {
		for(int i = 1; i < numSeatsPerRow.length; i++) {
			if(this.numSeatsPerRow[i] < c.numSeatsPerRow[i]) {
				return -1;
			}
			else if(this.numSeatsPerRow[i] > c.numSeatsPerRow[i]) {
				return 1;
			}
		}
		return 0;
	}

	@Override
	public boolean loadPassenger(Person p) {
		if(p != null) {
			if(p.getAge() < 5 || p.getHeight() < 36) {
				for(int i = 1; i < personsOnBoard.length; i++) {
					for(int j = 0; j < personsOnBoard[i].length; j++) {
						if(personsOnBoard[i][j] == null) {
							personsOnBoard[i][j] = p;
							return true;
						}
					}
				}
			}
			else {
				for(int i = 0; i < personsOnBoard.length; i++) {
					for(int j = 0; j < personsOnBoard[i].length; j++) {
						if(personsOnBoard[i][j] == null) {
							personsOnBoard[i][j] = p;
							return true;
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public int loadPassengers(Person[] peeps) {
		int count = 0;
		if(peeps != null) {
			for(int i = 0; i < peeps.length; i++) {
				if(loadPassenger(peeps[i])) {
					count++;
				}
			}
			return count;
		}
		return 0;
	}

	@Override
	public String departure() {
		return "All Aboard\n";
	}

	@Override
	public String arrival() {
		return "Everyone Out\n";
	}

	@Override
	public String doNotDisturbTheDriver() {
		return "No Backseat Driving\n";
	}
}
