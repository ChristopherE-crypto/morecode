import java.util.Arrays;

public abstract class Vehicle {
	protected Person [][] personsOnBoard;
	protected int numberOfRows;
	protected int maxSeatsPerRow;
	protected int [] numSeatsPerRow;
	
	public Vehicle(int numRows, int numSeatsPerRow) {
		personsOnBoard = new Person[numRows][numSeatsPerRow];
		numberOfRows = numRows;
		maxSeatsPerRow = numSeatsPerRow;
		this.numSeatsPerRow = new int [numRows];
		for(int i = 0; i < this.numSeatsPerRow.length; i++) {
			this.numSeatsPerRow[i] = numSeatsPerRow;
		}
	}
	
	public Vehicle(int [] numSeatsPerRow) {//Create a copy, sort the copy, keep the original as it is.
		personsOnBoard = new Person[numSeatsPerRow.length][];
		int [] copy = new int [numSeatsPerRow.length];
		
		for(int i = 0; i < copy.length; i++) {
			copy[i] = numSeatsPerRow[i];
		}
		
		numberOfRows = numSeatsPerRow.length;
		this.numSeatsPerRow = numSeatsPerRow;
		Arrays.sort(copy);
		maxSeatsPerRow = copy[copy.length - 1];
		for(int i = 0; i < numberOfRows; i++) {
			personsOnBoard[i] = new Person[copy[i]];
		}
		
	}
	
	public Vehicle(Person driver, int [] numSeatsPerRow) {
		if(driver.hasDriverLicense()) {
			personsOnBoard = new Person[numSeatsPerRow.length][];
			int [] copy = new int [numSeatsPerRow.length];
			
			for(int i = 0; i < copy.length; i++) {
				copy[i] = numSeatsPerRow[i];
			}
			
			numberOfRows = numSeatsPerRow.length;
			this.numSeatsPerRow = numSeatsPerRow;
			Arrays.sort(copy);
			maxSeatsPerRow = copy[copy.length - 1];
			for(int i = 0; i < numberOfRows; i++) {
				personsOnBoard[i] = new Person[copy[i]];
			}
			personsOnBoard[0][0] = driver;
		}
	}
	
	public abstract boolean loadPassenger(Person p);
	
	public abstract int loadPassengers(Person [] peeps);
	
	public int getNumberOfSeats() {//Change this. Use numSeatsPerRow array
		int count = 0;
		for(int i = 0; i < numSeatsPerRow.length; i++) {
			count += numSeatsPerRow[i];
		}
		return count;
	}
	
	public void setDriver(Person p) throws InvalidDriverException {
		if(p != null && p.hasDriverLicense()) {
			personsOnBoard[0][0] = p;
		}
		else {
			throw new InvalidDriverException("This Person Does Not Have A Driver License!");
		}
	}
	
	public Person getDriver() {
		if(personsOnBoard[0][0] != null) {
			return personsOnBoard[0][0];
		}
		else {
			return null;
		}
	}
	
	public boolean hasDriver() {
		if(personsOnBoard[0][0] != null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public int getNumberOfAvailableSeats() {
		int empty = 0;
		for(int i = 0; i < personsOnBoard.length; i++) {
			for(int j = 0; j < personsOnBoard[i].length; j++) {
				if(personsOnBoard[i][j] == null) {
					empty++;
				}
			}
		}
		return empty;
	}
	
	public int getNumberOfAvailableSeatsInRow(int row) {
		int empty = 0;
		if(row < 0 || row > personsOnBoard.length - 1) {
			return -1;
		}
		else {
			for(int j = 0; j < personsOnBoard[row].length; j++) {
				if(personsOnBoard[row][j] == null) {
					empty++;
				}
			}
			return empty;
		}
	}
	
	public int getNumberOfPeopleOnBoard() {
		int occupied = 0;
		for(int i = 0; i < personsOnBoard.length; i++) {
			for(int j = 0; j < personsOnBoard[i].length; j++) {
				if(personsOnBoard[i][j] != null) {
					occupied++;
				}
			}
		}
		return occupied;
	}
	
	public int getNumberOfPeopleInRow(int row) {
		int occupied = 0;
		for(int j = 0; j < personsOnBoard[row].length; j++) {
			if(personsOnBoard[row][j] != null) {
				occupied++;
			}
		}
		return occupied;
	}
	
	public Person getPersonInSeat(int row, int col) {
		if(row < 0 || row > numberOfRows || col < 0 || col > personsOnBoard[row].length || personsOnBoard[row][col] == null) {
			return null;
		}
		else {
			return personsOnBoard[row][col];
		}
	}
	
	public int [] getLocationOfPersonInVehicle(Person p) {
		int [] location = {-1, -1};
		if(p != null) {
			for(int i = 0; i < personsOnBoard.length; i++) {
				for(int j = 0; j < personsOnBoard[i].length; j++) {
					if(personsOnBoard[i][j] != null && personsOnBoard[i][j].equals(p)) {
						location[0] = i;
						location[1] = j;
					}
				}
			}
			return location;
		}
		else {
			return location;
		}
	}
	
	public Person [] getPeopleInRow(int row) {
		if(row < 0 || row > personsOnBoard.length || getNumberOfPeopleInRow(row) == 0) {
			return null;
		}
		else {
			Person [] peopleRow = new Person[getNumberOfPeopleInRow(row)];
			for(int i = 0; i < peopleRow.length; i++) {
				peopleRow[i] = personsOnBoard[row][i].clone();
			}
			return peopleRow;
		}
	}
	
	public Person [][] getPeopleOnBoard(){
		Person [][] copy = new Person[numSeatsPerRow.length][];
		for(int i = 0; i < numberOfRows; i++) {
			copy[i] = new Person[numSeatsPerRow[i]];
		}
		for(int i = 0; i < personsOnBoard.length; i++) {
			for(int j = 0; j < personsOnBoard[i].length; j++) {
				if(personsOnBoard[i][j] != null) {
				copy[i][j] = personsOnBoard[i][j].clone();
				}
			}
		}
		return copy;
	}
	
	public boolean isPersonInVehicle(Person p) {
		if(p != null) {
			for(int i = 0; i < personsOnBoard.length; i++) {
				for(int j = 0; j < personsOnBoard[i].length; j++) {
					if(personsOnBoard[i][j] != null && personsOnBoard[i][j].equals(p)) {
						return true;
					}
				}
			}
		}	
		return false;
	}
	
	public boolean isPersonDriver(Person p) {
		if(p != null && personsOnBoard[0][0] != null && personsOnBoard[0][0].equals(p)) {
			return true;
		}
		return false;
	}
}
