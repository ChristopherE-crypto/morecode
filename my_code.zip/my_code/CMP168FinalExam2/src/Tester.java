import java.util.Arrays;

public class Tester {

	public static void main(String[] args) {
		
		int [] numSeatsPerRow = {2, 4};
		int [] numSeatsPerRow2 = {3, 2, 1};
		Person p1 = new Person("Carlos", true, 20, 160);
		Person p2 = new Person("Maria", false, 50, 130);
		Person p3 = new Person("Manuel", true, 28, 190);
		
		Car c = new Car(2, 2, numSeatsPerRow);
		Car c1 = new Car(2, 3, numSeatsPerRow2);
		
		Bus b1 = new Bus(p1, numSeatsPerRow);
		
		System.out.println(c.getNumberOfAvailableSeats());
		System.out.println(c.getNumberOfPeopleOnBoard());
		
		System.out.println(c.loadPassenger(p1));
		
		System.out.println(c.getNumberOfAvailableSeats());
		System.out.println(c.getNumberOfPeopleOnBoard());
		
		System.out.println(c.loadPassenger(p2));
		
		System.out.println(c.getNumberOfAvailableSeats());
		System.out.println(c.getNumberOfPeopleOnBoard());
		
		System.out.println(c.loadPassenger(p3));
		
		System.out.println(c.getNumberOfAvailableSeats());
		System.out.println(c.getNumberOfPeopleOnBoard());
		
		System.out.println(c.toString());
		
		Person [][] people = c.getPeopleOnBoard();
		
		for(int i = 0; i < people.length; i++) {
			for(int j = 0; j < people[i].length; j++) {
				System.out.print(people[i][j]);
			}
			System.out.println();
		}
		
		System.out.println();
		
		for(int i = 0; i < c.personsOnBoard.length; i++) {
			for(int j = 0; j < c.personsOnBoard[i].length; j++) {
				System.out.print(c.personsOnBoard[i][j] + ",");
			}
			System.out.println();
		}
		
		System.out.println(c.getNumberOfAvailableSeatsInRow(2));
		
		int [] location = c.getLocationOfPersonInVehicle(p3);
		
		System.out.println(Arrays.toString(location));
		
		System.out.println(c.equals(c1));
		
		System.out.println("Passengers on Bus:\n" + b1.loadPassenger(p2));
		System.out.println(b1.loadPassenger(p2));
		System.out.println(b1.loadPassenger(p3));
		System.out.println(b1.loadPassenger(p3));
		System.out.println(b1.loadPassenger(p3));
		
		System.out.println("Can this passenger open the door? :" + b1.canOpenDoor(p3));
		
		System.out.println("COMPARE TO: " + c.compareTo(c1));

	}

}
