package tomala;
import java.util.Scanner;

public class Tomala {
	public static void main(String [] args) {

		Scanner scnr = new Scanner(System.in);
		
		String texto = "Pepe";
		String texto1 = "Mucho texto weon no sea asi...";
		
		System.out.println(texto.toUpperCase());
		
		System.out.println(texto1.substring(6, texto1.length()));
		
		
		
		
		
		
	}
}
