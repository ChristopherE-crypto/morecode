package entities;

public class Healer extends Allies{
	
	private String name;
	private char gender;
	private int powerLevel;
	private String race;
	
	public Healer(String name, char gender, int powerLevel, String race) {
		this.name = name;
		this.gender = gender;
		this.powerLevel = powerLevel;
		this.race = race;
		
	}
	
	public void heal() {
		System.out.println("Heals...");
	}
	
	public void revive() {
		System.out.println("Revives one ally...");
	}
	
	public String toString() {
		String s = "Healer: [Name = " + name + " | Gender = " + gender + " | Power Level = " + powerLevel + " | Race: " + race + "]";
		return s;
	}
}
