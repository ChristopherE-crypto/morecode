package entities;

public class Mage extends Allies {
	
	private String name;
	private char gender;
	private int powerLevel;
	private String race;
	
	public Mage(String name, char gender, int powerLevel, String race) {
		this.name = name;
		this.gender = gender;
		this.powerLevel = powerLevel;
		this.race = race;
		
	}
	
	public void castSpell() {
		System.out.println("Casts spell...");
	}
	
	public void teleport() {
		System.out.println("Teleports to a near location...");
	}
	
	public void meditate() {
		System.out.println("Meditates and regenerates mana...");
	}
	
	public String toString() {
		String s = "Mage: [Name = " + name + " | Gender = " + gender + " | Power Level = " + powerLevel + " | Race: " + race + "]";
		return s;
	}

}
