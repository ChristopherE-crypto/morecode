package entities;

public class Monster extends Enemy{
	private String name;
	
	public Monster(String name) {
		this.name = name;
	}
	
	public void scare() {
		System.out.println("Scares player...");
	}
}
