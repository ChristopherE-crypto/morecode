package entities;

public class Beast extends Enemy{
	private String name;
	
	public Beast(String name) {
		this.name = name;
	}
	
	public void runFast() {
		System.out.println("Runs really fast...");
	}
	
	public void bite() {
		System.out.println("Bites player...");
	}
}
