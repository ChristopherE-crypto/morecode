package entities;

public class Allies {
	
	private String name;
	private char gender;
	private int powerLevel;
	private String race;
	
	public void talk() {
		System.out.println("Talks to another ally...");
	}
	
	public void think() {
		System.out.println("Thinks and makes a decision...");
	}

}
