package entities;

public class Enemy {
	
	private int powerLevel;
	private int id;
	
	public void attack() {
		System.out.println("Attacks player...");
	}

}
