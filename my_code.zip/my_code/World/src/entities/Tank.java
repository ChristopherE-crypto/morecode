package entities;

public class Tank extends Allies{
	
	private String name;
	private char gender;
	private int powerLevel;
	private String race;
	
	public Tank(String name, char gender, int powerLevel, String race) {
		this.name = name;
		this.gender = gender;
		this.powerLevel = powerLevel;
		this.race = race;
		
	}
	
	public void shield() {
		System.out.println("Uses shield and blocks damage...");
	}
	
	public void incArmor() {
		System.out.println("Increases armor and resistances...");
	}
	
	public String toString() {
		String s = "Tank: [Name = " + name + " | Gender = " + gender + " | Power Level = " + powerLevel + " | Race: " + race + "]";
		return s;
	}

}
