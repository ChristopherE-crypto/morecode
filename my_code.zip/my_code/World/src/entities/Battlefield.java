package entities;

public class Battlefield {

	public static void main(String[] args) {
		
		Allies allies [] = new Allies [3];
		
		allies[0] = new Mage("Zer", 'm', 5, "Human");
		allies[1] = new Healer("Xiao", 'm', 3, "Elf");
		allies[2] = new Tank("Diana", 'f', 4, "Angel");
		
		for(int i = 0; i < allies.length; i++) {
			System.out.println(allies[i]);
			allies[i].talk();
			
		}
		
		
		

	}

}
