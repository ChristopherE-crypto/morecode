package recursion;

import java.util.Arrays;

/**
 * Implementation of the Quicksort Algorithm.
 * Time complexity: O(n^2) in the worst case; O(nlogn) in the average case.
 * Space complexity: O(1) (if the method call stack is not taken into account)
 * @author Christopher Esquivel
 *
 */

public class Quicksort {

	public static void main(String[] args) {
		int [] nums = {40, 14, 18, 10, 8, 5, 2, 1, 0};
		
		System.out.println("Quicksort:");
		
		System.out.println(Arrays.toString(nums));
		
		quicksort(nums);
		
		System.out.println(Arrays.toString(nums));
	}
	
	public static void quicksort(int [] nums) {
		quicksort(nums, 0, nums.length - 1);
	}
	
	private static void quicksort(int [] nums, int left, int right) {
		if(left < right) {
			int pIndex = partition(nums, left, right);
			quicksort(nums, left, pIndex - 1);
			quicksort(nums, pIndex + 1, right);
		}
	}
	
	private static int partition(int [] nums, int left, int right) {
		int pivot = nums[right];
		int pIndex = left;
		
		for(int i = left; i < right; i++) {
			if(nums[i] <= pivot) {
				swap(nums, pIndex++, i);
			}
		}
		swap(nums, pIndex, right);
		
		return pIndex;
	}
	
	private static void swap(int [] nums, int i, int j) {
		int temp = nums[i];
		nums[i] = nums[j];
		nums[j] = temp;
	}
	
	

}
