package recursion;

public class Maximum {

	public static void main(String[] args) {
		int [] nums = {34, 67, 12, 55, 88, 92, 10, 2};
		System.out.println(max(nums));
	}
	
	public static int max(int [] array) {
		return findMax(array, 0, array.length - 1);
	}
	
	public static int findMax(int [] array, int first, int last) {
		if(first > last) {
			return Integer.MIN_VALUE;
		}
		if(first == last) {
			return array[first];
		}
		else {
			int mid = first + (last - first) / 2;
			int leftMax = findMax(array, first, mid - 1);
			int rightMax = findMax(array, mid + 1, last);
			return Math.max(array[mid], Math.max(leftMax, rightMax));
		}
	}

}
