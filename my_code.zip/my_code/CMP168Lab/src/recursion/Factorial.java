package recursion;

public class Factorial {
	public static void main(String [] args) {
		System.out.println(factorial(4));
		System.out.println(factorial(3));
		System.out.println(factorial(2));
		System.out.println(factorial(1));
		System.out.println(factorial(0));
		
		System.out.println("--------------------------------");
		System.out.println(iterativeFactorial(4));
		System.out.println(iterativeFactorial(3));
		System.out.println(iterativeFactorial(2));
		System.out.println(iterativeFactorial(1));
		System.out.println(iterativeFactorial(0));
	}
	
	public static int factorial(int number) {
		if(number == 0) {
			return 1;
		}
		else {
			return number * factorial(number - 1);
		}
	}
	
	public static int iterativeFactorial(int number) {
		int result = 1;
		for(int x = number; x > 1; --x) {
			result = result * x;
		}
		return result;
	}
}
