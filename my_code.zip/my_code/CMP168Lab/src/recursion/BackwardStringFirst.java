package recursion;

import java.util.Scanner;

public class BackwardStringFirst {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		printBackward(scnr.nextLine());
		
		scnr.close();
	}
	
	public static void printBackward(String s) {
		printBackward(s, 0);
	}
	
	private static void printBackward(String s, int position) {
		if(position < s.length()) {
			printBackward(s, position + 1);
			System.out.print(s.charAt(position));
		}
	}

}
