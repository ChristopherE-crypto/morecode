package recursion;

public class BackwardArray {

	public static void main(String[] args) {
		int [] nums = {0, 2, 4, 6, 8, 10, 12, 14, 16};
		writeArrayBackward(nums, 2, 5);
	}
	
	public static void writeArrayBackward(int [] array, int first, int last) {
		if(first <= last) {
			System.out.printf("%d ", array[last]);
			writeArrayBackward(array, first, last - 1);
		}
	}

}
