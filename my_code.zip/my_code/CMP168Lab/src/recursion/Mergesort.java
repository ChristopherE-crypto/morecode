package recursion;

import java.util.Arrays;

/**
 * Recursive implementation of the Mergesort algorithm.
 * Time complexity: O(nlogn), where n is the length of the array.
 * Space complexity: O(n), where n is the length of the array.
 * @author Christopher Esquivel
 *
 */

public class Mergesort {
	public static void main(String [] args) {
		int [] nums = {12, 8, 4, 2, 6, 1, 10};
		
		System.out.println("Mergesort:");
		
		System.out.println(Arrays.toString(nums));
		
		mergesort(nums);
		
		System.out.println(Arrays.toString(nums));
	}
	
	public static void mergesort(int [] nums) {
		mergesort(nums, 0, nums.length - 1);
	}
	
	private static void mergesort(int [] nums, int left, int right) {
		if(left < right) {
			int mid = left + (right - left) / 2;
			mergesort(nums, left, mid);
			mergesort(nums, mid + 1, right);
			merge(nums, left, mid, right);
		}
	}
	
	private static void merge(int [] nums, int left, int mid, int right) {
		int [] merged = new int[right - left + 1];
		int mergedIndex = 0, leftIndex = left, rightIndex = mid + 1;
		while(leftIndex <= mid && rightIndex <= right) {
			if(nums[leftIndex] <= nums[rightIndex]) {
				merged[mergedIndex++] = nums[leftIndex++];
			}
			else {
				merged[mergedIndex++] = nums[rightIndex++];
			}
		}
		while(leftIndex <= mid) {
			merged[mergedIndex++] = nums[leftIndex++];
		}
		while(rightIndex <= right) {
			merged[mergedIndex++] = nums[rightIndex++];
		}
		for(int i = 0; i < merged.length; i++) {
			nums[left + i] = merged[i];
		}
	}

}
