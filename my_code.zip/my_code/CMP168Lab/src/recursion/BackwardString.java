package recursion;

import java.util.Scanner;

public class BackwardString {
	public static void main(String [] args) {
		Scanner scnr = new Scanner(System.in);
		
		printBackward(scnr.nextLine());
		
		scnr.close();
	}
	
	public static void printBackward(String s) {
		printBackward(s, s.length() - 1);
	}
	
	private static void printBackward(String s, int position) {
		if(position >= 0) {
			System.out.print(s.charAt(position));
			printBackward(s, position - 1);
		}
	}
}
