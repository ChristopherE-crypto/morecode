package recursion;

public class CountDown {
	public static void main(String [] args) {
		countDown(5);
	}
	
	public static void countDown(int count) {
		
		if(count > 0) {
			if(count == 0) {
				System.out.println("GO!");
			}
			else {
				//System.out.println(count);
				countDown(count - 1);
				System.out.println(count);
			}
		}
		else {
			if(count == 0) {
				System.out.println("GO!");
			}
			else {
				System.out.println(count);
				countDown(count + 1);
			}
		}
	}
}
