package exceptions;

public class FinalizationExample {

	public static void main(String[] args) {
		

	}

}
