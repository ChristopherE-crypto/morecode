package exceptions;

public class OutOfBoundsDemo {

	public static void main(String[] args) {
		int [] numbers = new int[5];
		System.out.println(numbers[7]);

	}

}
