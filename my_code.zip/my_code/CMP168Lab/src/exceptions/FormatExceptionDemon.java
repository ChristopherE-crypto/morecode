package exceptions;

public class FormatExceptionDemon {

	public static void main(String[] args) {
		try {
		int number = Integer.parseInt("1024");
		System.out.println(number);
		}catch(NumberFormatException e) {
			System.out.println("Invalid operation!");
		}
		System.out.println("Good-bye!");
	}

}
