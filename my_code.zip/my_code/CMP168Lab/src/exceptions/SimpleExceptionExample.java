package exceptions;

import java.util.InputMismatchException;
import java.util.Scanner;

public class SimpleExceptionExample {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		boolean keepGoing = true;
		do {
			try {
				System.out.println("Enter an integer numerator:");
				int numerator = scnr.nextInt();
				
				System.out.println("Enter an integer denominator:");
				int denominator = scnr.nextInt();
				
				int result = divide(numerator, denominator);
				System.out.printf("%nResult of %d / %d = %d%n%n",numerator, denominator, result);
				keepGoing = false;
			}catch(InputMismatchException e){
				scnr.next();
				System.out.printf("%nException: %s%n", e);
				System.out.println("You must enter an integer. Please try again.");
			}catch(ArithmeticException e) {
				System.err.printf("%nException: %s%n", e);
				System.out.println("You cannot divide by zero. Please try again.");
			}
		}while(keepGoing);
	}
	
	public static int divide(int numerator, int denominator) throws ArithmeticException{
		return numerator / denominator;
	}

}
