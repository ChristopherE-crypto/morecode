
public class Lab1 {

}
