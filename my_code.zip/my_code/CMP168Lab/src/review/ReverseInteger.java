package review;

public class ReverseInteger {

	public static void main(String[] args) {
		int number = 845092759;
		System.out.println("Original number: " + number);
		int reversedNumber = reverse(number);
		System.out.println("Reversed number: " + reversedNumber);

	}
	
	public static int reverse(int number) {
		if(number < 0) {
			throw new IllegalArgumentException("Unable to reverse a negative number.");
		}
		int reversed = 0;
		while(number > 0) {
			reversed = reversed * 10 + (number % 10);
			number /= 10;
		}
		return reversed;
	}

}
