package review;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class WritingExample {

	public static void main(String[] args) throws FileNotFoundException {
		FileOutputStream fos = new FileOutputStream("data.csv", true);
		PrintWriter writer = new PrintWriter(fos);
		writer.println("4,Antonio,Gonzales,45");
		writer.println("5,Thomas,Yang,13");
		writer.flush();
		
		writer.close();

	}

}
