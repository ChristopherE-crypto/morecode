package review;

import java.io.File;

public class Folders {
	private static final int NUMBER_OF_FOLDERS = 10;

	public static void main(String[] args) {
		System.out.println("Creating folders...");
		for(int i = 1; i <= NUMBER_OF_FOLDERS; i++) {
			File file = new File("Folder" + i);
			if(file.exists()) {
				System.out.println("The folder exists!");
			}
			else {
				if(file.mkdir()) {
					System.out.println("The folder #" + i + " has been created.");
				}
			}
		}
		System.out.println("Complete!");

	}

}
