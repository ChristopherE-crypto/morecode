package review;

import java.util.Arrays;

public class PerfectSizeArray {

	public static void main(String[] args) {
		int [] numbers = new int [10];
		System.out.println(Arrays.toString(numbers));
		fill(numbers, 240);
		System.out.println(Arrays.toString(numbers));

	}
	
	public static void fill(int [] numbers, int value) {
		for(int i = 0; i < numbers.length; i++) {
			numbers[i] = value;
		}
	}

}
