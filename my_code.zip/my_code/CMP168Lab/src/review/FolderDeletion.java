package review;

import java.io.File;

public class FolderDeletion {

	public static void main(String[] args) {
		for(int i = 1; i <= 10; i++) {
			File file = new File("Folder" + i);
			if(file.exists()) {
				if(file.delete()) {
					System.out.println("The folder #" + i + " has been deleted.");
				}
			}
		}

	}

}
