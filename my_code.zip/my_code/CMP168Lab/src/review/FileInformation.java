package review;

import java.io.File;

public class FileInformation {

	public static void main(String[] args) {
		File file = new File("data.csv");
		if(file.exists()) {
			System.out.println("Filename: " + file.getName());
			System.out.println("Size: " + file.length());
			System.out.println("Absolute path: " + file.getAbsolutePath());
			System.out.println("Permission to read the file: " + file.canRead());
			System.out.println("Permission to write: " + file.canWrite());
			System.out.println("Permission to execute: " + file.canExecute());
		}
		else {
			System.out.println("The file does not exist!");
		}

	}

}
