package review;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadingExample {

	public static void main(String[] args) throws FileNotFoundException {
		File file = new File("data.csv");
		Scanner input = new Scanner(file);
		
		while(input.hasNextLine()) {
			System.out.println(input.nextLine());
		}
		
		input.close();

	}

}
