package review;

import java.io.File;
import java.io.IOException;

public class FileCreation {

	public static void main(String[] args) throws IOException {
		File file = new File("data.csv");
		
		if(file.exists()) {
			System.out.println("The file exists!");
		}
		else {
			System.out.println("The file does not exist.");
			System.out.println("Creating file...");
			if(file.createNewFile()) {
				System.out.println("The file has been created successfully.");
			}
			else {
				System.out.println("Failure: The file has not been created.");
			}
		}
		File folder = new File("Folder");
		if(folder.exists()) {
			System.out.println("The folder already exists!");
		}
		else {
			System.out.println("Creating folder...");
			if(folder.mkdir()) {
				System.out.println("The folder has been created successfully!");
			}
			else {
				System.out.println("Error: Unable to create folder.");
			}
		}

	}

}
