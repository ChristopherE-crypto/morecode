package interfaces;

public class ValuableTest {

	public static void main(String[] args) {
		Gold myGold = new Gold();
		Trash myTrash = new Trash();
		
		Valuable [] valuables = {myGold, myTrash};
		
		for(Valuable valuable : valuables) {
			System.out.printf("%s %s valuable.\n", valuable, valuable.isValuable() ? "is" : "is not");
		}

	}

}
