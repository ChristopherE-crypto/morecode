package interfaces;

public class Trash implements Valuable {
	@Override
	public boolean isValuable() {
		return false;
	}
	
	@Override
	public String toString() {
		return "Trash";
	}
}
