package interfaces;

import java.util.Arrays;

public class PersonTest {

	public static void main(String[] args) {
		Person person1 = new Person("Mary", "Smith", 36);
		Person person2 = new Person("John", "Washington", 28);
		Person person3 = new Person("Michio", "Kaku", 75);
		Person person4 = new Person("Ally", "McNeal", 24);
		
		Person [] people = {person1, person2, person3, person4};
		
		for(Person person : people) {
			System.out.println(person);
		}
		
		Arrays.sort(people);
		
		System.out.println();
		
		for(Person person : people) {
			System.out.println(person);
		}
		

	}

}
