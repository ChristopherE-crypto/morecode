package interfaces;

public interface Valuable {
	boolean isValuable();
}
