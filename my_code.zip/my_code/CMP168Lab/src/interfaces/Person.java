package interfaces;

public class Person implements Comparable <Person>{
	private String firstName;
	private String lastName;
	private int age;
	
	public Person(String firstName, String lastName, int age) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
	}
	
	
	@Override
	public int compareTo(Person that) {
		if(age < that.age) {
			return -1;
		}
		if(age > that.age) {
			return 1;
		}
		return 0;
	}
	
	@Override
	public String toString() {
		return String.format("{%s %s, %d}", firstName, lastName, age);
	}

}
