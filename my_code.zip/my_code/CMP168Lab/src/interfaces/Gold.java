package interfaces;

public class Gold implements Valuable {
	@Override
	public boolean isValuable() {
		return true;
	}
	
	@Override
	public String toString() {
		return "Trash";
	}
}
