package gui;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class FontFrame extends JFrame{
	
	private JLabel mainLabel;
	private JTextField mainTextField;
	private JCheckBox italicCheckBox;
	private JCheckBox boldCheckBox;

	public FontFrame() {
		super("Font Application");
		
		mainLabel = new JLabel("Output:");
		mainTextField = new JTextField("This text is going to change!");
		italicCheckBox = new JCheckBox("Italic");
		boldCheckBox = new JCheckBox("Bold");
		
		mainTextField.setFont(new Font("Serif", Font.PLAIN, 14));
		mainTextField.setEditable(false);
		
		CheckBoxHandler handler = new CheckBoxHandler();
		italicCheckBox.addItemListener(handler);
		boldCheckBox.addItemListener(handler);
		
		add(mainLabel);
		add(mainTextField);
		add(italicCheckBox);
		add(boldCheckBox);
		
		setSize(320, 280);
		setLayout(new FlowLayout());
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	private class CheckBoxHandler implements ItemListener {

		@Override
		public void itemStateChanged(ItemEvent e) {
			if(boldCheckBox.isSelected() && italicCheckBox.isSelected()) {
				mainTextField.setFont(new Font("Serif", Font.BOLD + Font.ITALIC, 14));
			}
			else if(boldCheckBox.isSelected()) {
				mainTextField.setFont(new Font("Serif", Font.BOLD, 14));
			}
			else if(italicCheckBox.isSelected()) {
				mainTextField.setFont(new Font("Serif", Font.ITALIC, 14));
			}
			else {
				mainTextField.setFont(new Font("Serif", Font.PLAIN,  14));
			}
			
		}
		
	}

}
