package gui;

import javax.swing.JFrame;

public class HistogramViewer extends JFrame{
	
	public HistogramViewer() {
		super("Histogram");
		add(new HistogramComponent());
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(640, 480);
		setLocationRelativeTo(null);
		setVisible(true);
	}

}
