package gui;

public class TableApp {
	
	public static void main(String [] args) {
		JTableFrame frame = new JTableFrame();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
