package gui;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class JTableFrame extends JFrame{
	private JLabel label;
	private JTable table;
	
	public JTableFrame() {
		String [] columnNames = {"Name", "Age", "Nationality"};
		Object [][] data = {{"John Smith", 32, "American"}, {"Yin Yang", 21, "Chinese"}, {"Alex Rodriguez", 45, "Dominican"}};
		
		table = new JTable(data, columnNames);
		label = new JLabel("Students");
		
		//table.setShowGrid(false);//Don't show grid
		
		add(label, BorderLayout.NORTH);
		add(new JScrollPane(table), BorderLayout.CENTER);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(640, 480);
	}
}
