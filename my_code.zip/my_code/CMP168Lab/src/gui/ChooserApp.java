package gui;

public class ChooserApp {

	public static void main(String[] args) {
		ChooserFrame frame = new ChooserFrame();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

	}

}
