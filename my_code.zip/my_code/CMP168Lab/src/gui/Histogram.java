package gui;

public class Histogram {
	

	public static void main(String[] args) {
		new HistogramViewer();

	}

}
