package gui;

import javax.swing.JOptionPane;

public class Addition {

	public static void main(String[] args) {
		String firstNumber = JOptionPane.showInputDialog("Enter first number:");
		String secondNumber = JOptionPane.showInputDialog("Enter second number:");
		
		int num1 = Integer.parseInt(firstNumber);
		int num2 = Integer.parseInt(secondNumber);
		int sum = num1 + num2;
		
		JOptionPane.showMessageDialog(null, "The sum is: " + sum);

	}

}
