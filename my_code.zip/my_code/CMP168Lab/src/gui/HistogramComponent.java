package gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import javax.swing.JComponent;

public class HistogramComponent extends JComponent{
	
	@Override
	public void paintComponent(Graphics g) {
		Graphics2D g2D = (Graphics2D) g;
		
		Rectangle rectangle1 = new Rectangle(10, 10, 200, 50);
		Color red = new Color(255, 0, 0);
		g2D.setColor(red);
		g2D.fill(rectangle1);
		
		Rectangle rectangle2 = new Rectangle(10, 75, 120, 50);
		Color green = new Color(0, 255, 0);
		g2D.setColor(green);
		g2D.fill(rectangle2);
		
		Rectangle rectangle3 = new Rectangle(10, 140, 230, 50);
		Color blue = new Color(0, 0, 255);
		g2D.setColor(blue);
		g2D.fill(rectangle3);
	}

}
