package gui;

public class FontApp {

	public static void main(String[] args) {
		new FontFrame();

	}

}
