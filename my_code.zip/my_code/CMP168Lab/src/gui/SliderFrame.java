package gui;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class SliderFrame extends JFrame{
	private static final int WINDOW_WIDTH = 800, WINDOW_HEIGHT = 600;
	private static final int INITIAL_FONT_SIZE = 18;
	private static final int MIN_SLIDER_VALUE = 14;
	private static final int MAX_SLIDER_VALUE = 36;
	
	private JLabel label;
	private JSlider slider;
	
	public SliderFrame() {
		label = new JLabel("Mathematics is the queen of science and number theory is the queen of mathematics.");
		label.setFont(new Font("Serif", Font.PLAIN, INITIAL_FONT_SIZE));
		
		slider = new JSlider(JSlider.HORIZONTAL, MIN_SLIDER_VALUE, MAX_SLIDER_VALUE, INITIAL_FONT_SIZE);
		slider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				label.setFont(new Font("Serif", Font.PLAIN, slider.getValue()));
			}
		});
		
		Border outerBorder = BorderFactory.createEmptyBorder(40, 40, 40, 40);
		Border innerBorder = BorderFactory.createTitledBorder("Carl Friedrich Gauss");
		
		label.setBorder(BorderFactory.createCompoundBorder(outerBorder, innerBorder));
		
		slider.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
		
		add(label, BorderLayout.CENTER);
		add(slider, BorderLayout.SOUTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
		
	}

}
