package gui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;

public class SimpleFrame {
	
	private static final Color [] colors = {Color.BLACK, Color.BLUE, Color.GREEN, Color.RED, Color.CYAN};
	
	public static void main(String [] args) {
		JFrame frame = new JFrame("Basic Window");
		JButton changeColorButton = new JButton("Change Color!");
		
		
		Random random = new Random();
		
		changeColorButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent event) {
				Color color = colors[random.nextInt(colors.length)];
				frame.getContentPane().setBackground(color);
			}
			
		});
		
		
		
		frame.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		frame.add(changeColorButton);
		//frame.setTitle("Basic Window");
		frame.setSize(640, 480);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}
