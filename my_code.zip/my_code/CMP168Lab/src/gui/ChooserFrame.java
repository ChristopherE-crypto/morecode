package gui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class ChooserFrame extends JFrame implements ActionListener{
	private JButton openFileButton;
	private JTextArea textArea;
	private JFileChooser fileChooser;
	
	public ChooserFrame() {
		openFileButton = new JButton("Open File");
		textArea = new JTextArea(14, 40);
		fileChooser = new JFileChooser();
		
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		textArea.setEditable(false);
		openFileButton.addActionListener(this);
		
		add(openFileButton);
		add(new JScrollPane(textArea));
		
		pack();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		int result = fileChooser.showOpenDialog(this);
		if(result == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			StringBuilder sb = new StringBuilder();
			try(Scanner input = new Scanner(file)){
				while(input.hasNextLine()) {
					sb.append(input.nextLine()).append("\n");
				}
				textArea.setText(sb.toString());
				
			}catch(FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

}
