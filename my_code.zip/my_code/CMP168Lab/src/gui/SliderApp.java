package gui;

public class SliderApp {

	public static void main(String[] args) {
		SliderFrame frame = new SliderFrame();
		frame.setVisible(true);

	}

}
