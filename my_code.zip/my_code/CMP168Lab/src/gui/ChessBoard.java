package gui;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ChessBoard extends JFrame{
	private static final int WINDOW_WIDTH = 640, WINDOW_HEIGHT = 480;
	private static final int N = 9;
	
	public ChessBoard() {
		setLayout(new GridLayout(N, N));
		
		for(int i = 1; i <= N * N; i++) {
			JButton button = new JButton(String.valueOf(i));
			if(i % 2 == 0) {
				button.setBackground(Color.WHITE);
				button.setForeground(Color.BLACK);
			}
			else {
				button.setBackground(Color.BLACK);
				button.setForeground(Color.WHITE);
			}
			final int ID = i;
			button.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(ChessBoard.this, "You clicked cell #" + ID + "!");
				}
			});
			add(button);
		}
		
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		ChessBoard chessBoard = new ChessBoard();
		chessBoard.setLocationRelativeTo(null);
		chessBoard.setVisible(true);

	}

}
