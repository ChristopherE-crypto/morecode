package arrays;

import java.util.Arrays;

public class CopyArrayDemo {

	public static void main(String[] args) {
		
		double [] myValues = {5.43, 7.26, 8.25, 9.6, 3.12};
		
		double [] myCopy = new double [myValues.length];
		
		double [] secondCopy = myValues.clone();
		
		System.arraycopy(myValues, 0, myCopy, 0, myValues.length);
		
		System.out.println("Original: " + Arrays.toString(myValues));
		
		System.out.println("Copy: " + Arrays.toString(myCopy));
		
		System.out.println("Copy #2: " + Arrays.toString(secondCopy));

	}

}
