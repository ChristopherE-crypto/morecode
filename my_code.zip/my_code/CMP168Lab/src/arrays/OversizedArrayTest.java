package arrays;

public class OversizedArrayTest {

	public static void main(String[] args) {
		
		OversizedArray myArray = new OversizedArray(10);
		
		myArray.print();
		
		myArray.add(2);
		myArray.add(3);
		myArray.add(5);
		myArray.add(7);
		myArray.add(11);
		
		myArray.print();
		
		myArray.remove(3);
		
		myArray.print();
		
		System.out.println("Number of elements: " + myArray.getSize());

	}

}
