package arrays;

public class ReverseArray {
	
	public static void reverse(int [] nums) {
		reverse(nums, 0, nums.length);
	}
	
	public static void reverse(int [] nums, int start, int end) {
		
		for(int i = start, j = end - 1; i < j; i++, j--) {
			int temp = nums[i];
			nums[i] = nums[j];
			nums[j] = temp;
		}
	}

}
