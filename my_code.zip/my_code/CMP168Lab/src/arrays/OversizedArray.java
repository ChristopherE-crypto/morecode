package arrays;

public class OversizedArray {
	
	private int size;
	private int capacity;
	private int [] data;
	
	public OversizedArray(int capacity) {
		this.size = 0;
		this.capacity = capacity;
		this.data = new int [capacity];
	}
	
	public void add(int value) {
		
		if(size < capacity) {
			data[size++] = value;
		}
	}
	
	public boolean remove(int target) {
		boolean found = false;
		
		for(int i = 0; i < size; i++) {
			if(found) {
				data[i - 1] = data[i];
			}
			
			if(target == data[i]) {
				found = true;
			}
		}
		
		if(found) {
			size--;
		}
		return found;
	}
	
	public int getSize() {
		return size;
	}
	
	public boolean isEmpty() {
		return size == 0;
	}
	
	public boolean isFull() {
		return size == capacity;
	}
	
	public void print() {
		System.out.print("[");
		for(int i = 0; i < size; i++) {
			System.out.print(data[i]);
			
			if(i != size - 1) {
				System.out.print(", ");
			}
			else {
				System.out.print("]");
			}
		}
		
		System.out.println();
	}

}
