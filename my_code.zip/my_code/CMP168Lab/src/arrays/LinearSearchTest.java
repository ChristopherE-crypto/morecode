package arrays;

public class LinearSearchTest {
	
	public static void main(String [] args) {
		int [] num = {2, 3, 5, 7, 11};
		
		int index = LinearSearch.search(num, 12);
		
		if(index != -1) {
			System.out.println("The target was found at index: " + index);
		}
		else {
			System.out.println("The target was not found.");
		}
	}

}
