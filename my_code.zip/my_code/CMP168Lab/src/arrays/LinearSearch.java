package arrays;

public class LinearSearch {
	/** Searches for an element in an array using linear search.
	 * The time complexity of this algorithm is O(n), where n is the length of the array.
	 * The space complexity is O(1).
	 * 
	 * @param num The array to examine.
	 * @param target The value to search.
	 * @return Index of the target in the array. 
	 */
	public static int search(int [] num, int target) {
		for(int i = 0; i < num.length; i++) {
			if(num[i] == target) {
				return i;
			}
		}
		return -1;
	}

}
