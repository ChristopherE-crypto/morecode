package arrays;

import java.util.Arrays;

public class ReverseArrayTest {

	public static void main(String[] args) {
		
		int [] nums = {0, 2, 4, 6, 8, 10, 12};
		
		System.out.println("Original: " + Arrays.toString(nums));
		
		ReverseArray.reverse(nums);
		
		System.out.println("Reversed: " + Arrays.toString(nums));
		
		ReverseArray.reverse(nums, 1, 5);
		
		System.out.println("Reversed from 1 to 5: " + Arrays.toString(nums));

	}

}
