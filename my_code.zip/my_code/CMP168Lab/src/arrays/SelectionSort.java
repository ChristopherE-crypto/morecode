package arrays;

import java.util.Arrays;

public class SelectionSort {

	public static void main(String[] args) {
		int [] values = {8, 2, 1, 0, 3};
		
		System.out.println("Before sorting: " + Arrays.toString(values));
		
		sort(values);
		
		System.out.println("After sorting: " + Arrays.toString(values));

	}
	
	public static void sort(int [] nums) {
		for(int i = 0; i < nums.length; i++) {
			int min = i;
			
			for(int j = i + 1; j < nums.length; j++) {
				if(nums[j] < nums[min]) {
					min = j;
				}
			}
			swap(nums, i, min);
		}
	}
	
	public static void swap(int [] nums, int i, int j) {
		int temp = nums[i];
		nums[i] = nums[j];
		nums[j] = temp;
	}

}
