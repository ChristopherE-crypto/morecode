package multidimensional;

public class GradeBookTest {

	public static void main(String[] args) {
		int [][] courseGrades = {{89, 92, 85, 79}, 
								 {92, 90, 90, 99}, 
								 {80, 82, 86, 84}, 
								 {68, 62, 78, 88}, 
								 {89, 88, 89, 88}};
		
		GradeBook myGradeBook = new GradeBook("CMP-167", courseGrades);
		myGradeBook.processGrades();

	}

}
