package multidimensional;

public class Manipulations {

	public static void main(String[] args) {
		int [][] array = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
		System.out.println("Original Array");
		output(array);
		System.out.println();
		System.out.println("Modified Array");
		nullifyRow(array, 1);
		output(array);
		System.out.println();
		System.out.println("After column has been nullified");
		nullifyColumn(array, 0);
		output(array);
		System.out.println();
		System.out.printf("Sum: %d", sum(array));
		System.out.println();
		System.out.printf("Sum: %d", addValues(array));
	}
	
	public static void output(int [][] arr) {
		for(int[] row : arr) {
			for(int value : row) {
				System.out.printf("%4d", value);
			}
			System.out.println();
		}
	}
	
	public static void nullifyRow(int [][] arr, int row) {
		for(int column = 0; column < arr[row].length; column++) {
			arr[row][column] = 0;
		}
	}
	
	public static void nullifyColumn(int [][] arr, int column) {
		for(int row = 0; row < arr.length; row++) {
			arr[row][column] = 0;
		}
	}
	
	public static int sum(int [][] arr) {
		int total = 0;
		for(int row = 0; row < arr.length; row++) {
			for(int column = 0; column < arr[row].length; column++) {
				total += arr[row][column];
			}
		}
		return total;
	}
	
	public static int addValues(int [][] arr) {
		int total = 0;
		for(int [] row : arr) {
			for(int value : row) {
				total += value;
			}
		}
		return total;
	}

}
