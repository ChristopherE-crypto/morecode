package multidimensional;

public class InitArray {

	public static void main(String[] args) {
		
		int [][] b = {{1, 2}, {3, 4}};
		int [][] c = {{1, 2}, {3}, {4, 5, 6}};
		
		int [][] d = new int [3][4];
		int [][] e = new int [3][];
		e[0] = new int [2];
		e[1] = new int [5];
		e[2] = new int [3];
		
		int [][][] array3D = {{{2, 3}, {1, 6, 3}, {1, 1, 1}},{{3, 3}, {6, 6, 6, 6}}};
	}

}
