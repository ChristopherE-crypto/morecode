package inheritance;

public class Airport {

	public static void main(String[] args) {
		Airplane airplane1 = new Airplane();
		Airplane airplane2 = new Airplane();
		
		airplane1.fly();
		airplane2.fly();

	}

}
