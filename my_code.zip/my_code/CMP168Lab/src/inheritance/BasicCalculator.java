package inheritance;

public class BasicCalculator {
	
	private int result;
	private double price;
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public double getPrice() {
		return price;
	}
	
	public BasicCalculator(double price) {
		this.price = price;
	}
	
	public void setResult(int result) {
		this.result = result;
	}
	
	public int getResult() {
		return result;
	}
	
	public void add(int num1, int num2) {
		System.out.printf("The sum is %d\n", (num1 + num2));
	}
	
	public void subtract(int num1, int num2) {
		System.out.printf("The difference is %d\n", (num1 - num2));
	}
	
	@Override
	public String toString() {
		return "Basic Calculator: A cheap calculator that can perform addition and subtraction. Price: " + price;
	}
	
	

}
