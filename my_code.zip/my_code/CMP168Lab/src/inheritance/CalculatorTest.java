package inheritance;

public class CalculatorTest {

	public static void main(String[] args) {
		BasicCalculator myBasicCalculator = new BasicCalculator(25.99);
		
		int num1 = 20, num2 = 10;
		myBasicCalculator.add(num1, num2);
		myBasicCalculator.subtract(num1, num2);
		System.out.println(myBasicCalculator.toString());
		
		System.out.println();
		
		AdvancedCalculator myAdvancedCalculator = new AdvancedCalculator(60.99);
		
		myAdvancedCalculator.add(num1, num2);
		myAdvancedCalculator.subtract(num1, num2);
		myAdvancedCalculator.multiply(num1, num2);
		System.out.println(myAdvancedCalculator);
		
		System.out.println();
		
		BasicCalculator myOtherCalculator = new AdvancedCalculator(85.99);
		
		myOtherCalculator.add(num1, num2);
		myOtherCalculator.subtract(num1, num2);
		if(myOtherCalculator instanceof AdvancedCalculator) {
			((AdvancedCalculator)myOtherCalculator).multiply(num1, num2);
			System.out.println("It was an instance of AdvancedCalculator...");
		}
		
		
		System.out.println(myOtherCalculator);

	}

}
