package inheritance;

public class AdvancedCalculator extends BasicCalculator {
	public AdvancedCalculator(double price) {
		super(price);
	}
	
	
	public void multiply(int num1, int num2) {
		super.setResult( num1 * num2);
		System.out.printf("The product is %d\n", super.getResult());
	}
	
	@Override
	public String toString() {
		return "Advanced Calculator: A fancy calculator that can perfom addition, subtraction, and multiplication. Price: " + getPrice();
	}

}
