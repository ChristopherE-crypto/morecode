package inheritance;

public class Engine {
	private int id;
	
	public Engine(int id) {
		this.id = id;
	}
	
	public void start() {
		System.out.printf("Engine %d starting... \n", id);
		
	}

}
