package inheritance;

public class Airplane {
	
	private final Engine engine1;
	private final Engine engine2;
	
	public Airplane() {
		this.engine1 = new Engine(1);
		this.engine2 = new Engine(2);
	}
	
	public void fly() {
		engine1.start();
		engine2.start();
		System.out.println("I'm flying...");
	}

}
