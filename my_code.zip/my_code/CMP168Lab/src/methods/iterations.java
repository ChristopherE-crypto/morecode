package methods;

import java.util.Scanner;

public class iterations {
	public static void main(String [] args) {
		//useWhileLoop();
		
		//useForLoop();
		
		//showEvenNumbers();
		
		//findFirstPower();
		
		enterGrades();
		
	}

	private static void showEvenNumbers() {
		System.out.println("Even numbers from 0 to 30: ");
		
		for(int i = 0; i <= 30; i += 2) {
			System.out.printf("%d ", i);
		}
		System.out.println();
	}

	private static void useForLoop() {
		System.out.println("Using a for loop: ");
		for(int i = 1; i <= 20; i++) {
			System.out.printf("%d ", i);
		}
		System.out.println();
	}

	private static void useWhileLoop() {
		System.out.println("Using a while loop: ");
		int counter = 1;
		
		while(counter <= 20) {
			System.out.printf("%d ", counter++);
		}
		System.out.println();
	}
	
	private static void findFirstPower() {
		int power = 3;
		
		while(power <= 100) {
			power = power * 3;
		}
		System.out.printf("First Power of 3 Greater Than 100: %d\n", power);
	}
	
	private static void enterGrades() {
		Scanner scnr = new Scanner(System.in);
		System.out.printf("Enter a grade (or -1 to quit): ");
		int grade = scnr.nextInt(), total = 0, numGrades = 0;
		
		while(grade != -1) {
			if(grade < 0 || grade > 100) {
				System.out.println("Invalid grade!");
			}
			else {
				total += grade;
				numGrades++;
			}
			System.out.printf("Enter a grade (or -1 to quit): ");
			grade = scnr.nextInt();
		}
		
		System.out.printf("The total is %d\n", total);
		System.out.printf("%d grades were entered in.\n", numGrades);
		System.out.printf("The average is %.2f\n", (double) total / numGrades);
	}

}
