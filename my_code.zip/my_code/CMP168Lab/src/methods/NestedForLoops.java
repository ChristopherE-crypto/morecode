package methods;

public class NestedForLoops {
	public static void main(String [] args) {
		
		for(char c1 = 'a'; c1 <= 'z'; c1++) {
			for(char c2 = 'a'; c2 <= 'z'; c2++) {
				System.out.println(c1 + "" + c2);
			}
		}
	}

}
