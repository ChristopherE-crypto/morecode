package methods;

public class Maximum {

	public static void main(String[] args) {
		System.out.printf("The largest value is %d\n", maximum(40, 98, 32));
		System.out.printf("The largest value is %d\n", maximum2(40, 98, 32));
		
		int [] nums = {45, 12, 8, 16, 20};
		for(int num : nums) {
			System.out.printf("%d ", num);
		}
		System.out.println();

	}
	
	public static int maximum(int x, int y, int z) {
		 int greatest = x;
		 if(y > greatest) {
			 greatest = y;
		 }
		 if(z > greatest) {
			 greatest = z;
		 }
		 return greatest;
	}
	
	public static int maximum2(int x, int y, int z) {
		return x > y && x > z ? x : y > z ? y : z;
	}

}
