package oop;

public class Employee {
	private String name, designation;
	private int age;
	private double salary;
	private int id;
	private static int numEmployees;
	
	public Employee(String name) {
		this.name = name;
		this.id = ++numEmployees;
	}
	
	public Employee(String name, int age, String designation, double salary) {
		this.name = name;
		this.age = age;
		this.designation = designation;
		this.salary = salary;
		this.id = ++numEmployees;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	public void setSalary(double salary) {
		if(salary < 0 ) {
			throw new IllegalArgumentException("Invalid salary!");
		}
		this.salary = salary;
	}
	
	public void print() {
		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
		System.out.println("Employee ID: " + id);
		System.out.println("Designation: " + designation);
		System.out.println("Salary: " + salary);
		
	}

}
