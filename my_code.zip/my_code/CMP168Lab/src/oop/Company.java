package oop;

public class Company {
	
	public static void main(String [] args) {
		Employee employee1 = new Employee("John Doe");
		Employee employee2 = new Employee("Jane Smith");
		
		employee1.setAge(24);
		employee1.setDesignation("Software Engineer");
		employee1.setSalary(70000);
		
		employee1.print();
		
		employee2.setAge(34);
		employee2.setDesignation("Senior Software Engineer");
		employee2.setSalary(120000);
		
		employee2.print();
		
		Employee [] employees = {employee1, employee2};
		
		for(Employee employee : employees) {
			employee.print();
			System.out.println();
		}
	}

}
