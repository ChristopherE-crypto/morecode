package abstract_classes;

public class AnimalFarm {
	
	public static void main(String [] args) {
		Cat myCat = new Cat();
		Cow myCow = new Cow();
		Snake mySnake = new Snake();
		Lizard myLizard = new Lizard();
		Pig myPig = new Pig();
		
		myCat.setName("Armando");
		myCow.setName("Mary");
		mySnake.setName("Pepe");
		myLizard.setName("Rocky");
		myPig.setName("George");
		
		
		
		Animal [] animals = {myCat, myCow, mySnake, myLizard, myPig};
		
		for(int i = 0; i < animals.length; i++) {
			System.out.print(animals[i] + ":");
			animals[i].eat();
			System.out.println();
			
		}
	}

}
