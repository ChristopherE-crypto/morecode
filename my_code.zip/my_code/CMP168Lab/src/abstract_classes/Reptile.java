package abstract_classes;

public abstract class Reptile extends Animal{
	public abstract void warmUpBody();
	public abstract void shedOuterLayerOfSkin();
}
