package abstract_classes;

public class Lizard extends Reptile{

	@Override
	public void warmUpBody() {
		System.out.println("I'm a Lizard and I'm getting some sunlight!");
		
	}

	@Override
	public void shedOuterLayerOfSkin() {
		System.out.println("I'm getting rid of my old outer skin.");
		
	}

	@Override
	public void eat() {
		System.out.println("I'm eating a fly, and it is delicious...");
		
	}
	
}
