package abstract_classes;

public class Snake extends Reptile {
	@Override
	public void eat() {
		System.out.println("I'm eating a big frog!");
	}
	
	@Override
	public void warmUpBody() {
		System.out.println("As a snake, I need to warm up my body in order to survive.");
	}
	
	@Override
	public void shedOuterLayerOfSkin() {
		System.out.println("I'm getting rid of my old skin...");
	}
}
