package abstract_classes;

public class Cat extends Mammal implements Pet{
	@Override
	public void eat() {
		System.out.println("I'm eating a mouse!");
	}
	
	@Override
	public void drinkMilk() {
		System.out.println("As a cat, I really like this milk...");
	}
	
	@Override
	public void beCute() {
		System.out.println("Oh, I'm so cute!");
	}
}
