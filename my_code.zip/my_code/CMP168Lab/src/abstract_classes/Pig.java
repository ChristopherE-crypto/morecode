package abstract_classes;

public class Pig extends Mammal {

	@Override
	public void drinkMilk() {
		System.out.println("I'm a pig, and I like milk!");
		
	}

	@Override
	public void eat() {
		System.out.println("I'm eating some stuff...");
		
	}

}
