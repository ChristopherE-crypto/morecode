package abstract_classes;

public class Cow extends Mammal {
	@Override
	public void eat() {
		System.out.println("I'm eating grass!");
	}
	
	@Override
	public void drinkMilk() {
		System.out.println("This milk tastes good!");
	}
}
