package abstract_classes;

public abstract class Mammal extends Animal {
	
	public abstract void drinkMilk();
}
