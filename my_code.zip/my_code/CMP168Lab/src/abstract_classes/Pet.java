package abstract_classes;

public interface Pet {
	void beCute();
	
}
