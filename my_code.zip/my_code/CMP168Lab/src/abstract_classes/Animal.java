package abstract_classes;

public abstract class Animal {
	private String name;
	private double weight;
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public abstract void eat();
	
	@Override
	public String toString() {
		return String.format("{%s}", getName());
	}
}
