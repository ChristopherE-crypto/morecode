package challenge2;

import java.util.Arrays;

public class Cycles {
	
	public static int sortDescending(String n) {
		
		int num = Integer.valueOf(n);
		
		int [] nums = new int[n.length()];
		
		for(int i = 0; i < nums.length; i++) {
			
			nums[i] = num % 10;
			
			num /= 10;
		}
		
		int pos;
		int temp;
		
		for(int i = 0; i < nums.length; i++) {
			
			pos = i;
			
			for(int j = i + 1; j < nums.length; j++) {
				
				if(nums[j] > nums[pos]) {
					
					pos = j;
				}
			}
			
			temp = nums[pos];
			nums[pos] = nums[i];
			nums[i] = temp;
		}
		
		String result = "";
		
		for(int i = 0; i < nums.length; i++) {
			
			result += nums[i];
		}
		
		return Integer.valueOf(result);
	}
	
	public static int sortAscending(String n) {
		
		int num = Integer.valueOf(n);
		
		int [] nums = new int[n.length()];
		
		for(int i = 0; i < nums.length; i++) {
			
			nums[i] = num % 10;
			
			num /= 10;
		}
		
		int pos;
		int temp;
		
		for(int i = 0; i < nums.length; i++) {
			
			pos = i;
			
			for(int j = i + 1; j < nums.length; j++) {
				
				if(nums[j] < nums[pos]) {
					
					pos = j;
				}
			}
			
			temp = nums[pos];
			nums[pos] = nums[i];
			nums[i] = temp;
		}
		
		String result = "";
		
		for(int i = 0; i < nums.length; i++) {
			
			result += nums[i];
		}
		
		return Integer.valueOf(result);
	}
	
	public static int solution(String n, int b) {
		
		String nb = n;
		
		String result = "";
		
		while(true) {
			
			System.out.println("ORIGINAL NB = " + nb);
			
			String n10 = convertToBase10(nb, b); // convert n to base 10
			
			System.out.println("NB TO B 10 = " + n10);
			
			int x = sortDescending(n10); // sort n
			
			System.out.println("N10 IN DESCENDING ORDER = " + x);
			
			int y = sortAscending(n10); // sort n
			
			System.out.println("N10 IN ASCENDING ORDER = " + y);
			
			int z = x - y;
			
			System.out.println("Z = " + z);
			
			String nbNew = convertToBaseB(String.valueOf(z), b);
			
			System.out.println("NBNEW IN BASE B = " + nbNew);
			
			if(nb.equals(nbNew)) {
				
				System.out.println("PREVIOUS N = " + nb + " CURRENT N = " + nbNew);
				result = nbNew;
				break;
			}
			
			nb = nbNew;
			
		}
		
		return convertToBase10(result, b).length();
	}
	
	public static void main(String [] args) {
		
		
		
		String nb = "2112"; // Number n in base b
		
		int k = 6, b = 3;
		
		System.out.println(solution(nb, b));
		
		
		
	}
	
	public static String convertToBase10(String n, int b) {
		
		return String.valueOf(Integer.parseInt(n, b));
	}
	
	public static String convertToBaseB(String n, int b) {
		
		return Integer.toString(Integer.valueOf(n), b);
	}
	
	
	

}
