package challenge1;

import java.util.Hashtable;

public class Decoding {
	
	public static String decode(String s) {
		
		Hashtable<Character, Character> ht = new Hashtable<Character, Character>();
		
		char [] letters = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
		
		for(int i = 0, j = letters.length - 1; i < letters.length && j >= 0; i++, j--) {
			
			ht.put(letters[i], letters[j]);
		}
		
		String decoded = "";
		
		for(char letter : s.toCharArray()) {
			
			if(Character.isLetter(letter) && Character.isLowerCase(letter)) {
			
				decoded += ht.get(letter);
			
			}
			else {
				
				decoded += letter;
			}
			
			
		}
		
		return decoded;
	}

	public static void main(String[] args) {
		
		System.out.println(decode("Yvzs! I xzm'g yvorvev Lzmxv olhg srh qly zg gsv xlolmb!!"));
		
		char letter = 'z';
		
		System.out.println(Character.getNumericValue(letter));
	}

}
