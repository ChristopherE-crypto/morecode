import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;
import java.util.Scanner;
public class Exam {
	
	public int enterNumber() throws IOException{
		 int value;
		 value = System.in.read();
		 return value;
		}	
	
	
	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		double x = 9.0;
		double y = 4.0;
		y = Math.pow(Math.sqrt(x), Math.sqrt(y));
		
		System.out.println(y);
	}
}
