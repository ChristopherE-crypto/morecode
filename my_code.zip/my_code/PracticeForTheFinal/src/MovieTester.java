import java.util.Arrays;

public class MovieTester {

	public static void main(String[] args) {
		
		String [] names = new String [5];
		names[0] = "Carlos";
		names[1] = "Pedro";
		names[2] = "Robin";
		String [] names2 = {"Robert", "Maria", "Pepe"};
		
		Movie test = new Movie("Transformers", 90, true, names);
		Movie test2 = new Movie("Transformers", 120, true, names2);
		
		Movie test3 = new Movie();
		
		test3.setMovieName("Naruto");
		test3.setNumMinutes(85);
		
		//System.out.println(test.equals(test2));
		
		//System.out.println(Arrays.toString(test.getCastMembers()));
		
		//System.out.println(test.replaceCastMember(1, "Pepe"));
		
		//System.out.println(Arrays.toString(test.getCastMembers()));
		
		//System.out.println(test.doArraysMatch(names, names2));
		
		System.out.println(test.getCastMemberNamesAsString());
		System.out.println(test.replaceCastMember(-1, "Jose"));
		System.out.println(test.getCastMemberNamesAsString());
		System.out.println(test.getNumCastMembers());
		
		//System.out.println(test3.replaceCastMember(10, "Sasuke"));
		//System.out.println(test3.replaceCastMember(11, "Kakashi"));
		//System.out.println(test3.replaceCastMember(12, "Itachi"));
		
		System.out.println(test3.getCastMemberNamesAsString());
		System.out.println(test3.getNumCastMembers());
		
		//System.out.println(test.toString());
		
		
		
		
		
		
		
		
		/*
		 * public int getNumCastMembers() {
	   if(movieName.equals("Flick")){
	      numCastMembers = 0;
	      return numCastMembers;
	   }
	   else{
	      numCastMembers = castMembers.length;
	      return numCastMembers;
	   }
		
	}
	
	
	public String [] getCastMembers() {
	   String [] copy = new String [castMembers.length];
	   for(int i = 0; i < castMembers.length; i++){
	      copy[i] = castMembers[i];
	   }
	   castMembers = copy;
		return castMembers;
	}
		 */
		
		
		

	}

}
