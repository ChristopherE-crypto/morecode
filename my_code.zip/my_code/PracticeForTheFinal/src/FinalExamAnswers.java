import java.util.Arrays;
import java.util.Scanner;

public class FinalExamAnswers {
	
	public static void manipulateString() {
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Enter a sentence");
		String sentence = scnr.nextLine();
		sentence = sentence.toLowerCase();
		
		String [] words = new String [sentence.length()];
		
		words = sentence.split(" ");
		
		for(int j = 0; j < words.length; j++) {
			if(j % 2 == 0) {
				words[j] = words[j].toUpperCase();
			}
		}
		
		System.out.println(Arrays.toString(words));
		
	    String temp;
	    
	    for(int i = 0; i < (words.length / 2); ++i) {
	    	temp = words[i];
	    	words[i] = words[words.length - 1 - i];
	    	words[words.length - 1 - i] = temp;
	    }
	    String reversedsentence;
	    reversedsentence = String.join(" ", words);
	    //reversedsentence = Arrays.toString(words).replace(",", "");
	    System.out.print(reversedsentence.replace("[", "").replace("]", ""));
		
	}
	
	public static void main(String [] args) {
		
		manipulateString();
		
	}

}
