import java.util.Arrays;

public class Movie {
	private String movieName;
	private int numMinutes;
	private boolean isKidFriendly;
	private int numCastMembers;
	private String [] castMembers;
	
	public Movie() {
		movieName = "Flick";
		numMinutes = 0;
		isKidFriendly = false;
		numCastMembers = 0;
		castMembers = new String [10];
	}
	public Movie(String movieName, int numMinutes, boolean isKidFriendly, String [] castMembers) {
		this.movieName = movieName;
		this.numMinutes = numMinutes;
		this.isKidFriendly = isKidFriendly;
		this.castMembers = castMembers;
	}
	
	//Setters for the object Movie:------------------------------------------------------------------
	
	public void setNumMinutes(int numMinutes) {//Correct.
		this.numMinutes = numMinutes;
	}
	public void setMovieName(String movieName) {//Correct.
		this.movieName = movieName;
	}
	public void setIsKidFriendly(boolean isKidFriendly) {//Correct.
		this.isKidFriendly = isKidFriendly;
	}
	
	//Getters for the object Movie:-------------------------------------------------------------------
	
	public int getNumMinutes() {//Correct.
		return numMinutes;
	}
	public String getMovieName() {//Correct.
		return movieName;
	}
	public boolean isKidFriendly() {//Correct.
		return isKidFriendly;
	}
	public int getNumCastMembers() {
		//numCastMembers = castMembers.length;
		int counter = 0;
		for(int i = 0; i < castMembers.length; i++) {
			if(castMembers[i] != null) {
				counter++;
			}
		}
		numCastMembers = counter;
		return numCastMembers;
	}
	public String [] getCastMembers() {//Copied the elements form castMembers to copy.
		String [] copy = new String [castMembers.length];
		for(int i = 0; i < getNumCastMembers(); i++) {
			copy[i] = castMembers[i];
		}
		castMembers = copy;
		return castMembers;
	}
	
	//Methods for the object Movie:---------------------------------------------------------------------
	
	public boolean replaceCastMember(int index, String castMemberName) {//I think it works.
		
		if(index >= 0 && index < numCastMembers) {
			numCastMembers = 1 + numCastMembers;
			String [] copy = new String [castMembers.length];
			
			for(int i = 0; i < castMembers.length; i++) {
				copy[i] = castMembers[i];
				if(i == index) {
					copy[i] = castMemberName;
					
				}
			}
			numCastMembers = getNumCastMembers() + 1;
			castMembers = copy;
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean doArraysMatch(String [] arr1, String [] arr2) {
		if(Arrays.deepEquals(arr1, arr2)) {
			return true;
		}
		if(arr1 == null && arr2 != null) {
			return false;
		}
		if(arr1 == null && arr2 == null) {
			return true;
		}
		else {
			return false;
		}
		
		
	}
	
	public String getCastMemberNamesAsString() {
		String arr;
		if(getNumCastMembers() == 0) {
		
		return "none";
		}
		else {
			arr = String.join(", ", castMembers);
			
			return arr;
		}
		
	}
	
	public String toString() {
		String info;
		if(isKidFriendly == true) {
		info = String.format("Movie: [ Minutes %03d | Movie Name: %20s | is kid friendly | Number of Cast Members %d | Cast Members: %s ]", getNumMinutes(), getMovieName(), getNumCastMembers(), getCastMemberNamesAsString());
		}
		else {
			info = String.format("Movie: [ Minutes %03d | Movie Name: %20s | is kid friendly | Number of Cast Members %d | Cast Members: %s ]", getNumMinutes(), getMovieName(), getNumCastMembers(), getCastMemberNamesAsString());
		}
		return info;
	}
	
	
	public boolean equals(Movie m) {
		if(m == null) {
			return false;
		}
		if(this == m) {
			return true;
		}
		if(m instanceof Movie) {
			Movie otherMovie = (Movie)m;
			if(this.movieName.equals(otherMovie.movieName)) {
				if(this.numMinutes == otherMovie.numMinutes) {
					if(this.isKidFriendly == otherMovie.isKidFriendly) {
						if(this.numCastMembers == otherMovie.numCastMembers) {
							if(doArraysMatch(this.getCastMembers(), otherMovie.getCastMembers())) {
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}
	
	

}
