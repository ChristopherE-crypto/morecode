import java.util.Arrays;
import java.util.Scanner;

public class FinalPractice {
	
	public static void shiftArrayLeft() {// First it takes in the number of elements, then stores the numbers from the user in the array and lastly, it shifts one element from the array to the left 1 unit.
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Enter the number of elements: ");
		int n = scnr.nextInt();
		int [] nums = new int [n];
		
		for(int i = 0; i < n; i++) {
			System.out.println("Enter your numbers: ");
			nums[i] = scnr.nextInt();
		}
		int temp = nums[0];
		for(int i = 0; i < n - 1; i++) {
			nums[i] = nums[i + 1];
			
		}
		nums[n - 1] = temp;
		System.out.println(Arrays.toString(nums));
	}
	
	public static void shiftArrayRight() {//Takes in the number of elements, the number of rotations and the elements. Rotates to the right.
		Scanner scnr = new Scanner(System.in);
		System.out.println("Enter the number of elements: ");
		int n = scnr.nextInt();
		System.out.println("Enter the number of times for it to be rotated: ");
		int r = scnr.nextInt();
		int [] nums = new int [n];
		
		for(int i = 0; i < n; i++) {
			System.out.println("Enter your numbers: ");
			nums[i] = scnr.nextInt();
		}
		
		for(int i = 0; i < r; i++) {
			int j, temp;
			
			temp = nums[nums.length - 1];
			
			for(j = nums.length - 1; j > 0; j--) {
				
				nums[j] = nums[j - 1];
			}
			nums[0] = temp;
		}
		System.out.println(Arrays.toString(nums));
	}

	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		//shiftArrayLeft();
		shiftArrayRight();
	}

}
