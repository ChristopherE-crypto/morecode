
public abstract class Vehicle {
	protected Person[][] personsOnBoard;
	protected int numberOfRows;
	protected int maxSeatsPerRow;
	protected int[] numSeatsPerRow;
	
	public Vehicle(int numRows, int numSeatsPerRow) {
		numberOfRows = numRows;
		personsOnBoard = new Person [numRows][numSeatsPerRow];
	}
	
	public Vehicle(int [] numSeatsPerRow) {
		personsOnBoard = new Person [numSeatsPerRow.length][];
		for(int i = 0; i < numSeatsPerRow.length; i++) {
			personsOnBoard[i] = new Person[numSeatsPerRow[i]];
		}
		this.numSeatsPerRow = numSeatsPerRow;
	}
	
	public Vehicle(Person driver, int [] numSeatsPerRow) {//Might need to add a try/catch.
		if(driver.hasDriverLicense()) {
			personsOnBoard = new Person [numSeatsPerRow.length][];
			for(int i = 0; i < numSeatsPerRow.length; i++) {
				personsOnBoard[i] = new Person[numSeatsPerRow[i]];
			}
			personsOnBoard[0][0] = driver;
			this.numSeatsPerRow = numSeatsPerRow;
		}
		//Could add else with the Exception.
	}
	
	public abstract boolean loadPassenger(Person p);//Person must sit at the first available seat and people below age 5 and height less than 36 can't sit in the first row.
	
	public abstract int loadPassengers(Person [] peeps);//Return number of people loaded to the vehicle.
	
	public void setDriver(Person p) throws InvalidDriverException {
		if(p.hasDriverLicense()) {
			personsOnBoard[0][0] = p;
		}
		else {
			throw new InvalidDriverException("This Person Does Not Have A Driver License!");
		}
	}
	
	public Person getDriver() {
		if(personsOnBoard[0][0] != null) {
			return personsOnBoard[0][0];
		}
		else {
			return null;
		}
	}
	
	public boolean hasDriver() {
		if(personsOnBoard[0][0] != null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public int getNumberOfAvailableSeats() {
		int counter = 0;
		for(int i = 0; i < personsOnBoard.length; i++) {
			for(int j = 0; j < personsOnBoard[i].length; j++) {
				if(personsOnBoard[i][j] == null) {
					counter++;
				}
			}
		}
		return counter;
	}
	
	public int getNumberOfAvailableSeatsInRow(int row) {
		int counter = 0;
		if(row < 0 || row > personsOnBoard.length) {
			return -1;
		}
		else {
			for(int i = 0; i < personsOnBoard[row].length; i++) {
				if(personsOnBoard[row][i] == null) {
					counter++;
				}
			}
			return counter;
		}
	}
	
	public int getNumberOfPeopleOnBoard() {
		int counter = 0;
		for(int i = 0; i < personsOnBoard.length; i++) {
			for(int j = 0; j < personsOnBoard[i].length; j++) {
				if(personsOnBoard[i][j] != null) {
					counter++;
				}
			}
		}
		return counter;
	}
	
	public int getNumberOfPeopleInRow(int row) {
		int counter = 0;
		if(row < 0 || row > personsOnBoard.length) {
			return -1;
		}
		else {
			for(int i = 0; i < personsOnBoard[row].length; i++) {
				if(personsOnBoard[row][i] != null) {
					counter++;
				}
			}
			return counter;
		}
	}
	
	public Person getPersonInSeat(int row, int col) {
		if(row > 0 && row < personsOnBoard.length && col > 0 && col < personsOnBoard[row].length && personsOnBoard[row][col] != null) {
			return personsOnBoard[row][col];
		}
		else {
			return null;
		}
	}
	
	public int [] getLocationOfPersonInVehicle(Person p) {
		int [] location = {-1, -1};
		if(p != null) {
			for(int i = 0; i < personsOnBoard.length; i++) {
				for(int j = 0; j < personsOnBoard[i].length; j++) {
					if(personsOnBoard[i][j] != null && personsOnBoard[i][j].equals(p)) {
						location[0] = i;
						location[1] = j;
					}
					else {
						location[0] = -1;
						location[1] = -1;
					}
				}
			}
			return location;
		}
		else {
			location[0] = -1;
			location[1] = -1;
			return location;
		}
	}
	
	public Person [] getPeopleInRow(int row) {
		if(row < 0 || row > personsOnBoard.length || getNumberOfPeopleInRow(row) == 0) {
			return null;
		}
		else {
			Person [] peopleInRow = new Person [getNumberOfPeopleInRow(row)];
			for(int i = 0; i < peopleInRow.length; i++) {
				peopleInRow[i] = personsOnBoard[row][i].clone();
			}
			return peopleInRow;
		}
	}
	
	public Person [][] getPeopleOnBoard(){
		Person [][] clone = new Person [personsOnBoard.length][];
		for(int i = 0; i < personsOnBoard.length; i++) {
			for(int j = 0; j < personsOnBoard[i].length; i++) {
				clone[i][j] = personsOnBoard[i][j];
			}
		}
		return clone;
	}
	
	public boolean isPersonInVehicle(Person p) {
		if(p != null) {
			for(int i = 0; i < personsOnBoard.length; i++) {
				for(int j = 0; j < personsOnBoard[i].length; j++) {
					if(personsOnBoard[i][j].equals(p)) {
						return true;
					}
					else {
						return false;
					}
				}
			}
		}
		
		return false;//Not sure about this return.
	}
	
	public boolean isPersonDriver(Person p) {
		if(p != null && personsOnBoard[0][0] != null) {
			if(personsOnBoard[0][0].equals(p)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
		
}
