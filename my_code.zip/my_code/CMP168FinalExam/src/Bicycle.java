
public class Bicycle extends Vehicle implements Comparable <Bicycle> {
	private double weight;
	
	public Bicycle() {
		super(1, 1);
		weight = 0.0;
	}
	
	public Bicycle(Person driver) {
		super(driver, new int [1]);
		weight = 0.0;
	}
	
	public Bicycle(Person driver, double weight) {
		super(driver, new int [1]);
		if(weight < 0) {
			weight = 0.0;
		}
		else {
			this.weight = weight;
		}
	}
	
	public boolean equals(Object obj) {
		if(obj == null) {return false;}
		if(this == obj) {return true;}
		if(obj instanceof Bicycle) {
			Bicycle otherB = (Bicycle)obj;
			if(Math.abs(this.getWeight() - otherB.getWeight()) < 0.5) {
				return true;
			}
		}
		return false;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public void setWeight(double weight) {
		if(weight < 0) {
			this.weight = 0.0;
		}
		else {
			this.weight = weight;
		}
	}
	
	public void setDriver(Person p) throws InvalidDriverException {
		if(p != null && p.getAge() > 3) {
			super.personsOnBoard[0][0] = p;
		}
		else {
			throw new InvalidDriverException("This Person Cannot Ride The Bicycle: Age Less Than 3");
		}
	}
	
	public String toString() {
		return "Bicycle [rider= " + getDriver().getName() + " | weight= " + weight + " ]";
	}
	
	public int compareTo(Bicycle b) {
		if((this.getWeight() - b.getWeight()) > 0.5) {
			return -1;
		}
		else if((b.getWeight() - this.getWeight()) > 0.5) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean loadPassenger(Person p) {
		return false;
	}

	@Override
	public int loadPassengers(Person[] peeps) {
		return 0;
	}
}
