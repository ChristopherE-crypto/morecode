
public class InvalidDriverException extends Exception{
	public InvalidDriverException() {
		
	}
	
	public InvalidDriverException(String message) {
		
	}
}
