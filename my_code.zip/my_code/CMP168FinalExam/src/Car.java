import java.util.Arrays;

public class Car extends Vehicle implements Comparable<Car>, Announcements{
	private int numDoors;
	private int numWindows;
	
	public Car(int numDoors, int numWindows) {
		super(2, 2);
		this.numDoors = numDoors;
		this.numWindows = numWindows;
	}
	
	public Car(int numDoors, int numWindows, int numSeatsPerRow) {
		super(2, numSeatsPerRow);
		this.numDoors = numDoors;
		this.numWindows = numWindows;
	}
	
	public Car(int numDoors, int numWindows, int [] numSeatsPerRow) {
		super(numSeatsPerRow);
		this.numDoors = numDoors;
		this.numWindows = numWindows;
	}
	
	public Car(int numDoors, int numWindows, Person driver, int [] numSeatsPerRow) {
		super(driver, numSeatsPerRow);
		this.numDoors = numDoors;
		this.numWindows = numWindows;
	}
	
	public boolean canOpenDoor(Person p) {
		if(p != null) {
			int [] location = super.getLocationOfPersonInVehicle(p);
			if(p.getAge() > 5 && location[1] == 0 || location[1] == super.numSeatsPerRow.length) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	public boolean canOpenWindow(Person p) {//FIXME: There's probably something wrong with this.
		if(p != null && getNumWindows() < 2 * super.numberOfRows) {
			int [] location = super.getLocationOfPersonInVehicle(p);
			if(p.getAge() > 5 && location[1] == 0 || location[1] == super.numSeatsPerRow.length) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	public int getNumDoors() {
		return numDoors;
	}
	
	public int getNumWindows() {
		return numWindows;
	}
	
	public boolean equals(Object obj) {
		if(obj == null) {return false;}
		if(this == obj) {return true;}
		if(obj instanceof Car) {
			Car otherC = (Car)obj;
			if(this.getNumDoors() == otherC.getNumDoors()) {
				if(this.getNumWindows() == otherC.getNumWindows()) {
					if(this.numberOfRows == otherC.numberOfRows) {
						if(this.maxSeatsPerRow == otherC.maxSeatsPerRow) {
							if(this.numSeatsPerRow.length == otherC.numSeatsPerRow.length) {
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}
	
	public String toString() {
		String names = "";
		for(int i = 0; i < super.personsOnBoard.length; i++) {
			for(int j = 0; j < super.personsOnBoard[i].length; j++) {
				if(personsOnBoard[i][j] != null) {
					names += personsOnBoard[i][j].getName() + ", ";
				}
			}
		}
		names = names.substring(0, names.length() - 2);
		
		return String.format("Car: number of doors=%02d | number of windows = %02d | number of rows= %02d | seats per row= %s | names of people on board= %s\n", getNumDoors(), getNumWindows(), super.numberOfRows, Arrays.toString(super.numSeatsPerRow), names);
	}
	
	public int compareTo(Car c) {
		int totalSeats1 = 0;
		int totalSeats2 = 0;
		for(int i = 0; i < this.numSeatsPerRow.length; i++) {
			totalSeats1 += numSeatsPerRow[i];
		}
		for(int i = 0; i < c.numSeatsPerRow.length; i++) {
			totalSeats2 += numSeatsPerRow[i];
		}
		
		if(totalSeats1 > totalSeats2) {
			return -1;
		}
		else if(totalSeats1 < totalSeats2) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean loadPassenger(Person p) {
		if(p != null) {
			if(p.getAge() < 5 || p.getHeight() < 36) {
				for(int i = 1; i < personsOnBoard.length; i++) {
					for(int j = 0; j < personsOnBoard[i].length; j++) {
						if(personsOnBoard[i][j] == null) {
							personsOnBoard[i][j] = p;
							return true;
						}
						else {
							return false;
						}
					}
				}
			}
			else {
				for(int i = 0; i < personsOnBoard.length; i++) {
					for(int j = 0; j < personsOnBoard[i].length; j++) {
						if(personsOnBoard[i][j] == null) {
							personsOnBoard[i][j] = p;
							return true;
						}
						else {
							return false;
						}
					}
				}
			}
		}
		
	return false;
			
	}

	@Override
	public int loadPassengers(Person[] peeps) {
		int peopleL = 0;
		for(int i = 0; i < peeps.length; i++) {
			if(peeps[i] != null && peeps[i].getAge() < 5 || peeps[i].getHeight() < 36) {
				for(int row = 1; row < super.personsOnBoard.length; row++) {
					for(int col = 0; col < super.personsOnBoard[row].length; col++) {
						if(personsOnBoard[row][col] == null) {
							personsOnBoard[row][col] = peeps[i];
							peopleL++;
						}
					}
				}
			}
			else if(peeps[i] != null){
				for(int row = 0; row < super.personsOnBoard.length; row++) {
					for(int col = 0; col < super.personsOnBoard[row].length; col++) {
						if(personsOnBoard[row][col] == null) {
							personsOnBoard[row][col] = peeps[i];
							peopleL++;
						}
					}
				}
			}
		}
		return peopleL;
	}

	@Override
	public String departure() {
		return "All Aboard\n";
	}

	@Override
	public String arrival() {
		return "Everyone Out\n";
	}

	@Override
	public String doNotDisturbTheDriver() {
		return "No Backseat Driving\n";
	}
}
