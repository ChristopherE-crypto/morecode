import java.util.Arrays;

public class Tester {

	public static void main(String[] args) {
		
		int [] numRows = {2, 2};
		
		int [] location;
		
		Person p = new Person("Carlos", true, 20, 85);
		Person p1 = new Person("Jose", false, 25, 100);
		Person p2 = new Person("Maria", false, 30, 80);
		
		Car c = new Car(4, 5, numRows);
		
		System.out.println(c.getNumberOfAvailableSeats());
		
		System.out.println(c.loadPassenger(p));
		
		System.out.println(c.getNumberOfAvailableSeats());
		
		System.out.println(c.loadPassenger(p1));
		
		System.out.println(c.getNumberOfAvailableSeats());
		
		System.out.println(c.loadPassenger(p2));
		
		System.out.println(c.getNumberOfAvailableSeats());
		
		System.out.println(c.isPersonInVehicle(p));
		System.out.println(c.isPersonInVehicle(p1));
		System.out.println(c.isPersonInVehicle(p2));
		
		if(c.isPersonInVehicle(p)) {
			System.out.println("Person is in the vehicle!");
			System.out.println(Arrays.toString(c.getLocationOfPersonInVehicle(p)));
		}
		else {
			System.out.println("Person is not in the vehicle!");
		}
		
		//System.out.println(c.getNumberOfPeopleOnBoard());
		
		
		//System.out.println(Arrays.toString(c.getLocationOfPersonInVehicle(p)));
		
		//location = c.getLocationOfPersonInVehicle(p);
		
		//System.out.println(Arrays.toString(c.getPeopleInRow(0)));
		
		//System.out.println(Arrays.toString(location));
		

	}

}
