
public class Bus extends Car{
	public Bus(int [] numSeatsPerRow) {
		super(2, (2 * numSeatsPerRow.length) - 1, numSeatsPerRow);
	}
	
	public Bus(Person driver, int [] numSeatsPerRow) {
		super(2, (2 * numSeatsPerRow.length) - 1, driver, numSeatsPerRow);
	}
	
	public boolean canOpenDoor(Person p) {
		if(p != null) {
			Person lastP = super.personsOnBoard[0][0];
			for(int i = 0; i < super.personsOnBoard.length; i++) {
				for(int j = 0; j < super.personsOnBoard[i].length; j++) {
					if(i > 0 && j > 0 && i < super.numberOfRows && j < super.maxSeatsPerRow && super.personsOnBoard[i][j + 1] == null) {
						lastP = super.personsOnBoard[i][j];
					}
				}
			}
			if(super.isPersonDriver(p) || p.equals(lastP) && p.getAge() > 5 && p.getHeight() > 40) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	public boolean canOpenWindow(Person p) {
		if(p != null && super.canOpenWindow(p) && p.getAge() > 5) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public String toString() {
		return "Bus is an extension of " + super.toString();
	}
}
