//This class seems correct!
public class Person {
	private String name;
	private boolean hasDriverLicense;
	private int age;
	private int height;
	
	public Person(String name, boolean hasDriverLicense, int age, int height) {
		this.name = name;
		this.hasDriverLicense = hasDriverLicense;
		this.age = age;
		this.height = height;
	}
	
	public String getName() {
		return name;
	}
	
	public boolean hasDriverLicense() {
		return hasDriverLicense;
	}
	
	public int getAge() {
		return age;
	}
	
	public int getHeight() {
		return height;
	}
	
	public Person clone() {//Not sure about this.
		return new Person(name, hasDriverLicense, age, height);
	}
	
	public boolean equals(Object obj) {
		if(obj == null) {return false;}
		if(this == obj) {return true;}
		if(obj instanceof Person) {
			Person otherP = (Person)obj;
			if(this.getName().equals(otherP.getName())) {
				if(this.hasDriverLicense() == otherP.hasDriverLicense()) {
					if(this.getAge() == otherP.getAge()) {
						if(this.getHeight() == otherP.getHeight()) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	public String toString() {
		if(hasDriverLicense()) {
			return String.format("Person [name= %10s | age= %02d | height= %02d | has license]", name, age, height);
		}
		else {
			return String.format("Person [name= %10s | age= %02d | height= %02d | no license]", name, age, height);
		}
	}

}
