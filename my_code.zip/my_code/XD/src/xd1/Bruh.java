package xd1;

import java.awt.datatransfer.SystemFlavorMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Bruh {
	
	public static boolean isMinHeap(int [] arr){
		
		int i = 0;
		
		while(i < arr.length) {
			
			int left = (2 * i) + 1;
			
			int right = (2 * i) + 2;
			
			if(left < arr.length && right < arr.length) {
				
				if(arr[i] > arr[left] || arr[i] > arr[right]) {
					
					return false;
				}
			}
			
			if(left < arr.length) {
				
				if(arr[i] > arr[left]) {
					
					return false;
				}
			}
			
			if(right < arr.length) {
				
				if(arr[i] > arr[right]) {
					
					return false;
				}
			}
			
			i++;
		}
		
		return true;
    }

	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		String [] input = scnr.nextLine().split(" ");
		
		System.out.println(Arrays.toString(input));
		
		int [] arr = new int [input.length];
		
		for(int i = 0; i < arr.length; i++) {
			
			arr[i] = Integer.parseInt(input[i]);
			
			System.out.println(arr[i]);
		}
		
		System.out.println(isMinHeap(arr));
		

	}

}
