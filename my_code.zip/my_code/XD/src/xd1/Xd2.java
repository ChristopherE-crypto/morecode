package xd1;

public class Xd2 {

	public static void main(String[] args) {
		

	}

}
