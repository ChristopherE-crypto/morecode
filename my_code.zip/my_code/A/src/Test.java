import java.util.Scanner;
public class Test {
	
	public static void main(String [] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		Human pepe = new Human();
		Human joseph = new Human("Joseph", 16, "Male", 1.79, 140.0, "Hispanic", "Black", "Brown");
		
		//Cellphone phone = new Cellphone("Apple", "Iphone 11");
		//phone.turnOn();
		//phone.addFriend(pepe);
		//phone.call();
		//phone.turnOff();
		
		System.out.println("Welcome to the character creation menu\n Please enter the name of your character: ");
		String name = scnr.next();
		pepe.setName(name);
		
		System.out.println("Enter the age for your character: ");
		int age = scnr.nextInt();
		pepe.setAge(age);
		
		System.out.println("Enter your character's sex: ");
		String sex = scnr.next();
		pepe.setSex(sex);
		
		System.out.println("Enter your character's height: ");
		double height = scnr.nextDouble();
		pepe.setHeight(height);
		
		System.out.println("Enter your character's weight: ");
		double weight = scnr.nextDouble();
		pepe.setWeight(weight);
		
		System.out.println("Enter your character's race: ");
		String race = scnr.next();
		pepe.setRace(race);
		
		System.out.println("Enter your character's hair color: ");
		String hairColor = scnr.next();
		pepe.setHairColor(hairColor);
		
		System.out.println("Enter your character's eye color: ");
		String eyeColor = scnr.next();
		pepe.setEyeColor(eyeColor);
		
		
		
		pepe.printHumanDetails();
		
		
	}

}
