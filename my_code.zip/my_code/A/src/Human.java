
public class Human{
	
	private String name;
	private int age;
	private String sex;
	private double height;
	private double weight;
	private String race;
	private String hairColor;
	private String eyeColor;
	
	public Human() {
		name = "Null";
		age = 0;
		sex = "Null";
		height = 0;
		weight = 0;
		race = "Null";
		hairColor = "Null";
		eyeColor = "Null";
	}
	
	public Human(String name, int age, String sex, double height, double weight, String race, String hairColor, String eyeColor) {
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.height = height;
		this.weight = weight;
		this.race = race;
		this.hairColor = hairColor;
		this.eyeColor = eyeColor;
	}
	
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
	
	public String getSex() {
		return sex;
	}
	
	public double getHeight() {
		return height;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public String getRace() {
		return race;
	}
	
	public String getHairColor() {
		return hairColor;
	}
	
	public String getEyeColor() {
		return eyeColor;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public void setSex(String sex) {
		this.sex = sex;
	}
	
	public void setHeight(double height) {
		this.height = height;
	}
	
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	public void setRace(String race) {
		this.race = race;
	}
	
	public void setHairColor(String hairColor) {
		this.hairColor = hairColor;
	}
	
	public void setEyeColor(String eyeColor) {
		this.eyeColor = eyeColor;
	}
	
	public void greeting() {
		System.out.println("Hello, my name is " + getName() + ". Nice to meet you!");
	}
	
	
	public void printHumanDetails() {
		System.out.println("Name: " + name + "\nAge: " + age + "\nSex: " + sex + "\nHeight: " + height + " cm\nWeight: " + weight + " lbs\nRace: " + race + "\nHair Color: " + hairColor + "\nEye Color: " + eyeColor);
	}

}
