import java.util.Scanner;
public class A {
	
	public static void main(String [] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("This program combine two words that are of the same length");
				
		System.out.println("Enter a word: ");
		String word1 = scnr.next();
		
		System.out.println("Enter another word: ");
		String word2 = scnr.next();
		
		for(int i = 0; i < word1.length(); i++) {
			if(word1.charAt(i) % 2 == 0) {
				word1 = word1.replace(word1.charAt(i), word2.charAt(i));
			}
		}
		
		System.out.println("Here's your new word: " + word1);
	}

}
