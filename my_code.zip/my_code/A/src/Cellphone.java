import java.util.ArrayList;
import java.util.Scanner;
public class Cellphone {
	
	private String brand;
	private String model;
	private ArrayList <Human> friends = new ArrayList <Human>();
	private boolean isOn;
	Scanner scnr = new Scanner(System.in);
	
	public Cellphone(String brand, String model) {
		this.brand = brand;
		this.model = model;
	}
	
	public void turnOn() {
		isOn = true;
		System.out.println("The cellphone is on.");
	}
	
	public void turnOff() {
		isOn = false;
		System.out.println("The cellphone is off");
	}
	
	public void addFriend(Human friend) {
		
		if(isOn == true) {
			friends.add(friend);
			System.out.println(" A new friend has been added to your friend list.");
		}
		else {
			System.out.println("Your cellphone is off. Turn it on.");
		}
		
	}
	
	public void call() {
		
		if(isOn == true) {
			System.out.println("Type a number (Starting from 0) to select a friend: ");
			friends.toString();
			int choice = scnr.nextInt();
			
			for(int i = 0; i < friends.size(); i++) {
				if(choice == i) {
					System.out.println("You are calling :" + friends.get(i).getName());
				}
				else {
					System.out.println("Wrong number.");
				}
			}
		}
		else {
			System.out.println("Your cellphone is off. Turn it on.");
		}
	}

}
