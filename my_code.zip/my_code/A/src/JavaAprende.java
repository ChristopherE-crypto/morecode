
public class JavaAprende {
	
	public static void main(String [] args) {
		
		
	}

}
