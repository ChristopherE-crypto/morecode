import java.util.Stack;

class Vertex {
	
	public String name;
	public boolean wasVisited;
	
	public Vertex(String name) {
		
		this.name = name;
		this.wasVisited = false;
	}
	
}

class Graph {
	
	private final int MAX_VERTEX = 59;
	private Vertex vertexList[];
	private int adjMat[][];
	private int nVerts;
	private Stack<Integer> s;
	
	public Graph() {
		
		vertexList = new Vertex[MAX_VERTEX];
		adjMat = new int[MAX_VERTEX][MAX_VERTEX];
		nVerts = 0;
		s = new Stack<Integer>();
	}
	
	public void addVertex(String name) {
		
		if(nVerts <= 9) {
		
			vertexList[nVerts++] = new Vertex(name);
			
		}
		
	}
	
	public void addEdge(int start , int end) {
		
		adjMat[start][end] = 1;
		adjMat[end][start] = 1;
	}
	
	public void displayVertex(int v) {
		
		System.out.print(vertexList[v].name);
	}
	
	public int getAdjUnvisitedVertex(int v) {
		
		for(int i = 0; i < nVerts; i++) {
			
			if(adjMat[v][i] == 1 && vertexList[i].wasVisited == false) {
				
				return i;
			}
		}
		
		return -1;
	}
	
	public void mst() {
		
		vertexList[0].wasVisited = true;
		s.push(0);
		
		while(!s.isEmpty()) {
			
			int current = s.peek();
			int v = getAdjUnvisitedVertex(current);
			
			if(v == -1) {
				
				s.pop();
			}
			else {
				
				vertexList[v].wasVisited = true;
				displayVertex(current);
				System.out.print("<->");
				displayVertex(v);
				System.out.println();
				s.push(v);
			}
		}
	}
}

public class BestComp {
	
	public static void main(String [] args) {
		
		Graph champs = new Graph();
		
		String [] champions = {"Akali" , "Blitzcrank" , "Braum" , "Caitlyn" ,
		          "Camille" , "Chogath" , "Darius" , "Dr Mundo" ,
		          "Ekko" , "Ezreal" , "Fiora" , "Galio" , "Gangplank" ,
		          "Garen" , "Graves" , "Heimerdinger" , "Illaoi" ,
		          "Janna" , "Jayce" , "Jhin" , "Jinx" , "Kaisa" , 
		          "Kassadin" , "Katarina" , "Kogmaw" , "Leona" ,
		          "Lissandra" , "Lulu" , "Lux" , "Malzahar" ,
		          "Miss Fortune" , "Orianna" , "Poppy" , "Quinn" ,
		          "Samira" , "Seraphine" , "Shaco" , "Singed" ,
		          "Sion" , "Swain" , "Tamhkench" , "Talon" , "Taric" ,
		          "Tristana" , "Trundle" , "Twisted Fate" , "Twitch" ,
		          "Urgot" , "Veigar" , "Vex" , "Vi" , "Viktor" ,
		          "Warwick" , "Yone" , "Yuumi" , "Zac" , "Ziggs" ,
		          "Zilean" , "Zyra"};
		
		for(int i = 0; i < champions.length; i++) {
			
			champs.addVertex(champions[i]);
		}
		
		// Academy
		
		champs.addEdge(13, 14);
		champs.addEdge(13, 23);
		champs.addEdge(13, 25);
		champs.addEdge(13, 28);
		champs.addEdge(13, 53);
		champs.addEdge(13, 54);
		
		champs.addEdge(14, 23);
		champs.addEdge(14, 25);
		champs.addEdge(14, 28);
		champs.addEdge(14, 53);
		champs.addEdge(14, 54);
		
		champs.addEdge(23, 25);
		champs.addEdge(23, 28);
		champs.addEdge(23, 53);
		champs.addEdge(23, 54);
		
		champs.addEdge(25, 28);
		champs.addEdge(25, 53);
		champs.addEdge(25, 54);
		
		champs.addEdge(28, 53);
		champs.addEdge(28, 54);
		
		champs.addEdge(53, 54);
		
		// Chemtech
		
		champs.addEdge(7, 26);
		champs.addEdge(7, 37);
		champs.addEdge(7, 46);
		champs.addEdge(7, 47);
		champs.addEdge(7, 51);
		champs.addEdge(7, 52);
		champs.addEdge(7, 55);
		
		champs.addEdge(26, 37);
		champs.addEdge(26, 46);
		champs.addEdge(26, 47);
		champs.addEdge(26, 51);
		champs.addEdge(26, 52);
		champs.addEdge(26, 55);
		
		champs.addEdge(37, 46);
		champs.addEdge(37, 47);
		champs.addEdge(37, 51);
		champs.addEdge(37, 52);
		champs.addEdge(37, 55);
		
		champs.addEdge(46, 47);
		champs.addEdge(46, 51);
		champs.addEdge(46, 52);
		champs.addEdge(46, 55);
		
		champs.addEdge(47, 51);
		champs.addEdge(47, 52);
		champs.addEdge(47, 55);
		
		champs.addEdge(51, 52);
		champs.addEdge(51, 55);
		
		champs.addEdge(52, 55);
		
		// Clockwork
		
		champs.addEdge(4, 19);
		champs.addEdge(4, 31);
		champs.addEdge(4, 57);
		
		champs.addEdge(19, 31);
		champs.addEdge(19, 57);
		
		champs.addEdge(31, 57);
		
		// Enforcer
		
		champs.addEdge(3, 10);
		champs.addEdge(3, 18);
		champs.addEdge(3, 50);
		
		champs.addEdge(10, 18);
		champs.addEdge(10, 50);
		
		champs.addEdge(18, 50);
		
		// Imperial
		
		champs.addEdge(34, 38);
		champs.addEdge(34, 39);
		champs.addEdge(34, 41);
		
		champs.addEdge(38, 39);
		champs.addEdge(38, 41);
		
		champs.addEdge(39, 41);
		
		// Mercenary
		
		champs.addEdge(12, 16);
		champs.addEdge(12, 30);
		champs.addEdge(12, 33);
		champs.addEdge(12, 40);
		
		champs.addEdge(16, 30);
		champs.addEdge(16, 33);
		champs.addEdge(16, 40);
		
		champs.addEdge(30, 33);
		champs.addEdge(30, 40);
		
		champs.addEdge(33, 40);
		
		// Mutant
		
		champs.addEdge(5, 7);
		champs.addEdge(5, 21);
		champs.addEdge(5, 22);
		champs.addEdge(5, 24);
		champs.addEdge(5, 29);
		
		champs.addEdge(7, 21);
		champs.addEdge(7, 22);
		champs.addEdge(7, 24);
		champs.addEdge(7, 29);
		
		champs.addEdge(21, 22);
		champs.addEdge(21, 24);
		champs.addEdge(21, 29);
		
		champs.addEdge(22, 24);
		champs.addEdge(22, 29);
		
		champs.addEdge(24, 29);
		
		// Scrap
		
		champs.addEdge(1, 8);
		champs.addEdge(1, 9);
		champs.addEdge(1, 17);
		champs.addEdge(1, 20);
		champs.addEdge(1, 44);
		champs.addEdge(1, 56);
		
		champs.addEdge(8, 9);
		champs.addEdge(8, 17);
		champs.addEdge(8, 20);
		champs.addEdge(8, 44);
		champs.addEdge(8, 56);
		
		champs.addEdge(9, 17);
		champs.addEdge(9, 20);
		champs.addEdge(9, 44);
		champs.addEdge(9, 56);
		
		champs.addEdge(17, 20);
		champs.addEdge(17, 44);
		champs.addEdge(17, 56);
		
		champs.addEdge(20, 44);
		champs.addEdge(20, 56);
		
		champs.addEdge(44, 56);
		
		// Sister
		
		champs.addEdge(20, 50);
		
		// Socialite
		
		champs.addEdge(11, 35);
		champs.addEdge(11, 42);
		
		champs.addEdge(35, 42);
		
		// Syndicate
		
		champs.addEdge(0, 2);
		champs.addEdge(0, 6);
		champs.addEdge(0, 36);
		champs.addEdge(0, 45);
		champs.addEdge(0, 58);
		
		champs.addEdge(2, 6);
		champs.addEdge(2, 36);
		champs.addEdge(2, 45);
		champs.addEdge(2, 58);
		
		champs.addEdge(6, 36);
		champs.addEdge(6, 45);
		champs.addEdge(6, 58);
		
		champs.addEdge(36, 45);
		champs.addEdge(36, 58);
		
		champs.addEdge(45, 58);
		
		// Yordles
		
		champs.addEdge(15, 27);
		champs.addEdge(15, 32);
		champs.addEdge(15, 43);
		champs.addEdge(15, 49);
		champs.addEdge(15, 56);
		
		champs.addEdge(27, 32);
		champs.addEdge(27, 43);
		champs.addEdge(27, 49);
		champs.addEdge(27, 56);
		
		champs.addEdge(32, 43);
		champs.addEdge(32, 49);
		champs.addEdge(32, 56);
		
		champs.addEdge(43, 49);
		champs.addEdge(43, 56);
		
		champs.addEdge(49, 56);
		
		
		// Arcanists
		
		champs.addEdge(28, 29);
		champs.addEdge(28, 39);
		champs.addEdge(28, 45);
		champs.addEdge(28, 49);
		champs.addEdge(28, 51);
		champs.addEdge(28, 56);
		
		champs.addEdge(29, 39);
		champs.addEdge(29, 45);
		champs.addEdge(29, 49);
		champs.addEdge(29, 51);
		champs.addEdge(29, 56);
		
		champs.addEdge(39, 45);
		champs.addEdge(39, 49);
		champs.addEdge(39, 51);
		champs.addEdge(39, 56);
		
		champs.addEdge(45, 49);
		champs.addEdge(45, 51);
		champs.addEdge(45, 56);
		
		champs.addEdge(49, 51);
		champs.addEdge(49, 56);
		
		champs.addEdge(51, 56);
		
		
		// Assassins
		
		champs.addEdge(0, 8);
		champs.addEdge(0, 23);
		champs.addEdge(0, 36);
		champs.addEdge(0, 41);
		champs.addEdge(0, 46);
		
		champs.addEdge(8, 23);
		champs.addEdge(8, 36);
		champs.addEdge(8, 41);
		champs.addEdge(8, 46);
		
		champs.addEdge(23, 36);
		champs.addEdge(23, 41);
		champs.addEdge(23, 46);
		
		champs.addEdge(36, 41);
		champs.addEdge(36, 46);
		
		champs.addEdge(41, 46);
		
		// Bodyguards
		
		champs.addEdge(1, 2);
		champs.addEdge(1, 6);
		champs.addEdge(1, 11);
		champs.addEdge(1, 25);
		champs.addEdge(1, 32);
		
		champs.addEdge(2, 6);
		champs.addEdge(2, 11);
		champs.addEdge(2, 25);
		champs.addEdge(2, 32);
		
		champs.addEdge(6, 11);
		champs.addEdge(6, 25);
		champs.addEdge(6, 32);
		
		champs.addEdge(11, 25);
		champs.addEdge(11, 32);
		
		champs.addEdge(25, 32);
		
		// Bruisers
		
		champs.addEdge(5, 7);
		champs.addEdge(5, 16);
		champs.addEdge(5, 40);
		champs.addEdge(5, 44);
		champs.addEdge(5, 50);
		champs.addEdge(5, 55);
		
		champs.addEdge(7, 16);
		champs.addEdge(7, 40);
		champs.addEdge(7, 44);
		champs.addEdge(7, 50);
		champs.addEdge(7, 55);
		
		champs.addEdge(16, 40);
		champs.addEdge(16, 44);
		champs.addEdge(16, 50);
		champs.addEdge(16, 55);
		
		champs.addEdge(40, 44);
		champs.addEdge(40, 50);
		champs.addEdge(40, 55);
		
		champs.addEdge(44, 50);
		champs.addEdge(44, 55);
		
		champs.addEdge(50, 55);
		
		// Challengers
		
		champs.addEdge(4, 10);
		champs.addEdge(4, 21);
		champs.addEdge(4, 33);
		champs.addEdge(4, 34);
		champs.addEdge(4, 52);
		champs.addEdge(4, 53);
		
		champs.addEdge(10, 21);
		champs.addEdge(10, 33);
		champs.addEdge(10, 34);
		champs.addEdge(10, 52);
		champs.addEdge(10, 53);
		
		champs.addEdge(21, 33);
		champs.addEdge(21, 34);
		champs.addEdge(21, 52);
		champs.addEdge(21, 53);
		
		champs.addEdge(33, 34);
		champs.addEdge(33, 52);
		champs.addEdge(33, 53);
		
		champs.addEdge(34, 52);
		champs.addEdge(34, 53);
		
		champs.addEdge(52, 53);
		
		// Colossus
		
		champs.addEdge(5, 11);
		champs.addEdge(5, 38);
		
		champs.addEdge(11, 38);
		
		// Enchanters
		
		champs.addEdge(17, 27);
		champs.addEdge(17, 31);
		champs.addEdge(17, 42);
		
		champs.addEdge(27, 31);
		champs.addEdge(27, 42);
		
		champs.addEdge(31, 42);
		
		// Innovators
		
		champs.addEdge(9, 15);
		champs.addEdge(9, 18);
		champs.addEdge(9, 35);
		champs.addEdge(9, 37);
		champs.addEdge(9, 57);
		
		champs.addEdge(15, 18);
		champs.addEdge(15, 35);
		champs.addEdge(15, 37);
		champs.addEdge(15, 57);
		
		champs.addEdge(18, 35);
		champs.addEdge(18, 37);
		champs.addEdge(18, 57);
		
		champs.addEdge(35, 37);
		champs.addEdge(35, 57);
		
		champs.addEdge(37, 57);
		
		// Protectors
		
		champs.addEdge(1, 13);
		champs.addEdge(1, 22);
		champs.addEdge(1, 38);
		
		champs.addEdge(13, 22);
		champs.addEdge(13, 38);
		
		champs.addEdge(22, 38);
		
		// Scholars
		
		champs.addEdge(15, 17);
		champs.addEdge(15, 26);
		champs.addEdge(15, 54);
		champs.addEdge(15, 58);
		
		champs.addEdge(17, 26);
		champs.addEdge(17, 54);
		champs.addEdge(17, 58);
		
		champs.addEdge(26, 54);
		champs.addEdge(26, 58);
		
		champs.addEdge(54, 58);
		
		// Snipers
		
		champs.addEdge(3, 19);
		champs.addEdge(3, 24);
		champs.addEdge(3, 30);
		champs.addEdge(3, 43);
		
		champs.addEdge(19, 24);
		champs.addEdge(19, 30);
		champs.addEdge(19, 43);
		
		champs.addEdge(24, 30);
		champs.addEdge(24, 43);
		
		champs.addEdge(30, 43);
		
		// Twinshots
		
		champs.addEdge(12, 14);
		champs.addEdge(12, 20);
		champs.addEdge(12, 24);
		champs.addEdge(12, 47);
		
		champs.addEdge(14, 20);
		champs.addEdge(14, 24);
		champs.addEdge(14, 47);
		
		champs.addEdge(20, 24);
		champs.addEdge(20, 47);
		
		champs.addEdge(24, 47);
		
		System.out.println("MST :");
		champs.mst();
		
		
	}
	
	

}
