package chp14_GUI1;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MyFirstJP extends JPanel{
	
	private JLabel jl1;
	private JButton jbUp;
	private int counter = 0;//Keep track of counters
	
	public MyFirstJP() {
		setLayout(new GridLayout(2, 1));
		jl1 = new JLabel();
		jl1.setText("Hello");
		jl1.setFont(new Font(Font.SERIF, Font.ITALIC, 40));
		
		//Buttons
		jbUp = new JButton(" + ");
		jbUp.setForeground(Color.GREEN);
		jbUp.setFont(new Font(Font.SERIF, Font.ITALIC, 30));
		
		//Add listeners
		
		
		//Add components to container
		add(jl1);
		add(jbUp);
	}

}
