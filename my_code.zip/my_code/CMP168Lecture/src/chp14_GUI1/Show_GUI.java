package chp14_GUI1;

public class Show_GUI {
	
	public static void main(String [] args) {
		
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				MyFirstJFrame gui = new MyFirstJFrame();
			}
		});
		
	}

}
