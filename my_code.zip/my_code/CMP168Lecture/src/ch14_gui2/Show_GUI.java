package ch14_gui2;

public class Show_GUI {

	public static void main(String[] args) {
		
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				TicTacToe_JF TTT = new TicTacToe_JF();
			}
		
		});
		
		

	}

}
