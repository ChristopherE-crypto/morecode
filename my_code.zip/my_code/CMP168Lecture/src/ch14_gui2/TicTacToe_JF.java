package ch14_gui2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class TicTacToe_JF extends JFrame{
	
	private JPanel jpMain;
	private TicTacToeBoard jpTTTBoard;
	private ScoreBoard jpScoreBoard;
	
	private Player currPlayer;
	private Player player1, player2;
	
	public TicTacToe_JF() {
		
		player1 = new Player('X',"Pedro");
		player2 = new Player('O', "Max");
		currPlayer = player1;
		jpMain = new JPanel();
		jpMain.setLayout(new BorderLayout());
		
		jpTTTBoard = new TicTacToeBoard();//instance of our board JPanel
		jpScoreBoard = new ScoreBoard();
		
		jpMain.add(jpTTTBoard, BorderLayout.CENTER);
		jpMain.add(jpScoreBoard, BorderLayout.NORTH);
		
		add(jpMain);
		setSize(500, 500);
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}
	
	private class TicTacToeBoard extends JPanel implements BoardGameInterface, ActionListener{
		
		private JButton [][] board; //3x3
		private static final int NUM_ROWS = 3;
		private static final int NUM_COLS = 3;
		private static final int NUM_MATCHES_NEEDED_WIN = 3;
		
		public TicTacToeBoard() {
			setLayout(new GridLayout(NUM_ROWS, NUM_COLS));
			displayBoard();//board gets initialized and presented to the user
		}
		
		
		
		@Override
		public void populateBoard() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void clearBoard() {
			for(int row = 0; row < board.length; row++) {
				for(int col = 0; col < board[row].length; col++) {
					board[row][col].setText(String.valueOf(BoardGameInterface.EMPTY_CELL));
					board[row][col].setEnabled(true);
				}
			}
			
		}

		@Override
		public void displayBoard() {
			board = new JButton[NUM_ROWS][NUM_COLS];//initialized
			for(int row = 0; row < board.length; row++) {
				for(int col = 0; col < board[row].length; col++) {
					board[row][col] = new JButton();
					board[row][col].addActionListener(this);//add action listener
					//set font, set foreground
					Font bigFont = new Font(Font.SANS_SERIF, Font.BOLD, 36);
					board[row][col].setForeground(Color.BLUE);
					board[row][col].setFont(bigFont);
					board[row][col].setEnabled(true);//Ensures it's clickable
					this.add(board[row][col]);//Add to the TicTacToeBoard JPanel
				}
			}
			
		}

		@Override
		public void changeTurn() {
			if(currPlayer.equals(player1)) {
				currPlayer = player2;
			}
			else {
				currPlayer = player1;
			}
			
		}

		@Override
		public void placeMarker(int rowIndex, int colIndex) {
			board[rowIndex][colIndex].setText(currPlayer.getPlayerSymbolAsString());
			//Check for valid index
		}
		
		public void placeMarker(JButton buttonClicked) {
			//if(buttonClicked.getText().trim().equalsIgnoreCase(""))
			if(!buttonClicked.getText().equalsIgnoreCase(player1.getPlayerSymbolAsString().trim()) && !buttonClicked.getText().equalsIgnoreCase(player2.getPlayerSymbolAsString().trim())) {
				buttonClicked.setText(currPlayer.getPlayerSymbolAsString());
			}
		}

		@Override
		public boolean isWinner() {
			
			return false;
		}

		@Override
		public boolean isDraw() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isEmpty() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isFull() {
			for(int row = 0; row < board.length; row++) {
				for(int col = 0; col < board[row].length; col++) {
					if(board[row][col].getText().trim().equalsIgnoreCase("")) {
						return false;
					}
				}
			}
			return true;
		}



		@Override
		public void actionPerformed(ActionEvent e) {
			JButton btnClicked = (JButton) e.getSource();//find out which button trigger the event
			placeMarker(btnClicked);
			
			
			
			
			changeTurn();
		}
		
	}//End of TicTacToeBoard nested inner class
	
	private class ScoreBoard extends JPanel{
		
		public ScoreBoard(){
			setLayout(new BorderLayout());
		}
		
	}//End of ScoreBoard nested inner class

}
