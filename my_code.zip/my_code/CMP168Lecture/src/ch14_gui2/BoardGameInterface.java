package ch14_gui2;

import javax.swing.JButton;

public interface BoardGameInterface {
	
	char PLAYER_X = 'X';
	char PLAYER_O = 'O';
	char EMPTY_CELL = ' ';
	
	void populateBoard();
	void clearBoard();
	void displayBoard();
	void changeTurn();
	void placeMarker(int rowIndex, int colIndex);
	void placeMarker(JButton jb);
	boolean isWinner();
	boolean isDraw();
	boolean isEmpty();
	boolean isFull();

}
