package ch14_gui2;

public class Player implements Comparable <Player>{
	
	private char playerSymbol;
	private String playerName;
	private int numGames, numWins, numLosses;
	
	public Player() {
		playerSymbol = '*';
		playerName = "Play Doe";
		numGames = 0;
		numWins = 0;
		numLosses = 0;
	}
	
	public Player(char symbol, String name) {
		playerSymbol = symbol;
		playerName = name;
		numGames = 0;
		numWins = 0;
		numLosses = 0;
	}
	
	protected void addNumWins() {
		numWins++;
		numGames++;
	}
	
	protected void addNumLosses() {
		numLosses++;
		numGames++;
	}
	
	protected void addDraw() {
		numGames++;
	}
	
	public int getNumGames() {
		return numGames;
	}
	
	public int getNumWins() {
		return numWins;
	}
	
	public int getNumLosses() {
		return numLosses;
	}
	
	public int getNumDraws() {
		return (numGames - (numWins + numLosses));
	}
	
	public String getPlayerName() {
		return playerName;
	}
	
	public char getPlayerSymbol() {
		return playerSymbol;
	}
	public String getPlayerSymbolAsString() {
		return playerSymbol + "";
	}
	
	@Override
	public String toString() {
		return String.format("Player [ name = %20s, symbol = %2c, number of games = %02d, wins = %02d, losses = %02d, draws = %02d", playerName, playerSymbol, numGames, numWins, numLosses, getNumDraws());
	}
	
	@Override
	public boolean equals(Object o) {
		if(o == null) {return false;}
		if(this == o) {return true;}
		if(o instanceof Player) {
			Player otherP = (Player) o;
			if(this.playerName.equalsIgnoreCase(otherP.playerName)) {
				if(this.playerSymbol == otherP.playerSymbol) {
					if(this.numGames == otherP.numGames) {
						if(this.numWins == otherP.numWins) {
							if(this.numLosses == otherP.numLosses) {
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public int compareTo(Player otherP) {
		if(otherP != null) {
			if(this.numWins > otherP.numWins) {
				return 1;
			}
			else if(this.numWins < otherP.numWins) {
				return -1;
			}
		}
		return 0;
	}

}
