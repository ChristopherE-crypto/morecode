package chapter9;

public class Dog {
	private String name;
	private double weight;
	private double height;
	private boolean isVaccinated;
	private int ageInDogYears;
	private static int numDogs = 0; //numOfDogs counter shared for all instances of the Dog class
	private int dogNumber;//include dogNumber soon
	
	public Dog(){//default constructor
		numDogs++; //increment the numDogs
		dogNumber = numDogs;//assign the unique number to dogNumber
		name = "doggie Doe";
		weight = 0;
		height = 0;
		isVaccinated = false;
		ageInDogYears = 0;
	}
	public Dog(String name){
		this(); // call default constructor
		this.name = name;
	}
	public Dog(String name, double weight, double height){
		this(); // call default constructor
		this.name = name;
		this.weight = isValid(weight) ? weight : 0;
		this.height = isValid(height) ? height : 0;
	}
	public Dog(String name, double weight, double height, boolean isVaccinated,int ageInDogYears){//fully overloaded constructor
		numDogs++; //increment the numDogs
		dogNumber = numDogs;//assign the unique number to dogNumber
		this.weight = isValid(weight) ? weight : 0;
		this.height = isValid(height) ? height : 0;
		this.isVaccinated = isVaccinated;
		this.ageInDogYears = isValid(ageInDogYears) ? ageInDogYears : 0;
		
//		if(isValid(ageInDogYears)){				//equivalent to the shorthand if( )? : statement
//			this.ageInDogYears = ageInDogYears;
//		}
//		else{
//			this.ageInDogYears = 0;
//		}
		
	}
	
	//accessor also known as getter methods 
	public String getName(){
		return name;
	}
	public double getWeight(){
		return weight;
	}
	public double getHeight(){
		return height;
	}
	public boolean isVaccinated(){
		return isVaccinated;
	}
	public int getAgeInDogYears(){
		return ageInDogYears;
	}
	public int getDogNumber(){//no setter only getter to provide control
		return dogNumber;
	}
	public static int getNumDogs(){//no setter only getter to provide control
		return numDogs;
	}
	
	
	//mutator also known as setter methods
	public void setName(String name){
		this.name = name;
	}
	public void setWeight(double weight){
		if(isValid(weight)){
			this.weight = weight;
		}
	}
	public void setHeight(double height){
		if(isValid(height)){
				this.height = height;
		}
	}

	public void setIsVaccinated(boolean isVacc){
		isVaccinated = isVacc;
	}
	public void setAgeInDogYears(int age){
		if(isValid(age)){
			ageInDogYears = age;
		}
	}

	protected boolean isValid(double val){
		return (val >=0);
	}
	protected boolean isValid(int val){
		return (val >=0);
	}
	
	@Override
	public String toString(){
		String s = "Dog [name=" +name+ ", weight=" + weight + ", height=" + height+", age="+ageInDogYears; 
			s+= (isVaccinated) ? "is vaccinated" : "is not vaccinated";
			s+= ", dog number=" + dogNumber ;
			s+=	"]";
		return s;
	}
	
	@Override
	public boolean equals(Object obj){
		if(obj == null){ return false; }
		if(this == obj){ return true; }
		if(obj instanceof Dog){ // check if the passed in obj is indeed a Dog
			Dog otherD = (Dog)obj;//Cast
			if(ageInDogYears == otherD.ageInDogYears){
				if(name.equalsIgnoreCase(otherD.name)){
					if( Math.abs(weight - otherD.weight) < 0.5){//accuracy range
						if( Math.abs(height - otherD.height) < 0.5){//accuracy range
							if(isVaccinated == otherD.isVaccinated){
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}

}
