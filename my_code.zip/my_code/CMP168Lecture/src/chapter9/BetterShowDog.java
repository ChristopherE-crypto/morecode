package chapter9;

public class BetterShowDog extends ShowDog{
	private Trick [] tricks;
	private int numTricks;
	public static final int MAX_TRICKS = 5;
	
	public BetterShowDog(){
		super("Better Show Dog Doe");
		tricks = new Trick[MAX_TRICKS];
		numTricks = 0;
	}

	public BetterShowDog(String name){
		this();
		setName(name);
//		super(name);
//		tricks = new Trick[MAX_TRICKS];
//		numTricks = 0;
	}
	public BetterShowDog(int numTrophies, String bestFeature){
		this();//super(numTrophies,bestFeature);
		super.setNumTrophies(numTrophies);
		setBestFeature(bestFeature);
	}
	
	
	@Override
	public String toString(){
		return super.toString()+"\nBetterShowDog ["+
				"number of Tricks="+numTricks+" :\n"+
				getTricksAsString()+
				"]";
	}
	
	//getSkillLevelForTrickByName ... return int
	
	public String getTricksAsString(){
		String s = "Tricks";
		for(int i=0; i<numTricks; i++){
			s += tricks[i].toString();
		}
		return s+"\n";
	}
	
	public int getNumTricks(){
		return numTricks;
	}
	
	public boolean addTrick(String trickName, int skillLevel){
		if(numTricks < MAX_TRICKS){
			if(trickName != null  && isValid(skillLevel)){
				for(int i=0; i<numTricks; i++){
					if(tricks[i]!=null && trickName.equalsIgnoreCase(tricks[i].name)){//avoid duplicate names
						return false; //do not create and add the Trick
					}
				}//loop is done checking each location for duplicate names
				
				tricks[numTricks++] = new Trick(trickName,skillLevel);//add the Trick
				return true;
			}
			
			
		}
		return false;//no more tricks can be added or skillLevel was invalid
	}
	
	public boolean removeTrickByName(String trickName){
		for(int i=0; i<numTricks; i++){
			if(tricks[i].name.equalsIgnoreCase(trickName)){//found match
				//i=4 , j=4
				for(int j=i; j<numTricks-1; j++){//start at the index of the item that matches the name we're looking for
					tricks[j] = tricks[j+1];//shift from right to left
				}
				tricks[--numTricks]=null; //decrement then nullify
				return true;//removal successful
			}
		}
		return false;//not removed
	}

	/*
	 * We could also mark the Trick class as static
	 * since we do not need to directly access 
	 * any of the Outer class's member variables
	 * It is private so it is not accessible outside the Outer class
	 * 
	 * If it were protected it would be accessible outside the Outer class
	 * We will NOT make it protected so we can hide it within BetterShowDog
	 * 
	 * We will NOT make it static 
	 * because we DO NOT want to allow the creation of Trick objects 
	 * via the BetterShowDog.Trick syntax
	 * BetterShowDog.Trick t = new BetterShowDog.Trick(name, skillLevel);
	 * 
	 */

	private class Trick{
		private String name;
		private int skillLevel;
		
		public Trick(String name, int skillLevel){
			this.name = name;
			this.skillLevel = skillLevel;
		}
		@Override
		public String toString(){
			String s = "Trick[ name="+
					this.name+", skill level"+
					this.skillLevel+ "]\n";
			return s;
		}
		@Override
		public boolean equals(Object o){
			
			return false;
		}
	}//closing bracket for the class Trick

}
