package chapter9;

public class ShowDog extends Dog{
	private int numTrophies;
	private String bestFeature;
	
	public ShowDog(){
		super();
		super.setName("Show Dog Doe");
		numTrophies = 0;
		bestFeature = "unknown";
	}
	public ShowDog(String name){
		super();
		super.setName(name);
		numTrophies = 0;
		bestFeature = "unknown";
	}

	public ShowDog(int numTrophies, String bestFeature){
		super();
		super.setName("Show Dog Doe");
		this.numTrophies = isValid(numTrophies) ? numTrophies : 0;
		this.bestFeature = bestFeature;
		
	}
	
	public ShowDog(String name, double wt,double ht, boolean isVac, int age,int numTrophies, String bestFeature){
		super(name,wt,ht,isVac,age);
		this.numTrophies = isValid(numTrophies) ? numTrophies : 0;
//		if(isValid(numTrophies)){	//equivalent to the shorthand used above
//			this.numTrophies = numTrophies;
//		}
//		else{
//			this.numTrophies =0;
//		}
		this.bestFeature = bestFeature;
	}
	@Override
	public String toString(){
		String s = super.toString() + 
				"\nShowDog[ num trophies="+
				numTrophies+", best feature "+
				bestFeature;
		s+="]";
		return s;
	}
	
	//equals
	//if(obj instanceof ShowDog){ 
	//}
	@Override
	public boolean equals(Object obj){
		if(obj == null){ return false; }
		if(this == obj){ return true; }
		if(obj instanceof ShowDog){ // check if the passed in obj is indeed a Dog
			ShowDog otherSD = (ShowDog)obj;//Cast
			if(super.equals(otherSD)){//check equality using parent class's equals method
				if(numTrophies == otherSD.numTrophies){
					if(bestFeature.equalsIgnoreCase(otherSD.bestFeature)){
						return true;
					}
				}
			}
		}
		return false;
	}

	public void setNumTrophies(int n){
		numTrophies = isValid(n) ? n : 0;
		 
	}
	public void setBestFeature(String feature){
		bestFeature =feature;
	}
	
	public int getNumTrophies(){
		return numTrophies;
	}
	public String getBestFeature(){
		return bestFeature;
	}

}
