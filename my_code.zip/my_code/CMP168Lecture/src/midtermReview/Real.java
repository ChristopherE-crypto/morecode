package midtermReview;

public class Real extends Animal{
	
	public Real() {
		super();
	}
	
	public Real(String name, int numLegs, double weight, boolean hasTail) {
		super(numLegs, weight, name, hasTail);
	}
	
	public void speak(String s) {
		System.out.println(s);
	}
	
	public void greet() {
		System.out.println("I'm a real animal!");
	}
	
	public void sleep() {
		System.out.println("Come sleep with me... ZZZzzzZZZ");
	}
	
	public void eat(String s) {
		System.out.println("I really like eating " + s);
	}
	
	public void move() {
		System.out.println("Moves forward very fast...");
	}
	
	

}
