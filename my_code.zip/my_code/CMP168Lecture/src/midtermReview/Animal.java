package midtermReview;

import java.util.Arrays;

public class Animal implements Comparable <Animal>, Communicator, Behavior{
	private int numLegs;
	private double weight;
	private String name;
	private boolean hasTail;
	private int animalNumber;
	private String [] favoriteFoods;
	private int numFavoriteFood;
	private static int numOfAnimals;
	
	public Animal() {
		numLegs = 0;
		weight = 0.0;
		name = "Unknown";
		hasTail = false;
		animalNumber = ++numOfAnimals;
		favoriteFoods = new String [10];
	}
	
	public Animal(int numLegs, double weight, String name, boolean hasTail) {
		this.numLegs = numLegs;
		this.weight = weight;
		this.name = name;
		this.hasTail = hasTail;
		animalNumber = ++numOfAnimals;
		favoriteFoods = new String [10];
	}
	
	public void addFavoriteFood(String food) {
		if(food != null && numFavoriteFood < favoriteFoods.length) {
			favoriteFoods[numFavoriteFood] = food;
			numFavoriteFood++;
		}
	}
	
	public String [] getFavoriteFoods() {
		return favoriteFoods;
	}
	
	public String getFavoriteFoodsAsString() {
		String foods = Arrays.toString(favoriteFoods);
		return foods;
	}
	
	public void setNumLegs(int numLegs) {
		this.numLegs = numLegs;
	}
	
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setHasTail(boolean hasTail) {
		this.hasTail = hasTail;
	}
	
	public int getNumLegs() {
		return numLegs;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public String getName() {
		return name;
	}
	
	public boolean getHasTail() {
		return hasTail;
	}
	
	public int getAnimalNumber() {
		return animalNumber;
	}
	
	public static int getNumOfAnimals() {
		return numOfAnimals;
	}
	
	public String toString() {
		if(hasTail) {
			return String.format("Name: %20s| Number of Legs: %10d| Weight: %.2f| Has Tail| Animal Number: %10d| Favorite Foods: " + getFavoriteFoodsAsString(), name, numLegs, weight, animalNumber);
		}
		else {
			return String.format("Name: %20s| Number of Legs: %10d| Weight: %.2f| No Tail| Animal Number: %10d| Favorite Foods: " + getFavoriteFoodsAsString(), name, numLegs, weight, animalNumber);
		}
		
	}
	
	public boolean compareArrays(String [] arr1, String [] arr2) {
		for(int i = 0; i < arr1.length; i++) {
			if(arr1[i].equals(arr2[i])) {
				return true;
			}
		}
		return false;
	}

	@Override
	public int compareTo(Animal a) {
		if(this.weight > a.weight) {
			return 1;
		}
		else if(this.weight < a.weight) {
			return -1;
		}
		return 0;
	}
	
	public boolean equals(Animal a) {
		if(a == null) {return false;}
		if(this == a) {return true;}
		if(a instanceof Animal) {
			Animal otherA = (Animal)a;
			if(this.numLegs == otherA.numLegs) {
				if(this.name.equals(otherA.name)) {
					if(this.hasTail == otherA.hasTail) {
						if(compareArrays(this.favoriteFoods, otherA.favoriteFoods)) {
							if(Math.abs(this.weight - otherA.weight) < 0.25) {
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public void speak(String s) {
		System.out.println(s);
		
	}

	@Override
	public void greet() {
		System.out.println("Hi, I'm an animal!");
		
	}

	@Override
	public void sleep() {
		System.out.println("ZZZzzzZZZ... Sleeping... Don't bother me...");
		
	}

	@Override
	public void eat(String s) {
		System.out.println("I'm eating " + s);
		
	}

	@Override
	public void move() {
		System.out.println("Starts moving...");
		
	}

}
