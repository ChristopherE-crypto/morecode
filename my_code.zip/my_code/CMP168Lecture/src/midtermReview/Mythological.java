package midtermReview;

public class Mythological extends Animal{
	
	public Mythological() {
		super();
	}
	
	public Mythological(String name, int numLegs, double weight, boolean hasTail) {
		super(numLegs, weight, name, hasTail);
	}
	
	public void speak(String s) {
		System.out.println(s);
	}
	
	public void greet() {
		System.out.println("I'm a mythological animal!");
	}
	
	public void sleep() {
		System.out.println("DO NOT WAKE ME UP!...ZZZzzzZZZ");
	}
	
	public void eat(String s) {
		System.out.println("I devoured the " + s);
	}
	
	public void move() {
		System.out.println("Teleports behind you...");
	}

}
