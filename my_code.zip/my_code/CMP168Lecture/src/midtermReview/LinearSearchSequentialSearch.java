package midtermReview;

import java.util.Arrays;

public class LinearSearchSequentialSearch {
	
	public static int linearSearch(char [] arr, char target) {
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] == target) {
				return i;
			}
		}
		return -1;
	}
	
	public static void bubbleSort(char [] arr) {
		for(int i = 0; i < arr.length - 1; i++) {
			for(int j = 0; j < arr.length - i - 1; j++) {
				if(arr[j] > arr[j + 1]) {
					char temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}
			}
		}
	}
	
	public static void swap(char [] arr, int i, int j) {
		char temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
	
	public static void selectionSort(char [] arr) {
		for(int i = 0; i < arr.length; i++) {
			int min = i;
			
			for(int j = i + 1; j < arr.length; j++) {
				if(arr[j] < arr[min]) {
					min = j;
				}
			}
			swap(arr, i, min);
		}
	}

	public static void main(String[] args) {
		char [] arr = {'b', 'c', 'a', 'f', 'x', 'h'};
		
		System.out.println(linearSearch(arr, 'a'));
		
		//bubbleSort(arr);
		selectionSort(arr);
		
		System.out.println(Arrays.toString(arr));
	}

}
