package midtermReview;

public interface Behavior {
	
	void sleep();
	void eat(String s);
	void move();

}
