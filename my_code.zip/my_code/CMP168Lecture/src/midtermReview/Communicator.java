package midtermReview;

public interface Communicator {
	
	void speak(String s);
	void greet();

}
