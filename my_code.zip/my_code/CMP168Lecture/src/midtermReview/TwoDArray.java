package midtermReview;

public class TwoDArray {
	
	public static int sum(int [][] arr) {
		int sum = 0;
		for(int row = 0; row < arr.length; row++) {
			for(int col = 0; col < arr[row].length; col++) {
				sum = sum + arr[row][col];
			}
		}
		return sum;
	}

	public static void main(String[] args) {
		
		int [][] arr = new int [5][5];
		
		arr[0][0] = 30;
		arr[0][1] = 20;
		arr[4][3] = 10;
		
		System.out.println(sum(arr));
		

	}

}
