package midtermReview;

public class Driver {

	public static void main(String[] args) {
		Animal a = new Animal(4, 40.5, "Pepe", true);
		Animal b = new Animal(5, 30.6, "Xo", false);
		
		Real x = new Real("Zed", 3, 100.5, true);
		
		a.addFavoriteFood("Nuts");
		b.addFavoriteFood("Mango");
		
		System.out.println(a);
		System.out.println(b);
		
		System.out.println(a.compareTo(x));
		
		System.out.println(x.equals(b));
		
		x.addFavoriteFood("Apple");
		
		x.greet();
		x.speak("I'm real and really strong!");
		
		System.out.println(x);

	}

}
