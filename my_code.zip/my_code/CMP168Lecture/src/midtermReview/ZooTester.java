package midtermReview;

public class ZooTester {

	public static void main(String[] args) {
		Real pig = new Real("Pig", 4, 200.5, true);
			pig.addFavoriteFood("Carrot");
		Real wolf = new Real("Wolf", 4, 130.4, true);
			wolf.addFavoriteFood("Meat");
		Real dog = new Real("Dog", 4, 80.3, true);
			dog.addFavoriteFood("Cookies");
			
		Mythological yeeti = new Mythological("Yeeti", 2, 300.4, false);
			yeeti.addFavoriteFood("Rabbits");
		Mythological kraken = new Mythological("Kraken", 10, 10000, false);
			kraken.addFavoriteFood("Humans");
		Dragon dragon = new Dragon("Rex Lapis", 4, 500.4, true);
			dragon.addFavoriteFood("Birds");
		
		Animal [] animals = {pig, wolf, dog, yeeti, kraken, dragon};
		
		for(int i = 0; i < animals.length; i++) {
			System.out.println(animals[i]);
		}
		
		for(int i = 0; i < animals.length; i++) {
			animals[i].sleep();
		}
		
		System.out.println();

	}

}
