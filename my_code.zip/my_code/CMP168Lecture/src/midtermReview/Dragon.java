package midtermReview;

public class Dragon extends Mythological{
	
	public Dragon() {
		super();
	}
	
	public Dragon(String name, int numLegs, double weight, boolean hasTail) {
		super(name, numLegs, weight, hasTail);
	}
	
	public void speak(String s) {
		System.out.println(s);
	}
	
	public void greet() {
		System.out.println("I'm the great ancient dragon!");
	}
	
	public void sleep() {
		System.out.println("I do not have time to sleep...");
	}
	
	public void eat(String s) {
		System.out.println("The " + s + " was delicious, thank you.");
	}
	
	public void move() {
		System.out.println("Flies freely throught the skies...");
	}
}
