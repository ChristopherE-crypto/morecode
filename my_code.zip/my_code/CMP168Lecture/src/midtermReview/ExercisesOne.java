package midtermReview;

import java.util.Scanner;

public class ExercisesOne {
	
	public static String findFirstWord(String sentence) {
		sentence = sentence.replaceAll(" ", ",");
		String [] arr = sentence.split(",");
		return arr[0];
	}
	
	public static String findSecondWord(String sentence) {
		sentence = sentence.replaceAll(" ", ",");
		String [] arr = sentence.split(",");
		return arr[1];
	}
	
	public static void printReversedString(String sentence) {
		char [] arr = sentence.toCharArray();
		for(int i = sentence.length()-1; i >= 0; i--) {
			System.out.print(arr[i]);
		}
	}
	
	public static int sum(int a, int b) {
		return a + b;
	}
	
	public static int max(int a, int b) {
		if(a > b) {
			return a;
		}
		else {
			return b;
		}
	}
	
	public static void describePerson(String name) {
		char initial = name.charAt(0);
		
		switch(initial) {
		case 'A':
			System.out.println(name + " is amazing!");
			break;
		case 'B':
			System.out.println(name + " is bad!");
			break;
		case 'C':
			System.out.println(name + " is corrupt!");
			break;
		case 'D':
			System.out.println(name + " is decent!");
		}
	}

	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		int a = 3;
		int b = 5;
		String name = "Ben";
		
		//double x = scnr.nextDouble();
		
		//double y = x % 2;
		
		//System.out.println("x: " + x + " y: " + y);
		
		String text = "Hello World.";
		
		System.out.println(findFirstWord(text));
		
		System.out.println(findSecondWord(text));
		
		printReversedString(text);
		
		System.out.println("\nThe sum of " + a + " + " + b + " is " + sum(a,b));
		
		describePerson(name);
		

	}

}
