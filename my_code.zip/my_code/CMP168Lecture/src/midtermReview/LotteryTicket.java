package midtermReview;

public class LotteryTicket {

	public static void main(String[] args) {
		int [][] lotteryCard = {{20, 15, 7}, 
								 {8, 7, 19}, 
								{7, 13, 47}};
		
		int [][] lotteryCard2 = new int [3][3];
		lotteryCard2 [0][0] = 21;
		lotteryCard2 [0][1] = 14;
		lotteryCard2 [0][2] = 6;
		lotteryCard2 [1][0] = 9;
		lotteryCard2 [1][1] = 8;
		lotteryCard2 [1][2] = 18;
		lotteryCard2 [2][0] = 6;
		lotteryCard2 [2][1] = 12;
		lotteryCard2 [2][2] = 46;
		
		System.out.println(lotteryCard[0][0]);
		
		System.out.println("----------------------------------");
		
		for(int i = 0; i < 3; i++) {
			System.out.println(lotteryCard[i][i]);
		}
		
		System.out.println("----------------------------------");
		
		for(int i = 0; i < 3; i++) {
			System.out.println();
			for(int j = 0; j < 3; j++) {
				System.out.print(lotteryCard[i][j] + " ");
			}
		}

	}

}
