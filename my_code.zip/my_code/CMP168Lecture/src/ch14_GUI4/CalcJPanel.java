package ch14_GUI4;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CalcJPanel extends JPanel{
	
	private JLabel jlDisplay;
	private JTextField jtfNum1, jtfNum2;
	private JBtnPanel jpBtnPanel;
	public static final int NUM_BUTTONS = 4;
	
	public CalcJPanel() {
		setLayout(new GridLayout(3, 1));
		jlDisplay = new JLabel("CALCULATOR");
		Font bigFont = new Font(Font.SANS_SERIF, Font.BOLD, 30);
		jlDisplay.setFont(bigFont);
		
		jtfNum1 = new JTextField(5);
		jtfNum2 = new JTextField(5);
		
		jtfNum1.setFont(bigFont);
		jtfNum2.setFont(bigFont);
		
		jtfNum1.setForeground(Color.BLUE);
		jtfNum2.setForeground(Color.BLUE);
		
		JPanel jtfPanel = new JPanel();
		jtfPanel.setLayout(new GridLayout(1, 2));
		jtfPanel.add(jtfNum1);
		jtfPanel.add(jtfNum2);
		
		jpBtnPanel = new JBtnPanel();
		
		add(jlDisplay);//Gets added to first row of CalcJPanel
		add(jtfPanel);//Gets added to second row of CalcJPanel
		add(jpBtnPanel);//Gets added to third row of CalcJPanel
		
		
	}
	
	private double getNumFromJTF(JTextField someJTF) throws Exception {
		double num = 0;
		try {
		num= Double.parseDouble(someJTF.getText().trim());
		}catch(NumberFormatException e){
			throw new Exception("BAD INPUT");
		}
		
		return num;
	}
	
	private class JBtnPanel extends JPanel implements ActionListener{
		
		JButton [] jbtns = new JButton[NUM_BUTTONS];
		String [] jbtnTexts = {" + ", " - ", " / ", " * "};
		
		public JBtnPanel() {
			setLayout(new GridLayout(1, NUM_BUTTONS));
			
			for(int i = 0; i < jbtnTexts.length; i++) {
				jbtns[i] = new JButton();
				jbtns[i].setText(jbtnTexts[i]);
				jbtns[i].addActionListener(this);//Add action listener to each button
				add(jbtns[i]);//add each button to the JBtnPanel
			}
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			JButton btnClicked = (JButton)e.getSource();
			
			try {
				double num1 = getNumFromJTF(jtfNum1);
				double num2 = getNumFromJTF(jtfNum2);
				
				if(jbtns[0] == btnClicked) {
					double sum = num1 + num2;
					jlDisplay.setText("SUM = " + sum);
				}
				else if(jbtns[1] == btnClicked) {
					double sub = num1 - num2;
					jlDisplay.setText("DIFF = " + sub);
				}
				else if(jbtns[2] == btnClicked) {
					if(num2 == 0) {
						throw new Exception("Invalid Denominator");
					}
					else {
						jlDisplay.setText("QUOT = " + num1 / num2);
					}
				}
				else if(jbtns[3] == btnClicked) {
					jlDisplay.setText("PROD = " + num1 * num2);
				}
				else {
					jlDisplay.setText("WHAT???");
				}
				
				
				
				
				
				
				
			} catch (Exception e1) {
				
				e1.printStackTrace();
				jlDisplay.setText("Invalid Input!");
			}
			
		}
		
	}

}
