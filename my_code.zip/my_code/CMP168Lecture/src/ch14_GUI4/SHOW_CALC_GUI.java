package ch14_GUI4;

public class SHOW_CALC_GUI {

	public static void main(String[] args) {
		
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				CalcJFrame gui = new CalcJFrame();
			}
		});

	}

}
