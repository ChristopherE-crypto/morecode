package ch14_GUI4;

import javax.swing.JFrame;

public class CalcJFrame extends JFrame {
	
	public CalcJFrame() {
		
		CalcJPanel jpCalc = new CalcJPanel();
		
		add(jpCalc);
		
		setSize(400, 400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
