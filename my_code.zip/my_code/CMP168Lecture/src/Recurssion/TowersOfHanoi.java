package Recurssion;

public class TowersOfHanoi {

	public static void main(String[] args) {
		solveTheTower(4, "A", "B", "C");

	}
	
	public static void solveTheTower(int num, String src, String spare, String dest) {
		
		if(num == 1) {
			System.out.println("Move disk " + num + " from " + src + " to " + dest);
		}
		else {
			solveTheTower(num - 1, src, dest, spare);
			System.out.println("Move disk " + num + " from " + src + " to " + dest);
			solveTheTower(num - 1, spare, src, dest);
		}
	}

}
