package ch14_GUI3;

import java.awt.Color;
import java.awt.Graphics;

public class BasicTriangle extends BasicShape{

	public BasicTriangle(Graphics g) {
		super(g);
		x = 5;
		y = 5;
		paintComponent(g);
		
	}
	
	public BasicTriangle(Graphics g, int x, int y, int width, int height) {
		super(g, x, y, width, height);
		paintComponent(g);
		
	}
	
	public BasicTriangle(Graphics g, int x, int y, int width, int height, Color color) {
		super(g, x, y, width, height, color);
		paintComponent(g);
		
	}
	
	public BasicTriangle(Graphics g, int x, int y, int width, int height, Color color, boolean fillShape) {
		super(g, x, y, width, height, color, fillShape);
		paintComponent(g);
		
	}
	
	@Override
	public void paintComponent(Graphics g) {
		//x, y, draw beginning at upper left hand corner for any component
		
		int [] xPoints = {x, (int)(x - (width/ 2.0)), (int)(x + (width/ 2.0))};
		int [] yPoints = {y - height / 2, y + height / 2, y + height / 2};
		g.setColor(color);
		if(fillShape) {
			g.fillPolygon(xPoints, yPoints, 3);
		}
		else {
			g.drawPolygon(xPoints, yPoints, 3);
		}
	}
}
