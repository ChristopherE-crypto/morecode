package ch14_GUI3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;

import javax.swing.JPanel;

public class MyShapePanel extends JPanel{
	
	private final int MAX_X, MAX_Y, MAX_SHAPE_WIDTH, MAX_SHAPE_HEIGHT;
	
	public MyShapePanel() {
		MAX_X = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		MAX_Y = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		
		MAX_SHAPE_WIDTH = MAX_X / 4;
		MAX_SHAPE_HEIGHT = MAX_Y / 4;
		
		setPreferredSize(new Dimension(MAX_X / 2, MAX_Y / 2));
	}
	
	
	protected void paintComponent(Graphics g) {
		new BasicRectangle(g);
		new BasicRectangle(g, 75, 100, 100, 200, Color.CYAN, true);
		new BasicRectangle(g, 75, 200, 100, 200, Color.RED, true);
		new BasicRectangle(g, 150, 200, 100, 200, Color.YELLOW, true);
	}
	

}
