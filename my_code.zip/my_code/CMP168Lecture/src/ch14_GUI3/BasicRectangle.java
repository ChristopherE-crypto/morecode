package ch14_GUI3;

import java.awt.Color;
import java.awt.Graphics;

public class BasicRectangle extends BasicShape	{

	public BasicRectangle(Graphics g) {
		super(g);
		x = 5;
		y = 5;
		paintComponent(g);
		
	}
	
	public BasicRectangle(Graphics g, int x, int y, int width, int height) {
		super(g, x, y, width, height);
		paintComponent(g);
		
	}
	
	public BasicRectangle(Graphics g, int x, int y, int width, int height, Color color) {
		super(g, x, y, width, height, color);
		paintComponent(g);
		
	}
	
	public BasicRectangle(Graphics g, int x, int y, int width, int height, Color color, boolean fillShape) {
		super(g, x, y, width, height, color, fillShape);
		paintComponent(g);
		
	}
	
	@Override
	public void paintComponent(Graphics g) {
		//x, y, draw beginning at upper left hand corner for any component
		g.setColor(color);
		if(fillShape) {
			g.fillRect(x, y, width, height);
		}
		else {
			g.drawRect(x, y, WIDTH, HEIGHT);
		}
	}
}
