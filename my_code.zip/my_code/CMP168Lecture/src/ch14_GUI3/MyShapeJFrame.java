package ch14_GUI3;

import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MyShapeJFrame extends JFrame{
	
	public MyShapeJFrame() {
		JPanel mainJP = new JPanel();
		mainJP.setLayout(new GridLayout(1, 2));
		
		
		
		MyShapePanel shapeJP = new MyShapePanel();
		MyShapePanelResponsive shapeJPResp = new MyShapePanelResponsive();
		mainJP.add(shapeJP);
		mainJP.add(shapeJPResp);
		
		
		
		
		
		
		
		
		add(mainJP);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		pack();
	}

}
