package ch14_GUI3;

import chp14_GUI1.MyFirstJFrame;

public class Shape_GUI {

	public static void main(String[] args) {
		
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				MyShapeJFrame gui = new MyShapeJFrame();
			}
		});
	}

}
