package ch14_GUI3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

public class MyShapePanelResponsive extends JPanel implements MouseListener{
	
private final int MAX_X, MAX_Y, MAX_SHAPE_WIDTH, MAX_SHAPE_HEIGHT;
	
	public MyShapePanelResponsive() {
		MAX_X = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		MAX_Y = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		
		MAX_SHAPE_WIDTH = MAX_X / 4;
		MAX_SHAPE_HEIGHT = MAX_Y / 4;
		
		setPreferredSize(new Dimension(MAX_X / 2, MAX_Y / 2));
		addMouseListener(this);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();
		int width = 50;
		int height = 50;
		//new BasicRectangle(this.getGraphics(), x, y, width, height);//Draw beginning at the upper left hand corner and therefore making the shape appear downward and rightward of the click
		int shiftedX = x - width / 2;
		int shiftedY = y - height / 2;
		
		new BasicRectangle(this.getGraphics(), shiftedX, shiftedY, width, height, Color.GREEN, true);
		new BasicTriangle(this.getGraphics(), x, y, width, height, Color.RED, true);//Draws the rectangle from the center
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
