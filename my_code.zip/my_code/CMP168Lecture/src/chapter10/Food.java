package chapter10;

public class Food {
	
	private String name;
	private int calories;
	private int portionSizeInOunces;
	
	public Food(String name, int calories, int portionSize){
		this.name = name;
		this.calories = calories;
		portionSizeInOunces = portionSize;
	}

	public String getName() {
		return name;
	}

	public int getCalories() {
		return calories;
	}

	public int getPortionSizeInOunces() {
		return portionSizeInOunces;
	}
	
	@Override
	public String toString(){
		return String.format("Food [name= %10s, calories=%02d, portion size in ounces= %02d ]", name, calories, portionSizeInOunces);
	}
	@Override
	public boolean equals(Object o){
		if(o == null){return false;}
		if(this == o){return true;}
		if(o instanceof Food){
			Food otherF = (Food)o;
			if(name.equalsIgnoreCase(otherF.name)){
				if(calories == otherF.calories){
					if(portionSizeInOunces == otherF.portionSizeInOunces){
						return true;
					}
				}
			}
		}
		return false;
	}

}
