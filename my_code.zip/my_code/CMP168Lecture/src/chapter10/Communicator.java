package chapter10;

public interface Communicator {
	void speak();
	void speak(String s);
}
