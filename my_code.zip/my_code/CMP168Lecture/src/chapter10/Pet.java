package chapter10;

public abstract class Pet {
	
	private String favoriteFood;
	private String favoriteToy;
	private int maintenanceLevel;
	private boolean goesOutside;
	
	public Pet() {
		favoriteFood = "unknown food";
		favoriteToy = "unknown toy";
		maintenanceLevel = 0;
		goesOutside = false;
		
	}
	
	public Pet(String favoriteFood, String favoriteToy, int maintenanceLevel, boolean goesOutside) {
		this.favoriteFood = favoriteFood;
		this.favoriteToy = favoriteToy;
		this.maintenanceLevel = (maintenanceLevel > 0) ? maintenanceLevel : 0;
		this.goesOutside = goesOutside;
		
	}
	
	public abstract void play();
	
	public String getFavoriteFood() {
		return favoriteFood;
	}
	
	public String getFavoriteToy() {
		return favoriteToy;
	}
	
	public void setFavoriteFood(String favoriteFood) {
		this.favoriteFood = favoriteFood;
	}
	
	public void setFavoriteToy(String favoriteToy) {
		this.favoriteFood = favoriteToy;
	}
	
	public String toString() {
		String s = "Pet [favoriteToy = " + favoriteToy + ", favoriteFood = " + favoriteFood + ", maintenanceLevel = " + maintenanceLevel + ", goesOutside = " + goesOutside + "]";
		return s;
	}
	@Override
	public boolean equals(Object obj) {
		if(obj == null){ return false; }
		if(this == obj){ return true; }
		if(obj instanceof Pet){
			Pet otherP = (Pet) obj;
			if(this.favoriteFood.equalsIgnoreCase(otherP.favoriteFood)) {
				if(this.favoriteToy.equalsIgnoreCase(otherP.favoriteToy)) {
					if(this.maintenanceLevel == otherP.maintenanceLevel) {
						if(this.goesOutside == otherP.goesOutside) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}

}
