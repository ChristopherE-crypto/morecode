package chapter10;

public interface FoodEater {
	
	static final double METABOLISM_RATING_FAST = .75;
	static final double METABOLISM_RATING_MEDIUM = .5;
	static final double METABOLISM_RATING_SLOW = .15;
	
	
	void eat();
	void eat(Food f);
	double metabolizeFood(Food f);

}
