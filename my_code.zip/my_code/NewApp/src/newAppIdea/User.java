package newAppIdea;

import java.io.File;
import java.io.IOException;

public class User {
	private String username;
	private String password;
	private File [] files; //Max amount of files per user = 10
	private int filesNumber;
	
	public User() {
		this.username = "user123";
		this.password = "123456";
		files = new File [1];
		filesNumber = 0;
	}
	
	public User(String username, String password) {
		this.username = username;
		this.password = password;
		files = new File [10];
		filesNumber = 0;
	}
	
	public String getUsername() {
		return username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public int getNumberOfFiles() {
		return filesNumber;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void createFile(String fileName) throws IOException {
		
		for(int i = 0; i < files.length; i++) {
			if(files[i] == null) {
				files[i] = new File(fileName + i);
				files[i].createNewFile();
				filesNumber++;
				break;
			}
		}
	}

}
