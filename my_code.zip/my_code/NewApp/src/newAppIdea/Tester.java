package newAppIdea;

import java.io.IOException;

public class Tester {

	public static void main(String[] args) {
		
		User admin = new User("admin", "666666");
		
		LoginWindow w = new LoginWindow();
		

	}

}
