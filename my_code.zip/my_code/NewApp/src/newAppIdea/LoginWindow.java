package newAppIdea;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LoginWindow extends JFrame{

	public LoginWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500, 500);
		setLocationRelativeTo(null);
		setTitle("Notes Administrator");
		setResizable(false);
		
		JPanel panel = new JPanel();
		
		add(panel);
		
		panel.setLayout(null);
		
		JLabel label = new JLabel("User");
		label.setBounds(10, 20, 80, 25);
		panel.add(label);
		
		JTextField userText = new JTextField();
		userText.setBounds(100, 20, 165, 25);
		panel.add(userText);
		
		setVisible(true);
	}
	
}
