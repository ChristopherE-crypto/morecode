package com.chess.engine.pieces;

public class Piece {

}
