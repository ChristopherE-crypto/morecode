
public class Tester {

	public static void main(String[] args) {
		
		javax.swing.SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				//Grid g = new Grid();
				//Grid g = new Grid(5, 5, 1);
				Grid g = new Grid(12, 12, 50);
				g.print();
				
			}
			
		});

	}

}
