//Link for the video: https://www.youtube.com/watch?v=YBBAm3PdEos
//For some reason my app did not record the JOptionPanes that pop up when the user looses/wins. I apologize for the inconvenience.
//I had to comment out "new Frame()" because Zybooks was giving me trouble because of this. 

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Grid {//Grid class.
	
	private boolean [][] bombGrid;//Boolean 2D array for the bombs.
	private int [][] countGrid;//int 2D array that stores the bomb count next to where the user clicked.
	private int numRows;//Number of rows.
	private int numColumns;//Number of columns.
	private int numBombs;//Number of bombs.
	public JButton [][] button;//JButton 2D array.
	public boolean [][] revealed;//2D array for the cells revealed.
	
	private Random random = new Random();//Random object for spawning bombs.
	
	public int nextTo;//int variable used for the count.
	
	public Grid() {//Default constructor 10x10 and 25 bombs.
		numRows = 10;
		numColumns = 10;
		numBombs = 25;
		createBombGrid();//Places the bombs randomly.
		createCountGrid();//Calculates the count of bombs next to each cell.
		
		new frame();//Show the frame.
	}
	
	public Grid(int rows, int columns) {//Overloaded constructor. Rows and columns chosen by the user. 25 bombs.
		if(rows > 0 && columns > 0 && (rows * columns) > numBombs) {//Check that rows and columns are positive and that the number of bombs is less than the area of the board.
			numRows = rows;
			numColumns = columns;
			numBombs = 25;
			createBombGrid();
			createCountGrid();
			
			new frame();
		}
		else {//If the user enters an invalid index, set everything to default.
			numRows = 10;
			numColumns = 10;
			numBombs = 25;
			createBombGrid();
			createCountGrid();
			
			new frame();
		}
		
	}
	
	public Grid(int rows, int columns, int bombs) {//Overloaded constructor. Rows, columns, and number of bombs chosen by the user. 
		if(rows > 0 && columns > 0 && bombs > 0 && (rows * columns) > numBombs) {//Check rows, columns, and bombs are positive. Board area greater than the # of bombs.
			numRows = rows;
			numColumns = columns;
			numBombs = bombs;
			createBombGrid();
			createCountGrid();
			
			new frame();
		}
		else {//If invalid rows, columns or bombs; set everything to default.
			numRows = 10;
			numColumns = 10;
			numBombs = 25;
			createBombGrid();
			createCountGrid();
			
			new frame();
		}
		
	}
	
	public int getNumRows() {//Getter for the rows.
		return numRows;
	}
	
	public int getNumColumns() {//Getter for the columns.
		return numColumns;
	}
	
	public int getNumBombs() {//Getter for the number of bombs.
		return numBombs;
	}
	
	public boolean [][] getBombGrid() {//Return a copy of the 2D array bombGrid.
		boolean [][] copyB = new boolean [numRows][numColumns];
		for(int i = 0; i < bombGrid.length; i++) {
			for(int j = 0; j < bombGrid[i].length; j++) {
				copyB[i][j] = bombGrid[i][j];
			}
		}
		return copyB;
	}
	
	public int [][] getCountGrid() {//Return a copy of the 2D array countGrid.
		int [][] copyC = new int [numRows][numColumns];
		for(int i = 0; i < countGrid.length; i++) {
			for(int j = 0; j < countGrid[i].length; j++) {
				copyC[i][j] = countGrid[i][j];
			}
		}
		return copyC;
	}
	
	public boolean isBombAtLocation(int row, int column) {//Check if there is a bomb at a certain location.
		if(bombGrid[row][column]) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public int getCountAtLocation(int row, int column) {//Get the number of bombs next to a specific cell.
		
		nextTo = 0;
		
		if(bombGrid[row][column] == true) {//Count itself.
			nextTo++;
		
		}
		if(row > 0 && bombGrid[row - 1][column] == true) {//Check if there is a bomb above the cell.
			nextTo++;
		}
					
		if(row + 1 < getNumRows() && bombGrid[row + 1][column] == true) {//Check if there is a bomb below the cell.
			nextTo++;
		}
					
		if(column > 0 && bombGrid[row][column - 1] == true) {//Check if there is a bomb to the left of the cell.
			nextTo++;
		}
					
		if(column + 1 < getNumColumns() && bombGrid[row][column + 1] == true) {//Check if there is a bomb to the right of the cell.
			nextTo++;
		}
					
		//Diagonal 
					
		if(row > 0 && column > 0 && bombGrid[row - 1][column - 1] == true) {//Check if there is a bomb to the left and top of the cell.
			nextTo++;
		}
					
		if(row > 0 && column + 1 < getNumColumns() && bombGrid[row - 1][column + 1] == true) {//Check if there is a bomb right and above the cell.
			nextTo++;
		}
					
		if(row + 1 < getNumRows() && column > 0 && bombGrid[row + 1][column - 1]) {//Check if there is a bomb to the left and below of the cell.
			nextTo++;
		}
					
		if(row + 1 < getNumRows() && column + 1 < getNumColumns() && bombGrid[row + 1][column + 1] == true) {//Check if there is a bomb to the right and below of the cell.
			nextTo++;
		}
		
		return nextTo;
	}
	
	private void createBombGrid() {//Initialize the bombGrid 2D array and place the bombs randomly.
		
		revealed = new boolean [getNumRows()][getNumColumns()];//Initialize the revealed array.
		
		int counter = 0;//Counter for the bombs to be placed.
		
		bombGrid = new boolean[getNumRows()][getNumColumns()];//Initialize bomb array.
		
		while(counter < getNumBombs()) {
			
			//Get random integers.
			int randomRow = random.nextInt(getNumRows());
			int randomColumn = random.nextInt(getNumColumns());
			
			if(bombGrid[randomRow][randomColumn] == false) {//Place the bombs at random spots and make sure to not put the 2 bombs in the same cell. 
				bombGrid[randomRow][randomColumn] = true;
				counter++;
			}
		}
	}
	
	private void createCountGrid() {//Initialize the countGrid 2D array and get fill it the count of bombs.
		
		countGrid = new int[getNumRows()][getNumColumns()];//Initialize int array.
		
		for(int i = 0; i < getNumRows(); i++) {
			for(int j = 0; j < getNumColumns(); j++) {
				countGrid[i][j] = getCountAtLocation(i, j);//Add the count at location [i][j].
			}
		}
	}
	
	public void print() {//Print the count of all the cells.
		for(int i = 0; i < getNumRows(); i++) {
			for(int j = 0; j < getNumColumns(); j++) {
				System.out.print(" " + countGrid[i][j]);
			}
			System.out.println();
		}
	}
	
	private void printBombs() {//Print the location of the bombs.
		for(int i = 0; i < getNumRows(); i++) {
			for(int j = 0; j < getNumColumns(); j++) {
				System.out.print(" " + bombGrid[i][j]);
			}
			System.out.println();
		}
	}
	
	public class Board extends JPanel implements MouseListener{//JPanel for the JButtons.
		
		public Board() {//Default constructor for the JPanel.
			
			button = new JButton[getNumRows()][getNumColumns()];//Initialize the JButton 2D array.
			
			setLayout(new GridLayout(getNumRows(), getNumColumns()));//Set the layout to a GridLayout.
			
			displayBoard();//Display the JButtons.
			
		}
		
		public void setColors(int count, int row, int column) {//Sets the foreground color for the cells.
			if(count == 0) {
				button[row][column].setForeground(Color.LIGHT_GRAY);
			}
			else if(count == 1) {
				button[row][column].setForeground(Color.BLUE);
			}
			else if(count == 2) {
				button[row][column].setForeground(Color.GREEN);
			}
			else if(count == 3) {
				button[row][column].setForeground(Color.RED);
			}
			else if(count == 4) {
				button[row][column].setForeground(new Color(0, 0, 128));
			}
			else if(count == 5) {
				button[row][column].setForeground(new Color(178, 34, 34));
			}
			else if(count == 6) {
				button[row][column].setForeground(new Color(72, 209, 204));
			}
			else if(count == 7) {
				button[row][column].setForeground(Color.BLACK);
			}
			else if(count == 8) {
				button[row][column].setForeground(Color.DARK_GRAY);
			}
			else if(count == 9) {
				button[row][column].setForeground(Color.CYAN);
			}
		}
		
		public void removeZeroes(int row, int col) {
			if(bombGrid[row][col] == false) {
				if(countGrid[row][col] == 0) {
					if(row > 0) {//Check for cell above.
						if(countGrid[row - 1][col] >= 0 || countGrid[row - 1][col] < 10) {
							if(countGrid[row - 1][col] > 0 || countGrid[row - 1][col] < 10) {
								button[row - 1][col].setBackground(Color.LIGHT_GRAY);
								button[row - 1][col].setText("" + countGrid[row - 1][col]);
								revealed[row - 1][col] = true;
							}
							button[row - 1][col].setBackground(Color.LIGHT_GRAY);
						}
					}
					if(row + 1 < getNumRows()) {//Check for cell below.
						if(countGrid[row + 1][col] >= 0 || countGrid[row + 1][col] < 10) {
							button[row + 1][col].setBackground(Color.LIGHT_GRAY);
							button[row + 1][col].setText("" + countGrid[row + 1][col]);
							revealed[row + 1][col] = true;
						}
					}
					if(col > 0) {
						if(countGrid[row][col - 1] >= 0 || countGrid[row][col - 1] < 10) {
							button[row][col - 1].setBackground(Color.LIGHT_GRAY);
							button[row][col - 1].setText("" + countGrid[row][col - 1]);
							revealed[row][col - 1] = true;
						}
					}
					if(col + 1 < getNumColumns()) {
						if(countGrid[row][col + 1] >= 0 || countGrid[row][col + 1] < 10) {
							button[row][col + 1].setBackground(Color.LIGHT_GRAY);
							button[row][col + 1].setText("" + countGrid[row][col + 1]);
							revealed[row][col + 1] = true;
						}
					}
					if(col > 0 && row > 0) {//Check for upper left diagonal.
						if(countGrid[row - 1][col - 1] >= 0 || countGrid[row - 1][col - 1] < 10) {
							button[row - 1][col - 1].setBackground(Color.LIGHT_GRAY);
							button[row - 1][col - 1].setText("" + countGrid[row - 1][col - 1]);
							revealed[row - 1][col] = true;
						}
					}
					if(col + 1 < getNumColumns() && row + 1 < getNumRows()) {//Check for lower right diagonal.
						if(countGrid[row + 1][col + 1] >= 0 || countGrid[row + 1][col + 1] < 10) {
							button[row + 1][col + 1].setBackground(Color.LIGHT_GRAY);
							button[row + 1][col + 1].setText("" + countGrid[row + 1][col + 1]);
							revealed[row + 1][col + 1] = true;
						}
					}
					if(col + 1 < getNumColumns() && row > 0) {//Check for upper right diagonal.
						if(countGrid[row - 1][col + 1] >= 0 || countGrid[row - 1][col + 1] < 10) {
							button[row - 1][col + 1].setBackground(Color.LIGHT_GRAY);
							button[row - 1][col + 1].setText("" + countGrid[row - 1][col + 1]);
							revealed[row - 1][col + 1] = true;
						}
					}
					if(col > 0 && row + 1 < getNumRows()) {
						if(countGrid[row + 1][col - 1] >= 0 || countGrid[row + 1][col - 1] < 10) {
							button[row + 1][col - 1].setBackground(Color.LIGHT_GRAY);
							button[row + 1][col - 1].setText("" + countGrid[row + 1][col - 1]);
							revealed[row + 1][col - 1] = true;
						}
					}	
				}
			}
			
		}
		
		public void displayBoard() {//Adds the JButtons to the 2D array and sets the color/text/font of each. Adds MouseListener to each JButton.
			
			for(int i = 0; i < getNumRows(); i++) {
				for(int j = 0; j < getNumColumns(); j++) {
					button[i][j] = new JButton();
					button[i][j].addMouseListener(this);
					button[i][j].setBackground(Color.LIGHT_GRAY);
					button[i][j].setFont(new Font("Serif", Font.BOLD, 20));
					button[i][j].setEnabled(true);
					button[i][j].setFocusable(false);
					this.add(button[i][j]);//Adds the JButton to the JPanel.
					
					setColors(countGrid[i][j], i, j);//Set the colors for the buttons.
				}
			}
			
			printBombs();//Print the bombs.
		}
		
		public void clear() {//Clears the board.
			for(int i = 0; i < getNumRows(); i++) {
				for(int j = 0; j < getNumColumns(); j++) {
					button[i][j].setText("");
					button[i][j].setBackground(Color.LIGHT_GRAY);
					button[i][j].setForeground(Color.LIGHT_GRAY);
					button[i][j].setFont(new Font("Serif", Font.BOLD, 20));
					
					setColors(countGrid[i][j], i, j);
					
				}
			}
		}
		
		public void reset() {//Reset the game. Create a new bombGrid and countGrid.
			createBombGrid();
			createCountGrid();
			clear();
			
			for(int i = 0; i < getNumRows(); i++) {
				for(int j = 0; j < getNumColumns(); j++) {
					System.out.print(" " + countGrid[i][j]);
				}
				System.out.println();
			}
			
			printBombs();
		}
		
		public int count() {
			int count = 0;
			for(int i = 0; i < getNumRows(); i++) {
				for(int j = 0; j < getNumColumns(); j++) {
					if(revealed[i][j] == true) {
						count++;
					}
				}
			}
			return count;
		}

		@Override
		public void mouseClicked(MouseEvent e) {//Mouse Listener for the buttons.
			if(e.getButton() == MouseEvent.BUTTON1) {//Check that the user clicked the left click.
				for(int i = 0; i < getNumRows(); i++) {
					for(int j = 0; j < getNumColumns(); j++) {
						if(e.getSource() == button[i][j]) {//Check that the user clicked a JButton.
							
							removeZeroes(i, j);
							
							if((getNumRows() * getNumColumns()) - count() == getNumBombs()) {
								
								int op = JOptionPane.showConfirmDialog(this, "You have won!", "VICTORY", JOptionPane.OK_CANCEL_OPTION);//Show JOptionPane.
								
								if(op == JOptionPane.OK_OPTION) {//If the user clicks the ok option, reset and clean everything.
									reset();
								}
								if(op == JOptionPane.CANCEL_OPTION) {//If the user clicked the cancel option, reset and clean everything.
									reset();
								}
							}
							
							button[i][j].setText("" + countGrid[i][j]);
							button[i][j].setBackground(Color.LIGHT_GRAY);
							
							if(countGrid[i][j] == 0) {//If the count at a certain cell is 0, change its color to GRAY.
								button[i][j].setBackground(Color.LIGHT_GRAY);
							}
							
							revealed[i][j] = true;
							
							setColors(countGrid[i][j], i, j);
						}
						
						if(e.getSource() == button[i][j] && isBombAtLocation(i, j)) {//Check if the user clicked a cell that contains a bomb.
							button[i][j].setBackground(Color.RED);
							button[i][j].setForeground(Color.BLACK);
							button[i][j].setFont(new Font("Serif", Font.BOLD, 30));
							button[i][j].setText("X");
							
							//This part shows count and all the bombs when the user has clicked a bomb.
							
							for(int x = 0; x < getNumRows(); x++) {
								for(int y = 0; y < getNumColumns(); y++) {
									if(bombGrid[x][y] == false) {
										button[x][y].setText("" + countGrid[x][y]);
										button[x][y].setForeground(Color.DARK_GRAY);
									}
									if(bombGrid[x][y] == true) {
										button[x][y].setText("X");
										button[x][y].setForeground(Color.BLACK);
										button[x][y].setBackground(Color.RED);
									}
								}
							}
							
							int option = JOptionPane.showConfirmDialog(this, "You lost. Would you like to play again?", "DEFEAT", JOptionPane.YES_NO_OPTION);//Show JOptionPane when the user has lost.
							
							if(option == JOptionPane.YES_OPTION) {//If clicked yes option, reset and clean everything.
								reset();
							}
							if(option == JOptionPane.NO_OPTION) {//If clicked no, close everything.
								System.exit(0);
							}
						}
						
					}
				}
			}
			
			if(e.getButton() == MouseEvent.BUTTON2) {//Clear the board when the user clicks the little wheel.
				clear();
			}
			if(e.getButton() == MouseEvent.BUTTON3) {//Flags when right click.
				for(int i = 0; i < getNumRows(); i++) {
					for(int j = 0; j < getNumColumns(); j++) {
						if(e.getSource() == button[i][j]) {
							button[i][j].setBackground(Color.WHITE);
							button[i][j].setText("?");
							button[i][j].setForeground(Color.BLACK);
							button[i][j].setFont(new Font("Serif", Font.BOLD, 20));
						}
					}
				}
			}
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
	
	public class frame extends JFrame {//JFrame.
		
		public frame() {//Default constructor.
			Board b = new Board();//Create an instance of the board class.
			add(b);//Add the board to the JFrame.
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setTitle("Minesweeper");
			setSize(750, 750);
			setLocationRelativeTo(null);
			setVisible(true);
			setResizable(false);
		
		}
	}
	
	
}
