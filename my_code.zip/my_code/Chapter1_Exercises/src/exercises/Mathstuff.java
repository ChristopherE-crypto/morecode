package exercises;
import java.util.Random;

public class Mathstuff {
public static void main(String [] Args) {
	
	Random randomGen = new Random();
	
	randomGen.nextInt(10);
	
	int randNum = randomGen.nextInt(100);
	
	System.out.println("The random number is : "+ randNum);
	
	System.out.println("The number "+ randNum + " squared is "+ Math.pow(randNum, 2));
	
	
	
}
}
