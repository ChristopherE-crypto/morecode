package xdd;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.io.File;

public class WordFinder {

	public static void main(String[] args) throws IOException, FileNotFoundException {
		Scanner scnr = new Scanner(System.in);
		File file = new File("C:/Users/epicd/OneDrive/Desktop/myText.txt");
	      FileInputStream fileByteStream = null; // File input stream
	      Scanner inFS = null;                   // Scanner object
	      String userWord;
	      int wordFreq = 0;
	      String currWord;

	      // Try to open file
	      System.out.println("Opening file wordFile.txt.");
	      fileByteStream = new FileInputStream(file);
	      inFS = new Scanner(fileByteStream);

	      // Word to be found
	      System.out.print("Enter a word: ");
	      userWord = scnr.next();

	      while (inFS.hasNext()) {
	         currWord = inFS.next();
	         if(currWord.equals(userWord)) {
	            ++wordFreq;
	         }
	      }

	      System.out.println(userWord + " appears in the file " +
	                         wordFreq + " times.");

	      // Done with file, so try to close it
	      fileByteStream.close();

	}

}
