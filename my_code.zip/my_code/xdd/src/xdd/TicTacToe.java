package xdd;

public class TicTacToe {
	
	public void displayBoard(String [][] board) {
		
		System.out.println();
		
		System.out.println(" " + board[0][0] + " | " + board[0][1] + " | " + board[0][2] + "");
		
		System.out.println("-----------");
		
		System.out.println(" " + board[1][0] + " | " + board[1][1] + " | " + board[1][2] + "");
		
		System.out.println("-----------");
		
		System.out.println(" " + board[2][0] + " | " + board[2][1] + " | " + board[2][2] + "");
		
		
	}
	
	public void clearBoard(String [][] board) {
		
		for(int i = 0; i < board.length; i++) {
			
			for(int j = 0; j < board[i].length; j++) {
				
				board[i][j] = " ";
			}
		}
	}
	
	public String [] userToken() {
		
		java.util.Scanner scnr = new java.util.Scanner(System.in);
		
		System.out.println("Player 1 enter X or O: ");
		
		String playerOneToken = scnr.next();
		
		String playerTwoToken = "";
		
		boolean valid = true;
		
		if(!playerOneToken.equals("X") || !playerOneToken.equals("O")) {
			
			valid = false;
		}
		
		while(valid) {
			
			System.out.println("You entered the wrong thing. Please try again!");
			
			playerOneToken = scnr.next();
			
			if(playerOneToken.equals("X") || playerOneToken.equals("O")) {
				
				valid = true;
			}
		}
		
		if(playerOneToken.equals("X")) {
			
			playerTwoToken = "O";
		}
		
		else {
			
			playerTwoToken = "X";
		}
		
		String [] tokens = new String [] {playerOneToken , playerTwoToken};
		
		return tokens;
	}
	
	public static void main(String [] args) {
		
		TicTacToe ttt = new TicTacToe();
		
		String [][] board = new String [3][3];
		
		ttt.clearBoard(board);
		
		ttt.displayBoard(board);
		
		String [] tokens = ttt.userToken();
		
		for(int i = 0; i < tokens.length; i++) {
			
			System.out.print(tokens[i]);
		}
	}

}
