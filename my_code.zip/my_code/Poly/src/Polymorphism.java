class Bird {
	public void sing() {
		System.out.println("Tweet tweet tweet");
	}
}

class Robin extends Bird {
	public void sing() {
		System.out.println("Twiddledeedee");
	}
}

class Pelican extends Bird {
	public void sing() {
		System.out.println("Kwaah Kwaah Kwaah");
	}
}

public class Polymorphism {

	public static void main(String[] args) {
		
		
		
		Bird birds [] = {new Robin(), new Pelican(), new Bird()};
		
		for(int i = 0; i < birds.length; i++) {
			birds[i].sing();
		}

	}

}
