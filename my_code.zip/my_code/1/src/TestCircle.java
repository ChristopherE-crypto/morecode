import java.util.Scanner;

public class TestCircle {
	
	public static void main(String [] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		
		
		System.out.println("Enter a color: ");
		String s = scnr.next();
		
		Circle c =  new Circle(3, s);
		
		System.out.println(c.area());
		System.out.println(c.diameter());
		
		c.print();
		
		System.out.println(c.getRadius());
		System.out.println(c.getColor());
		
		c.setColor("blue");
		c.print();
		
	}

}
