import java.util.Scanner;

public class DateConverter {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("Enter 4 integers representing dayNumber monthNumber date year:");
	String day = "Day";
	int dayNumber = scnr.nextInt();
	if(dayNumber <=0 || dayNumber > 7) {
		System.out.println("Invalid day number: " + dayNumber + ", please enter a number from 1..7.");
	}
	else {
		switch(dayNumber) {
		case 1:
			day = "Sunday";
		break;
		case 2:
			day = "Monday";
		break;
		case 3:
			day = "Tuesday";
		break;
		case 4:
			day = "Wednesday";
		break;
		case 5:
			day = "Thursday";
		break;
		case 6:
			day = "Friday";
		break;
		case 7:
			day = "Saturday";
		break;
		}
	}
	String month = "Month";
	int monthNumber = scnr.nextInt();
	if(monthNumber <= 0 || monthNumber > 12) {
		System.out.println("Invalid month number: " + monthNumber + ", please enter a number from 1..12");
	}
	else {
		switch(monthNumber) {
		case 1:
			month = "January";
		break;
		case 2:
			month = "February";
		break;
		case 3:
			month = "March";
		break;
		case 4:
			month = "April";
		break;
		case 5:
			month = "May";
		break;
		case 6:
			month = "June";
		break;
		case 7:
			month = "July";
		break;
		case 8:
			month = "August";
		break;
		case 9:
			month = "September";
		break;
		case 10:
			month = "October";
		break;
		case 11:
			month = "November";
		break;
		case 12:
			month = "December";
		break;
	}
}
	
	int date = scnr.nextInt();
	
	if(date <= 0 || date > 31) {
		System.out.println("Invalid date number: " + date + ", please enter a number from 1..31.");
	}
	
		
	
	
	    if(monthNumber == 2 && date == 30 && date == 31) {
			System.out.println("Invalid date: February, does not have " + date + " days, please enter a valid date.");
		}
		if(monthNumber == 4 && date == 31) {
			System.out.println("Invalid date: April, does not have " + date + " days, please enter a valid date.");
		}
	    if(monthNumber == 6 && date == 31) {
			System.out.println("Invalid date: June, does not have " + date + " days, please enter a valid date.");
		}
		if(monthNumber == 9 && date == 31) {
			System.out.println("Invalid date: September, does not have " + date + " days, please enter a valid date.");
		}
		if(monthNumber == 11 && date == 31) {
			System.out.println("Invalid date: November, does not have " + date + " days, please enter a valid date.");
		}
		int year = scnr.nextInt();
			System.out.printf("%d %d %d %d is %s %s %d, %d", dayNumber, monthNumber, date, year, day, month, date, year);
		
	
	
	
    }
}
