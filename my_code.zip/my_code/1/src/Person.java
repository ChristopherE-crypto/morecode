import java.util.Arrays;
import java.util.Random;

public class Person {
	
	private String name;
	private int age;
	private char gender;
	private String hairColor;
	private int height;
	private int weight;
	
	public Person() {
		name = "No name";
		age = 21;
	}
	public Person(String name, String hairColor) {
		this.name = name;
		this.hairColor = hairColor;
		weight = 50;
	}
	
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public char getGender() {
		return gender;
	}
	public String getHairColor() {
		return hairColor;
	}
	public int getHeight() {
		return height;
	}
	public int getWeight() {
		return weight;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public void setHairColor(String hairColor) {
		this.hairColor = hairColor;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	
	
	public void speak() {
		Random randNum = new Random();
		
		
		int number = randNum.nextInt(5);
		String phrase = "";
		
		switch(number) {
		case 0:
			phrase = "You are ugly!";
			break;
		case 1:
			phrase = "You are nice!";
			break;
		case 2:
			phrase = "Stop doing your homework!";
			break;
		case 3: 
			phrase = "Leave me alone...";
			break;
		case 4:
			phrase = "Yikes!";
			break;
		}
		
		 
		
		System.out.println(name + " says: " + phrase);
	}
	public void print() {
		System.out.println("Name: " + name);
		System.out.println("Age " + age);
		System.out.println("Gender: " + gender);
		System.out.println("Hair color: " + hairColor);
		System.out.println("Height: " + height);
		System.out.println("Weight: " + weight);
	}

}

