import java.util.Scanner;

public class Driver {
	

	
	public static void main(String [] args) {
		
		Scanner scnr = new Scanner(System.in);
		//String s = scnr.next();
		//char c = scnr.next().charAt(0);
		int a = scnr.nextInt();
		//int b = scnr.nextInt();
		
		//MidtermProblems.replaceLast(s, c);
		//MidtermProblems.difference(a, b);
		//MidtermProblems.evens(a);
		//MidtermProblems.productAll(a, b);
		
		//Examtesting.cc(a);
		
		//System.out.println(MidtermProblems.replaceLast(s, c));
		//System.out.println(MidtermProblems.difference(a, b));
		System.out.print(MidtermProblems.evens(a));
		//System.out.print(MidtermProblems.productAll(a, b));
		
		//System.out.print(Examtesting.cc(a));
		
		
		//int n;
		//for(n = 0; n <= a; n = n + 2) {
			//System.out.print(n + " ");
		//}
	}

}
