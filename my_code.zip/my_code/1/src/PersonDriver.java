
public class PersonDriver {

	public static void main(String[] args) {
		Person pepe = new Person();
		Person Joseph = new Person();
		
		pepe.setName("Jose");
		pepe.setAge(12);
		pepe.setGender('m');
		pepe.setHairColor("Black");
		pepe.setHeight(100);
		pepe.setWeight(50);
		
		pepe.speak();
		
		Joseph.setName("Joseph");
		Joseph.setAge(15);
		Joseph.setGender('m');
		Joseph.setHairColor("Black");
		Joseph.setHeight(180);
		Joseph.setWeight(140);
		
		Joseph.speak();

	}

}
