
public class Circle {

	private double radius;
	private String color;
	
	public Circle(int r, String c) {
		radius = r;
		color = c;
	}
	
	public double getRadius() {
		return radius;
	}
	
	public String getColor() {
		return color;
	}
	
	public void setRadius(double newRadius) {
		radius = newRadius;
	}
	
	public void setColor(String newColor) {
		color = newColor;
	}
	
	public void print() {
		System.out.println("Cicle: (" + radius + ", " + color + ")");
	}
	
	public double diameter() {
		return 2 * radius;
	}
	
	public double area() {
		return Math.PI * Math.pow(radius, 2);
	}
	
	public double circumference() {
		return 2 *  Math.PI * radius;
	}
}
