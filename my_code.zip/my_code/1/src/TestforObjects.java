
public class TestforObjects {
	
	public static void main(String [] args) {
		Cat pepe = new Cat();
		Cat Mishi = new Cat();
		Cat Leo = new Cat();
		
		pepe.setName("Carlos");
		pepe.setHeight(50.5);
		pepe.setWeight(30.5);
		pepe.setIsVaccinated(true);
		
		String pepeName = pepe.getName();
		double pepeHeight = pepe.getHeight();
		double pepeWeight = pepe.getWeight();
		boolean pepeVacc = pepe.getIsVaccinated();
		System.out.println("pepe's name is " + pepeName);
		System.out.println("pepe's height is " + pepeHeight + " cm.");
		System.out.println("pepe's weight is " + pepeWeight + " lbs.");
		System.out.println("Is pepe vaccinated? " + pepeVacc);
	}

}
