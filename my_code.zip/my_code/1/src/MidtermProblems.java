

public class MidtermProblems {
	
public static String replaceLast(String s, char c) {
		
		if(s == null) {
			return null;
		}
		if(s.equals("")) {
			return "";
		}
		
		s = s.replace(s.charAt(s.length()-1), c);
		
		return s;
	}

public static String difference(int a, int b) {
	
	if(a > b) {
	int diff = Math.abs(a - b);
	
	if(diff >= 10) {
		
		return "Big Difference " + diff;
	}
	else if(diff < 10) {
		
		return "Small Difference " + diff;
	}
	else {
		
		return "EQUAL";
	}
	}
	 if(a < b) {
		int diff = Math.abs(a - b);
		if(diff >= 10) {
			
			return "Big Difference -" + diff;
		}
		else if(diff < 10) {
			
			return "Small Difference -" + diff;
		}
		else {
			
			return "EQUAL";
		}
	}
	else {
		
		return "EQUAL";
	}
}

public static String evens(int a) {
	
	String numbers  = "";
	
	if(a >= 0) {
		
		for(int i = 0; i <= a; i = i + 2) {
			
			numbers += i + ",";
		}
		return numbers = numbers.substring(0, numbers.length()-1);
		
	}
	else {
        return "NONE";
	}
		
}

public static int productAll(int a, int b) {
	
	if(a > b) {
		int product = 1;
		for(int i = a; i >= b; i--) {
			product = product * i;
		}
		return product;
	}
	else if(a < b) {
		int product = 1;
		for(int i = a; i <= b; i++) {
			product = product * i;
		}
		return product;
	}
	else if(a < 0 && b > 0 || a > 0 && b < 0) {
		return 0;
	}
	else if(a == b){
		return a * b;
	}
	else {
		return 0;
	}
}
}

