import java.util.Arrays;
import java.util.Scanner;


public class Grades {
	
	public static int readGrades(int [] grades) { //Takes grades from the user until the user enters a negative number. 
		//Place them into an array and return the number of grades that were read from the user. 
		
		Scanner scnr = new Scanner(System.in);
		System.out.println("Enter a grade : ");
		int grade = scnr.nextInt();
		int totalGrades = 0;
		
		while(grade != -1) {
			
			grades[totalGrades] = grade;
			totalGrades += 1;
			
			System.out.println("Enter a grade : ");
			grade = scnr.nextInt();
		}
		
		return totalGrades;
				
	}
	
	public static int sum(int [] arr) {
		
		int sum = 0;
		
		for(int i = 0; i < arr.length; i++) {
			
			sum += arr[i];
		}
		return sum;
	}
	
	public static int sum(int [] arr, int firstIndex, int lastIndex) {
		
		int sum = 0;
		
		if(lastIndex >= arr.length) {
			return -666;
		}
		
		else if(firstIndex >= 0 && lastIndex > 0 && firstIndex < lastIndex) {
			
			for(int i = firstIndex; i <= lastIndex; i++) {
				
				sum += arr[i];
			}
			
		}
		else {
			return -666;
		}
		return sum;
	}
	
	public static double average(int [] arr) {
	int sum = 0;
	
	for(int i = 0; i < arr.length; i++) {
		
		sum += arr[i];
	}
	int numbers = arr.length;
	double average = (double) sum / (double) numbers;
	return average;
	}
	
	public static int maxValue(int [] arr) {
	int max = Integer.MIN_VALUE;
	for(int i = 0; i < arr.length; i++) {
		if(arr[i] > max) {
			max = arr[i];
		}
	}
	return max;
	}
	
	public static int maxValue(int [] arr, int firstIndex, int lastIndex) {
		
		if(lastIndex >= arr.length) {
			return -666;
		}
		
		else if(firstIndex >= 0 && lastIndex > 0 && firstIndex < lastIndex) {
			int max = Integer.MIN_VALUE;
			for(int i = firstIndex; i <= lastIndex; i++) {
				if(arr[i] > max) {
					max = arr[i];
				}
			}
			return max;
		}
		else {
			return -666;
		}
		
	}
	
	public static int indexOfFirstMaxValue(int [] arr) {
		int max = arr[0];
		int index = 0;
		
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] > max) {
				index = i;
				max = arr[i];
			}
		}
		return index;
	}
	
	public static int minValue(int [] arr) {
		
		int min = Integer.MAX_VALUE;
		for(int i = 0; i < arr.length; i++) {
			
			if(arr [i] < min && arr [i] > 0) {
				min = arr [i];
			}
			
		}
		return min;
	}
	
	public static int minValue(int [] arr, int firstIndex, int lastIndex) {
		
		if(lastIndex >= arr.length) {
			return -666;
		}
		
		else if(firstIndex >= 0 && lastIndex > 0 && firstIndex < lastIndex) {
			int min = Integer.MAX_VALUE;
			for(int i = firstIndex; i <= lastIndex; i++) {
				if(arr [i] < min) {
					min = arr [i];
				}
			}
			return min;
		}
		else {
			return -666;
		}
	}
	
	public static int indexOfFirstMinValue(int [] arr) {
		
		int min = arr [0];
		int index = 0;
		
		for(int i = 0; i < arr.length; i++) {
			if(arr [i] < min) {
				index = i;
				min = arr [i];
			}
		}
		return index;
	}
	
	public static int numberOfBelowAverageElements(int [] arr) {
		
		int sum = 0;
		int count = 0;
		
		//Average.
		for(int i = 0; i < arr.length; i++) {
			
			sum += arr [i];
		}
		int numbers = arr.length;
		double average = (double) sum / (double) numbers;
		
		//Counting min values.
		for(int i = 0; i < arr.length; i++) {
			if(arr [i] < average) {
				count++;
			}
		}
		return count;
	}
	
	public static int numberOfAboveAverageElements(int [] arr) {
		
		int sum = 0;
		int count = 0;
		
		//Average.
		for(int i = 0; i < arr.length; i++) {
			
			sum += arr [i];
		}
		int numbers = arr.length;
		double average = (double) sum / (double) numbers;
		
		//Counting max values.
		
		for(int i = 0; i < arr.length; i++) {
			if(arr [i] > average) {
				count++;
			}
		}
		return count;
	}
	
	public static void rotateElements(int [] arr) {
		for(int i = 0; i < 1; i++) {
			
		
		int temp = arr [arr.length - 1];
		
		for(i = arr.length - 1; i > 0; i--) {
			
			arr [i] = arr[i - 1];
		}
		arr [0] = temp;
		}

	}
	
	public static void rotateElements(int [] arr, int rotationCount) {
		
		for(int i = 1; i <= rotationCount; i++) {
			
			int temp = arr [arr.length - 1];
			
			for(int j = arr.length - 1; j > 0; j--) {
				
				arr [j] =  arr [j - 1];
			}
			arr [0] = temp;
		}
	}
	
	public static void reverseArray(int [] arr) {
		
		int i, b;
		for(i = 0; i < arr.length / 2; i++) {
			b = arr [i];
			arr [i] = arr [arr.length - i - 1];
			arr[arr.length - i - 1] = b;
		}
	}
	
	
	
	public static void main(String [] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		int [] arr = new int [150];
		//int [] a = new int [12];
		//int [] b = new int [14];
		//int [] c = new int [22];
		//int [] d = new int [45];
		//int x = readGrades(arr);
		//System.out.println(x);
		
		//int [] arr = {1, 4, 5, 6, 4, 5, 2, 7, 9, 10, 6, 10, 45, 33, 9, 2, 44, 64, 12, 30, 34, 22, 34, 11, 28};
		
		//System.out.println(sum(arr));
		//System.out.println(sum(arr, 2, 6));
		//System.out.println(average(arr));
		//System.out.println(maxValue(arr));
		//System.out.println(maxValue(arr, 2, 6));
		//System.out.println(indexOfFirstMaxValue(arr));
		//System.out.println(minValue(arr));
		//System.out.println(minValue(arr, 2, 25));
		//System.out.println(indexOfFirstMinValue(arr));
		//System.out.println(numberOfBelowAverageElements(arr));
		//System.out.println(numberOfAboveAverageElements(arr));
		//rotateElements(arr);
		//rotateElements(arr, 2);
		//reverseArray(arr);
		
		//for(int i = 0; i < arr.length; i++) {
		//	System.out.print(arr [i] + ", ");
		//}
		
		
		
		int numOfGrades = readGrades(arr);
		System.out.println("Number Of Grades = " + numOfGrades);
		System.out.println("Maximum Grade = " + maxValue(arr));
	    System.out.println("Minimum Grade = " + minValue(arr));
	    
	    
	    //------------------------------------------------------
	    
	    
	}

}
