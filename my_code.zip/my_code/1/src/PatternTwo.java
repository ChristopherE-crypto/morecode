import java.util.Scanner;

public class PatternTwo {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("Please enter a number 1...9 : ");
	int n = scnr.nextInt();
	
	int i, j;  
    for(i = 1; i <= n; i++) //outer loop for number of rows(n)
    { 
    for(j = (2*(n - i))-1; j >= 0; j--) // inner loop for spaces 
        {           
            System.out.print(" "); // printing space
        } 
        for(j = i; j >= 1; j--) //  inner loop for columns
        {
        	System.out.print(" " + j);
       
        }           
        System.out.println(); // ending line after each row
    } 
		
	//Homework 5-4. It took me the whole day to figure it out. Felt good at the end.
}
}
