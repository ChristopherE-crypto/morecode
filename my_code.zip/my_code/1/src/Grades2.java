import java.util.Scanner;

public class Grades2 {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	
	int numGradesA = 0;
	int numGradesAminus = 0;
	int numGradesBplus = 0;
	int numGradesB = 0;
	int numGradesBminus = 0;
	int numGradesCplus = 0;
	int numGradesC = 0;
	int numGradesCminus = 0;
	int numGradesD = 0;
	int numGradesF = 0;
	
	int total = 0;
	
	System.out.println("Enter a grade: ");
	int grade = scnr.nextInt();
	
	while(grade > 0) {
		System.out.println("Enter a grade: ");
		total++;
	
	if(grade >= 93 && grade <= 100)
		numGradesA++;
	else if(grade >= 90 && grade < 93)
		numGradesAminus++;
	else if(grade >= 87 && grade < 90)
		numGradesBplus++;
	else if(grade >= 83 && grade < 87)
		numGradesB++;
	else if(grade >= 80 && grade < 83)
		numGradesBminus++;
	else if(grade >= 77 && grade < 80)
		numGradesCplus++;
	else if(grade >= 73 && grade < 77)
		numGradesC++;
	else if(grade >= 70 && grade < 73)
		numGradesCminus++;
	else if(grade >= 60 && grade < 70)
		numGradesD++;
	else if(grade >= 0 && grade < 60)
		numGradesF++;
	
	grade = scnr.nextInt();
	
	}
	System.out.println("Total number of grades = " + total);
	System.out.println("Number of A's  = " + numGradesA);
	System.out.println("Number of A-'s = " + numGradesAminus);
	System.out.println("Number of B+'s = " + numGradesBplus);
	System.out.println("Number of B's  = " + numGradesB);
	System.out.println("Number of B-'s = " + numGradesBminus);
	System.out.println("Number of C+'s = " + numGradesCplus);
	System.out.println("Number of C's  = " + numGradesC);
	System.out.println("Number of C-'s = " + numGradesCminus);
	System.out.println("Number of D's  = " + numGradesD);
	System.out.println("Number of F's  = " + numGradesF);
	
	// Homework 5-2 It was quite difficult. The while loop was tricky. 
    }
}
