
public class Examtesting {
	
	public static String cc(int a) {
	  String numbers = "";
	  int i = 0;
	  if(a > 0) {
	  while(i <= a) {
		  
		  numbers = i + " ";
		  
		 i += 2;
	  }
	  return numbers;
	  }
	  else {
		  return "NONE";
	  }
		
	
	}


public static void main(String [] args) {
	
	for(int i = 0; i <= 10; i++) {
		for(int j = 1; j <= 10; j++) {
			System.out.println();
		}
	}
	
	
      }
}