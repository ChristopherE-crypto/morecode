import java.util.Scanner;

public class AgeLabel {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("Enter an age in number of days :");
	int numDays = scnr.nextInt();
	
	if(numDays <= 365) {
		System.out.println("You are an infant");
	}
	else if(numDays > 365 && numDays <= 1095) {
		System.out.println("You are a toddler");
	}
	else if(numDays > 1095 && numDays <= 4380) {
		System.out.println("You are a child");
	}
	else if(numDays > 4380 && numDays <= 6935) {
		System.out.println("You are a teenager");
	}
	else if(numDays > 6935 && numDays <= 7665) {
		System.out.println("You are a young adult");
	}
	else if(numDays > 7665 && numDays <= 18250) {
		System.out.println("You are an adult");
	}
	else if(numDays > 18250 && numDays <= 23725) {
		System.out.println("You are middle aged");
	}
	else if(numDays > 23725) {
		System.out.println("You are a senior citizen");
	}
	
	
}
}
