import java.util.Scanner;
public class Main{
   
	public static void main(String[] args) {
	   Scanner kb = new Scanner(System.in);
	   //int a = kb.nextInt();
	   String s = kb.nextLine();
	   //int index = kb.nextInt();
	   //char c = kb.next().charAt(0);
	  // int b = kb.nextInt();
	  // int c = kb.nextInt();
	  // Homework6Methods.getMaxOf2Ints(a,b);
	  // Homework6Methods.getMinOf2Ints(a,b);
	  // Homework6Methods.getMaxOf3Ints(c,a,b);
	  // Homework6Methods.getMedianOf3Ints(c,b,a);
	   //Homework6Methods.printMinOf3Ints(b,c,a);
	  // Homework6Methods.getProdOfAllPositiveInts(a);
	   //Homework6Methods.getProdOfAllNegativesInts(a);
	  // Homework6Methods.isProdOfAllNegativeIntsNegative(a);
	   //Homework6Methods.getCharAtIndex(s, index);
	   //Homework6Methods.getCountOfCharInString(s, c);
	   //Homework6Methods.getStringReversed(s);
	   Homework6Methods.getStringTitleCased(s);
	   
	   //int result = Homework6Methods.getMaxOf3Ints(c, a, b);
	   //int result = Homework6Methods.getMaxOf2Ints(a, b);
	   //int result = Homework6Methods.getMedianOf3Ints(c,b,a);
	   //int result = Homework6Methods.getProdOfAllNegativesInts(a);
	  // boolean iS = Homework6Methods.isProdOfAllNegativeIntsNegative(a);
	  //System.out.println(Homework6Methods.getCharAtIndex(s, index));
	   //int result = Homework6Methods.getCountOfCharInString(s, c);
	   //System.out.println(Homework6Methods.getStringReversed(s));
	   System.out.println(Homework6Methods.getStringTitleCased(s));
	   //System.out.println(result);
	  // System.out.println(index);
	   //System.out.println(iS);
	}
}