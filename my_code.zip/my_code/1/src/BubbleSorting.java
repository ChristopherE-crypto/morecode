
public class BubbleSorting {
	
	public static void swap(int [] arr, int i, int j) {//Method that swaps the values of an array.
		int temp = arr [i];
		arr [i] = arr [j];
		arr [j] = temp;
	}
	
	public static void bubbleSort(int [] arr) {
		for(int i = 0; i< arr.length - 1; i++) {
			for(int j = 0; j < arr.length - 1; j++) {
				if(arr [j] > arr [j + 1]) {
					swap(arr, j, j + 1);
				}
			}
		}
	}
	
	public static void bubbleSortBetter(int [] arr) {
		boolean isSorted = false;
		while(!isSorted) {
			isSorted = true;
			for(int j = 0; j < arr.length - 1; j++) {
				if(arr [j] > arr [j + 1]) {
					swap(arr, j, j + 1);
					isSorted = false;
				}
			}
		}
	}
	
	public static void main(String [] args) {
		
		int [] arr = {90, 89, 78, 67, 56, 45, 34, 75};
		
		for(int i = 0; i < arr.length; i++) {//Before the method
			System.out.print(arr [i] + ", ");
		}
		
		System.out.println();
		
		bubbleSort(arr);
		
		for(int i = 0; i < arr.length; i++) {//After the method
			System.out.print(arr [i] +", ");
		}
		
		System.out.println();
		
		bubbleSortBetter(arr);
		
		for(int i = 0; i < arr.length; i++) {//After the other method
			System.out.print(arr [i] +", ");
		}
	}

}
