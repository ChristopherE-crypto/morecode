import java.util.Scanner;

public class PatternOne {
public static void main(String [] args) {
	
	Scanner scnr = new Scanner(System.in);
	
	System.out.println("Please enter a number 1...9 : ");
	int n = scnr.nextInt();
	
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= i; j++) {
			System.out.print(j + " ");
		}
		System.out.println();
		
	}
	
	
	
	//System.out.println("Please enter a number 1...9 : ");
	//int n = scnr.nextInt();
	
	//for(int i = 1; i <= n; i++) {
	//	for(int j = i; j <= n; j++) {
	//		System.out.print(" ");
	//	}
	//	for(int l = i; l >= 1; l--) {
	//		System.out.print("");
	//		System.out.print(l);
	//		System.out.print("");
	//	}
	//	System.out.println();
	//}
	
	
	
	
}
}
