import java.lang.*;
import java.util.Scanner;
public class Homework6Methods{
   
   public static int getMaxOf2Ints(int a, int b) {
	   
	   if(a > b) {
		   return a;
	   }
	   else {
		   return b;
	   }
   }
   
   public static int getMinOf2Ints(int a, int b) {
	   
	   if(a < b) {
		   return a;
	   }
	   else {
		   return b;
	   }
   }
   
   public static int getMaxOf3Ints(int c, int a, int b) {
	   
	   int mX = getMaxOf2Ints(a, b);
	   
	   if(mX > c) {
		   return mX;
	   }
	   else {
		   return c;
	   }
   }
   
   public static int getMinOf3Ints(int b, int c, int a) {
	   
	  int mM = getMinOf2Ints(a, b);
	  
	  if(mM < c) {
		  return mM;
	  }
	  else {
		  return c;
	  }
	   
   }
   
   public static int getMedianOf3Ints(int c, int b, int a) {
	   
	   if(c > getMinOf2Ints(a, b) && c < getMaxOf2Ints(a, b)) {
		   return c;
	   }
	   else if(a > getMinOf2Ints(b, c) && a < getMaxOf2Ints(b, c)) {
		   return a;
	   }
	   else {
		   return b;
	   }
   }
   
   public static void printMinOf3Ints(int b, int a, int c) {
	   
	   int minVal = getMinOf3Ints(b, a, c);
	   
	   System.out.println("The min is " + minVal);
   }
   
   public static int getProdOfAllPositiveInts(int a) {
	   
	   if(a > 0) {
	   
	   int prod = 1;
	   
	   for(int i = 1; i <= a; i++) {
		   
		   prod = prod * i;
	   }
	   return prod;
	   }
	   else {
		   return 0;
	   }
   }
   
   public static int getProdOfAllNegativeInts(int a) {
	   
	   if(a < 0) {
		   
		   int prod = 1;
		   
		   for(int i = -1; i >= a; i--) {
			   
			   prod = prod * i;
		   }
		   return prod;
		   }
	   else {
		   return 0;
	   }
	   
   }
   
   public static boolean isProdOfAllNegativeIntsNegative(int a) {
	   
	   if(getProdOfAllNegativeInts(a) < 0) {
		   return true;
	   }
	   else {
		   return false;
	   }
	   
	   
   }
   
   public static char getCharAtIndex(String s, int index) {
	   
	   char [] c = s.toCharArray();
   
	   
	   if(s.equals(null)){
		   return '?';
	   }
	   if(index < 0) {
		   return '?';
	   }
       if(index > s.length()-1) {
    	   return '?';
       }
       else {
    	   return c [index];
       
   }
   }
   
   public static int getCountOfCharInString(String s, char c) {
	   
	int counter = 0;
	
	for(int i = 0; i <= s.length()-1; i++) {
		if(s.charAt(i) == c) {
			
			counter++;
		}
	}
	return counter;
	   
   }
   
   public static String getStringReversed(String s) {
	   
	   String reverse = "";
	   
	  for(int i = s.length()-1; i >= 0; i--) {
		  
		   reverse = reverse + s.charAt(i);
	  }
	  return reverse;
	   
   }
   
   public static String getStringTitleCased(String s) {
	   
	s = s.toLowerCase();
	
	String str = s;
	StringBuilder result = new StringBuilder(str.length());
	String words [] = str.split("\\ ");
	for(int i = 0; i < words.length; i++) {
		
		result.append(Character.toUpperCase(words[i].charAt(0))).append(words[i].substring(1)).append(" ");
		
	}
	String sentence = result.toString();
  return sentence;
   } 
   
   
   
   
   
   
   
   
}