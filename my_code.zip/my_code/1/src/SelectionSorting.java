
public class SelectionSorting {
	
	public static void swap(int [] arr, int i, int j) {//Method that swaps the values of an array.
		int temp = arr [i];
		arr [i] = arr [j];
		arr [j] = temp;
	}
	
	public static void selectionSort(int [] arr) {
		for(int i = 0; i < arr.length - 1; i++) {
			int minIndex = i;
			
			for(int j = i + 1; j < arr.length; j++) {
				if(arr [j] < arr [minIndex]) {
					minIndex = j;
				}
			}
			swap(arr, i, minIndex);
		}
	}
	
	public static void main(String [] args) {
		
		int [] arr = {96, 57, 48, 88, 44, 51};
		
		for(int i = 0; i < arr.length; i++) {//Before the method
			System.out.print(arr [i] + ", ");
		}
		
		System.out.println();
		
		selectionSort(arr);
		
		for(int i = 0; i < arr.length; i++) {//After the method
			System.out.print(arr [i] + ", ");
		}
	}

}
