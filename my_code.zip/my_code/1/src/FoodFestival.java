import java.util.Scanner;

public class FoodFestival {
	
	public static void main(String [] args) {
		
		String yes = "Yes";
		String no = "No";
		String yesNo;
		String name;
		System.out.println("Welcome to the food festival!");
		System.out.println("Would you like to place an order?");
		Scanner scnr = new Scanner(System.in);
		yesNo = scnr.next();
		int mainSelection;
		
		if(yesNo.equalsIgnoreCase("No")) {
			System.out.println("Thank you for stopping by, maybe next time you'll sample our menu.");
			return;
		}
		if(yesNo.equalsIgnoreCase("Yes")) {
			System.out.println("What is your name for the order?");
			name = scnr.next();
			
			System.out.println("Select from the menu, " + name + ":");
			System.out.println("0 - Nothing");
			System.out.println("1 - Appetizer");
			System.out.println("2 - Main Course");
			System.out.println("3 - Dessert");
			System.out.println("Enter the number for your selection:");
			
			mainSelection = scnr.nextInt();
			
				if(mainSelection == 0) {
					System.exit(1);
				}
				switch(mainSelection) {
				case 1:
					System.out.println("Appetizer menu:");
					System.out.println("0 - Nothing");
					System.out.println("1 - Oysters");
					System.out.println("2 - Grilled Octopus");
					System.out.println("3 - Hummus");
					System.out.println("Enter the number for your appetizers selection:");
					
					//if(appSelection )
				}
			
			
			
		}
		
		
		
		
		
	}

}
