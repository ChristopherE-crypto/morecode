
public class Cat {//Declares the class
	//Member variables
	private String name;
	private double height;
	private double weight;
	private boolean isVaccinated;
	private int ageInDogYears;
	
	public Cat() {//Constructor
		
		name = "Bob";
		height = 0.0;
		weight = 0.0;
		isVaccinated = false;
		ageInDogYears = 0;
	}
	
	public void setAgeInDogYears(int a) {
		ageInDogYears = a;
	}
	
	public void speak() {
		System.out.println("Woof");
	}
	public void sit() {
		System.out.println("I, " + name + " will sit now.");
	}
	public void beg() {
		System.out.println("Treat for " + name + " woof please.");
	}
	public int getAgeConvertedIntoHumanYears() {
		return ageInDogYears * 7;
	}
	public void growTaller() {
		height++;
	}
	public void growTaller(double growthAmount) {
		if(isValid(growthAmount)) {
			height += growthAmount;
		}
	}
	private boolean isValid(double growthAmount) {//not sure about this part. Watch video of the lecture for more information.
		if(growthAmount > 0) {
			return true;
		}
		else {
			return false;
		}
	}
	//Setters for the class Cat
	public void setName(String n) {
		name = n;
	}
	public void setHeight(double h) {
		height = h;
	}
	public void setWeight(double w) {
		weight = w;
	}
	public void setIsVaccinated(boolean v) {
		isVaccinated = v;
	}
	//Getters for the class Cat
	public String getName() {
		return name;
	}
	public double getHeight() {
		return height;
	}
	public double getWeight() {
		return weight;
	}
	public boolean getIsVaccinated() {
		return isVaccinated;
	}

}
