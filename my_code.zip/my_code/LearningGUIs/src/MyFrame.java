import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class MyFrame extends JFrame{
	
	MyFrame(){
		
		this.setTitle("Jthis Title Goes Here");//Sets title of this
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//Exit out of the application
		this.setResizable(false);//Prevent this from being resized
		this.setSize(420, 420);//Sets the x-dimension and y-dimension of this
		
		this.setVisible(true);//Make this visible
		
		ImageIcon image = new ImageIcon("YoneIcon.png");//Create an image icon
		this.setIconImage(image.getImage());//Change icon of this
		this.getContentPane().setBackground(new Color(150, 66, 66));
	}

}
