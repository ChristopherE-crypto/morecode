
public class MyButton {

	public static void main(String[] args) {
		
		AnotherFrame myFrame = new AnotherFrame();

	}

}
