import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;

public class FrameTwo {

	public static void main(String[] args) {
		
		ImageIcon image = new ImageIcon("IreliaIcon.jpg");
		Border border = BorderFactory.createLineBorder(new Color(150, 66, 66), 3);//Create border
		
		JLabel label = new JLabel();//Create a label
		label.setText("I am learning GUI!");//Set text of label
		label.setIcon(image);
		label.setHorizontalTextPosition(JLabel.CENTER);//Set text left/center/right of icon
		label.setVerticalTextPosition(JLabel.TOP);//Set text top/center/bottom
		label.setForeground(new Color(160, 11, 100));//Set color of text
		label.setFont(new Font("MV Boli", Font.PLAIN, 50));//Set font of text
		label.setIconTextGap(20);//Set gap of text to image
		label.setBackground(Color.BLACK);//Set background color
		label.setOpaque(true);//Display background color
		label.setBorder(border);//Set border
		label.setVerticalAlignment(JLabel.CENTER);//Set vertical position of icon + text within label
		label.setHorizontalAlignment(JLabel.CENTER);//Set horizontal position of icon + text within label
		label.setBounds(175, 175, 350, 350);//Set x and y position within frame as well as position
		
		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(750, 750);
		//frame.setLayout(null);
		frame.setVisible(true);
		frame.add(label);
		frame.pack();//Accomodate all the elements

		
	}

}
