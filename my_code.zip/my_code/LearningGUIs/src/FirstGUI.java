import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class FirstGUI {

	public static void main(String[] args) {
		
//		JFrame frame = new JFrame();//Creates a frame
//		frame.setTitle("JFrame Title Goes Here");//Sets title of frame
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//Exit out of the application
//		frame.setResizable(false);//Prevent frame from being resized
//		frame.setSize(420, 420);//Sets the x-dimension and y-dimension of frame
//		
//		frame.setVisible(true);//Make frame visible
//		
//		ImageIcon image = new ImageIcon("YoneIcon.png");//Create an image icon
//		frame.setIconImage(image.getImage());//Change icon of frame
//		frame.getContentPane().setBackground(new Color(150, 66, 66));
		
		MyFrame myFrame = new MyFrame();

	}

}
