package com.tutorial.main;

public enum ID {
	
	Player(),
	Trail(),
	MenuParticle(),
	FastEnemy(),
	SmartEnemy(),
	EnemyBoss(),
	BasicEnemy();

}
